import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  const agencies = [
    {
      name: 'SolarTech Noida',
      city: 'Noida',
      district: 'Gautam Buddha Nagar',
      phone: '+919876543210',
      email: 'info@solartech-noida.in',
      address: 'Sector 18, Noida, UP 201301',
    },
    {
      name: 'Green Energy Greater Noida',
      city: 'Greater Noida',
      district: 'Gautam Buddha Nagar',
      phone: '+919876543211',
      email: 'info@greenenergy-gn.in',
      address: 'Alpha-1, Greater Noida, UP 201310',
    },
    {
      name: 'SunPower Meerut',
      city: 'Meerut',
      district: 'Meerut',
      phone: '+919876543212',
      email: 'info@sunpower-meerut.in',
      address: 'Hapur Road, Meerut, UP 250001',
    },
    {
      name: 'Shamli Solar Solutions',
      city: 'Shamli',
      district: 'Shamli',
      phone: '+919876543213',
      email: 'info@shamlisolar.in',
      address: 'Gandhi Road, Shamli, UP 247776',
    },
  ]

  for (const agency of agencies) {
    await prisma.agency.upsert({
      where: { email: agency.email },
      update: {},
      create: agency,
    })
  }

  console.log('Seed complete — agencies created')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
