const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
module.exports = {
  siteUrl: SITE_URL,
  generateRobotsTxt: true,
  generateIndexSitemap: true,
  changefreq: 'weekly',
  priority: 0.7,
  sitemapSize: 5000,
  robotsTxtOptions: {
    policies: [
      { userAgent: '*', allow: '/' },
      { userAgent: '*', disallow: ['/admin/', '/api/', '/_next/'] },
    ],
    additionalSitemaps: [`${SITE_URL}/sitemap.xml`],
  },
  additionalPaths: async () => {
    const cities = [
      'noida', 'greater-noida', 'ghaziabad', 'meerut',
      'baraut', 'baghpat', 'muzaffarnagar', 'saharanpur',
      'shamli', 'hapur', 'bulandshahr', 'moradabad',
    ]
    const blogs = [
      'pm-surya-ghar-subsidy-guide-up-2025',
      'solar-panel-price-noida-meerut-2025',
      'net-metering-pvvnl-uppcl-guide',
      'solar-loan-sbi-up-2025',
      'upneda-state-subsidy-application',
      'on-grid-off-grid-solar-up',
    ]
    return [
      ...cities.map(city => ({
        loc: `/cities/${city}`,
        changefreq: 'monthly',
        priority: 0.92,
        lastmod: new Date().toISOString(),
      })),
      ...blogs.map(slug => ({
        loc: `/blog/${slug}`,
        changefreq: 'monthly',
        priority: 0.85,
        lastmod: new Date().toISOString(),
      })),
    ]
  },
  transform: async (config, path) => {
    const priorities = {
      '/': 1.0,
      '/calculator': 0.98,
      '/muft-bijli-yojana': 0.95,
      '/cities': 0.93,
      '/why-solar': 0.90,
      '/blog': 0.90,
      '/learn/subsidies': 0.90,
      '/solar-installation-process': 0.88,
      '/learn/solar-basics': 0.85,
      '/learn/loans': 0.82,
      '/contact': 0.80,
      '/about': 0.65,
      '/partners': 0.75,
      '/privacy': 0.3,
      '/terms': 0.3,
    }
    return {
      loc: path,
      changefreq: path === '/' ? 'daily' : 'weekly',
      priority: priorities[path] ?? config.priority,
      lastmod: config.autoLastmod ? new Date().toISOString() : undefined,
      alternateRefs: [
        { href: `${SITE_URL}${path}`, hreflang: 'en-IN' },
        { href: `${SITE_URL}${path}?lang=hi`, hreflang: 'hi-IN' },
        { href: `${SITE_URL}${path}`, hreflang: 'x-default' },
      ],
    }
  },
}
