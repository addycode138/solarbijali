export interface City {
  name: string
  district: string
  slug: string
  description: string
  avgBill: number
  sunHours: number
}

export interface CalculatorInputs {
  monthlyBill: number
  city: City | string
  propertyType: 'residential' | 'commercial'
  financing: 'cash' | 'loan' | 'emi'
  roofArea: number
}

export interface CalculatorResult {
  systemSizeKw: number
  panelCount: number
  roofAreaRequired: number
  totalCost: number
  centralSubsidy: number
  stateSubsidy: number
  subsidyAmount: number  // total = central + state
  netCost: number
  emiMonthly: number
  annualSavings: number
  paybackYears: number
  co2OffsetKgPerYear: number
  savingsOver25Years: number
}

export interface Lead {
  id: string
  name: string
  phone: string
  email?: string
  city: string
  district?: string
  monthlyBill: number
  roofArea?: number
  propertyType: string
  systemSizeKw?: number
  totalCost?: number
  subsidyAmount?: number
  netCost?: number
  paybackYears?: number
  financing?: string
  status: LeadStatus
  agencyId?: string
  preferredTime?: string
  source?: string
  message?: string
  createdAt: Date
}

export type LeadStatus = 'NEW' | 'ASSIGNED' | 'CONTACTED' | 'QUOTED' | 'CONVERTED' | 'LOST'

export interface Agency {
  id: string
  name: string
  city: string
  district: string
  phone: string
  email: string
  address: string
  isActive: boolean
}

export interface LeadWithAgency extends Lead {
  agency?: Agency
}

export interface BlogPost {
  slug: string
  title: string
  description: string
  publishDate: string
  category: string
  readTime: number
  keywords: string[]
  content?: string
}
