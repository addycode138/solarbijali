'use client'
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { translations, Locale, defaultLocale, locales } from './translations'

interface I18nCtx { locale: Locale; t: typeof translations.en; setLocale: (l: Locale) => void }
const Ctx = createContext<I18nCtx>({ locale: defaultLocale, t: translations.en, setLocale: () => {} })

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(defaultLocale)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    // 1. URL param  ?lang=hi
    const urlParam = new URLSearchParams(window.location.search).get('lang') as Locale
    if (urlParam && locales.includes(urlParam)) {
      apply(urlParam); return
    }
    // 2. localStorage preference
    try {
      const stored = localStorage.getItem('sb-locale') as Locale
      if (stored && locales.includes(stored)) { apply(stored); return }
    } catch {}
    // 3. Browser navigator.languages (auto-detect)
    const navLangs = Array.from(navigator.languages || [navigator.language])
    for (const lang of navLangs) {
      const code = lang.split('-')[0].toLowerCase() as Locale
      if (locales.includes(code)) { apply(code); return }
    }
  }, [])

  function apply(l: Locale) {
    setLocaleState(l)
    if (typeof document !== 'undefined') document.documentElement.lang = l
  }

  const setLocale = (l: Locale) => {
    apply(l)
    try { localStorage.setItem('sb-locale', l) } catch {}
    // Update URL param
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href)
      if (l === defaultLocale) url.searchParams.delete('lang')
      else url.searchParams.set('lang', l)
      window.history.replaceState({}, '', url.toString())
    }
  }

  // Prevent hydration mismatch — render default locale on server
  const t = mounted ? translations[locale] : translations[defaultLocale]

  return <Ctx.Provider value={{ locale: mounted ? locale : defaultLocale, t, setLocale }}>{children}</Ctx.Provider>
}

export const useI18n = () => useContext(Ctx)
