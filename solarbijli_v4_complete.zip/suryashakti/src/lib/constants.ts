import type { City } from '@/types'

// ─── BRAND ──────────────────────────────────────────────────────────────────
export const BRAND_NAME    = 'SolarBijli'
export const BRAND_DOMAIN  = 'solarbijli.in'
export const PHONE         = '7373734778'
export const PHONE_INTL    = '+917373734778'
export const PHONE_DISPLAY = '+91 73737 34778'
export const WA_NUMBER     = '917373734778'
export const EMAIL         = 'pankajyadi@gmail.com'
export const ADMIN_EMAIL   = 'pankajyadi@gmail.com'

// ─── CITIES ─────────────────────────────────────────────────────────────────
export const CITIES: City[] = [
  {
    name: 'Noida',       district: 'Gautam Buddha Nagar', slug: 'noida',
    description: "Noida's fast-growing residential sectors are among UP's most active solar adoption zones. High PVVNL electricity tariffs and excellent rooftop availability drive strong ROI.",
    avgBill: 3200, sunHours: 5.4,
  },
  {
    name: 'Greater Noida', district: 'Gautam Buddha Nagar', slug: 'greater-noida',
    description: "Greater Noida's planned townships offer large unshaded rooftops ideal for 3–10 kW systems. All sectors covered by our MNRE-certified partners.",
    avgBill: 2800, sunHours: 5.4,
  },
  {
    name: 'Meerut', district: 'Meerut', slug: 'meerut',
    description: "Meerut combines high solar irradiance with PVVNL electricity rates, giving homeowners payback periods as short as 4 years.",
    avgBill: 2400, sunHours: 5.5,
  },
  {
    name: 'Baraut', district: 'Baghpat', slug: 'baraut',
    description: "Baraut in Baghpat district is a growing commercial hub. With high sun hours and low grid reliability, solar offers excellent ROI for homes and shops.",
    avgBill: 1900, sunHours: 5.6,
  },
  {
    name: 'Baghpat', district: 'Baghpat', slug: 'baghpat',
    description: "Baghpat district's sugarcane belt homes benefit from plentiful sunlight. Solar installations here regularly achieve 4-year payback periods.",
    avgBill: 1700, sunHours: 5.6,
  },
  {
    name: 'Ghaziabad', district: 'Ghaziabad', slug: 'ghaziabad',
    description: "Ghaziabad's dense urban residential colonies and industrial zones make it one of West UP's highest solar-demand districts. EMI as low as ₹638/month.",
    avgBill: 3000, sunHours: 5.4,
  },
  {
    name: 'Muzaffarnagar', district: 'Muzaffarnagar', slug: 'muzaffarnagar',
    description: "Muzaffarnagar's agro-industrial economy and high grid tariffs make solar a smart investment. Top sun hours at 5.7 hrs/day ensure excellent yield.",
    avgBill: 2200, sunHours: 5.7,
  },
  {
    name: 'Saharanpur', district: 'Saharanpur', slug: 'saharanpur',
    description: "Saharanpur's wood industry and dense residential areas are increasingly going solar. Subsidy + net metering makes it virtually free electricity.",
    avgBill: 2100, sunHours: 5.5,
  },
  {
    name: 'Shamli', district: 'Shamli', slug: 'shamli',
    description: "Shamli's agricultural heartland benefits enormously from solar. Among the highest sun hours in the region at 5.6 hrs/day.",
    avgBill: 1800, sunHours: 5.6,
  },
  {
    name: 'Hapur', district: 'Hapur', slug: 'hapur',
    description: "Hapur's growing urban population and high electricity costs make rooftop solar an increasingly popular choice. PVVNL net metering fully supported.",
    avgBill: 2000, sunHours: 5.5,
  },
  {
    name: 'Bulandshahr', district: 'Bulandshahr', slug: 'bulandshahr',
    description: "Bulandshahr district has strong solar potential with 5.5 hrs/day irradiance. PM Surya Ghar subsidy up to ₹1,08,000 available for all residential homes.",
    avgBill: 1900, sunHours: 5.5,
  },
  {
    name: 'Moradabad', district: 'Moradabad', slug: 'moradabad',
    description: "Moradabad's brass industry hub is going green. Rooftop solar slashes electricity bills for homes and workshops alike.",
    avgBill: 2300, sunHours: 5.5,
  },
]

// Cities to show in calculator (first 8 most popular)
export const CALCULATOR_CITIES = ['noida', 'greater-noida', 'ghaziabad', 'meerut', 'baraut', 'muzaffarnagar', 'saharanpur', 'shamli', 'baghpat', 'hapur', 'bulandshahr', 'moradabad']
export const CITY_MAP = Object.fromEntries(CITIES.map(c => [c.slug, c]))
export const WEST_UP_DISTRICTS = ['Gautam Buddha Nagar','Ghaziabad','Meerut','Baghpat','Muzaffarnagar','Saharanpur','Shamli','Hapur','Bulandshahr','Moradabad']

// ─── SUBSIDIES (Verified March 2025) ────────────────────────────────────────
// Central: PM Surya Ghar - MNRE CFA
// State: UPNEDA Rooftop Solar Policy 2022-2027 (₹15,000/kW, max ₹30,000)
export const SUBSIDY_SLABS = [
  { maxKw: 1,        central: 30000, state: 15000, total: 45000  },
  { maxKw: 2,        central: 60000, state: 30000, total: 90000  },
  { maxKw: Infinity, central: 78000, state: 30000, total: 108000 },
]

// ─── PRICING (MNRE Benchmark 2025) ──────────────────────────────────────────
export const COST_PER_KW_FIRST_2KW  = 50000   // ₹50,000/kW for first 2 kW
export const COST_PER_KW_ABOVE_2KW  = 45000   // ₹45,000/kW from 3rd kW

// ─── BANK LOAN OPTIONS (Verified 2025 from official bank portals) ────────────
// Source: SBI bank.sbi, Canara canarabank.com, ET, PM Surya Ghar portal
export const BANK_LOANS = [
  {
    bank: 'SBI',
    product: 'SBI Surya Ghar Scheme',
    rateUpto3kw: 7.00,       // % p.a. (linked to EBLR-2.25%, effective 7% currently)
    rateAbove3kw: 9.15,      // % p.a. for SBI home loan borrowers; 10.15% for others
    maxLoanUpto3kw: 200000,  // ₹2 lakh (up to 3kW)
    maxLoanAbove3kw: 600000, // ₹6 lakh (3-10kW)
    maxTenureMonths: 120,    // 10 years
    moratoriumMonths: 6,
    collateral: false,       // No collateral up to ₹2L
    marginPct: 10,           // 10% of project cost from borrower
    processingFee: 'NIL',
    cibilRequired: 680,
    applyUrl: 'https://www.jansamarth.in',
    color: '#1B4F9C',
  },
  {
    bank: 'Canara Bank',
    product: 'Canara Rooftop Solar (CRTS)',
    rateUpto3kw: 6.50,       // Most competitive rate currently
    rateAbove3kw: 8.50,
    maxLoanUpto3kw: 200000,
    maxLoanAbove3kw: 600000,
    maxTenureMonths: 120,
    moratoriumMonths: 6,
    collateral: false,
    marginPct: 10,
    processingFee: 'NIL',
    cibilRequired: 675,
    applyUrl: 'https://www.canarabank.com',
    color: '#F4A020',
  },
  {
    bank: 'Union Bank',
    product: 'Union Bank PM Surya Ghar Loan',
    rateUpto3kw: 7.00,       // RLLR-2.25% = 7% currently
    rateAbove3kw: 9.50,
    maxLoanUpto3kw: 200000,
    maxLoanAbove3kw: 600000,
    maxTenureMonths: 120,
    moratoriumMonths: 6,
    collateral: false,
    marginPct: 10,
    processingFee: 'NIL',
    cibilRequired: 680,
    applyUrl: 'https://www.unionbankofindia.co.in',
    color: '#E31837',
  },
  {
    bank: 'PNB',
    product: 'PNB Rooftop Solar Finance',
    rateUpto3kw: 7.00,       // Verified from pmsuryaghar.in Jan 2025
    rateAbove3kw: 8.40,
    maxLoanUpto3kw: 200000,
    maxLoanAbove3kw: 600000,
    maxTenureMonths: 120,
    moratoriumMonths: 6,
    collateral: false,
    marginPct: 10,
    processingFee: 'NIL',
    cibilRequired: 680,
    applyUrl: 'https://www.pnbindia.in',
    color: '#FF6600',
  },
  {
    bank: 'Bank of India',
    product: 'BOI Star Rooftop Solar',
    rateUpto3kw: 7.00,       // RBLR-2.25%, minimum 7% p.a.
    rateAbove3kw: 9.25,
    maxLoanUpto3kw: 200000,
    maxLoanAbove3kw: 1000000, // ₹10 lakh
    maxTenureMonths: 120,
    moratoriumMonths: 6,
    collateral: false,
    marginPct: 5,             // Only 5% margin when subsidy is available
    processingFee: 'NIL',
    cibilRequired: 675,
    applyUrl: 'https://www.bankofindia.co.in',
    color: '#004080',
  },
]

// ─── TARIFF ─────────────────────────────────────────────────────────────────
export const TARIFF_PER_UNIT    = 7.5    // PVVNL/UPPCL LMV-1 residential ₹/unit
export const ANNUAL_TARIFF_HIKE = 0.08   // 8% annual tariff escalation (UP avg)

// ─── SYSTEM SPECS ───────────────────────────────────────────────────────────
export const PANEL_WATT         = 545    // 545W monocrystalline (2025 standard)
export const PANEL_SQ_FT        = 24     // sq ft per 545W panel
export const SYSTEM_EFFICIENCY  = 0.80   // 80% overall system efficiency
export const KWH_PER_KW_PER_DAY = 4.2   // Western UP average
export const CO2_KG_PER_KWH     = 0.71  // India grid emission factor (CEA 2024)

// ─── GOVERNMENT SCHEME DETAILS ───────────────────────────────────────────────
export const PM_SURYA_GHAR_PORTAL   = 'https://pmsuryaghar.gov.in'
export const JAN_SAMARTH_PORTAL     = 'https://www.jansamarth.in'
export const UPNEDA_PORTAL          = 'https://upneda.org.in'
export const FREE_UNITS_PER_MONTH   = 300  // Units of free electricity per month (3kW)
export const SCHEME_LAUNCH_DATE     = 'February 13, 2024'
export const SCHEME_TOTAL_OUTLAY    = '₹75,021 crore'
export const SCHEME_TARGET_HOMES    = '1 crore (10 million)'
