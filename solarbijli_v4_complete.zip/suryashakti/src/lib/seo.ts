import type { Metadata } from 'next'
import { BRAND_NAME, PHONE, PHONE_DISPLAY, EMAIL } from './constants'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

// High-value keywords for UP solar market 2025 — all West UP districts
export const PRIMARY_KEYWORDS = [
  // Core brand + product
  'SolarBijli',
  'solar panel installation UP',
  'PM Surya Ghar subsidy UP 2025',
  'solar subsidy Uttar Pradesh 2025',
  '₹1,08,000 solar subsidy UP',
  'UPNEDA solar subsidy 2025',
  'PM Surya Ghar Muft Bijli Yojana',
  // City-level — Tier 1
  'solar panel installation Noida',
  'solar panel installation Ghaziabad',
  'solar panel installation Meerut',
  'rooftop solar Noida',
  'solar installer Greater Noida',
  'solar panel Ghaziabad 2025',
  // City-level — Tier 2
  'solar panel Muzaffarnagar',
  'solar panel Saharanpur',
  'solar panel Baraut Baghpat',
  'solar panel Shamli UP',
  'solar panel Hapur',
  'solar panel Bulandshahr',
  'solar panel Moradabad',
  // Technical keywords
  'PVVNL solar panel net metering',
  'solar calculator UP',
  'solar panel price Uttar Pradesh 2025',
  'MNRE empanelled solar installer UP',
  'on grid solar system UP',
  'net metering PVVNL 2025',
  'solar loan SBI UP 2025',
  'solar EMI 638 per month UP',
  'best solar company western UP',
  // AI/voice search optimised
  'how much does solar cost in UP',
  'solar subsidy kaise milegi UP',
  'free bijli yojana UP 2025',
]

export const LONG_TAIL_KEYWORDS = [
  'how much does solar cost in Noida 2025',
  'how much does solar cost in Ghaziabad 2025',
  'PM Surya Ghar subsidy apply online UP',
  'UPNEDA state solar subsidy 30000',
  '₹1,08,000 solar subsidy Uttar Pradesh residential',
  'solar EMI calculator UP tenure 5 7 10 15 years',
  'best solar panels for home in UP 2025',
  'solar payback period Noida Meerut Ghaziabad',
  'PVVNL net metering process 2025',
  'solar installation cost Meerut Muzaffarnagar 2025',
  'rooftop solar panel 3kW price UP after subsidy',
  'solar panel baraut baghpat installation',
  'solar saharanpur muzaffarnagar subsidy',
]

export function buildMetadata({
  title,
  description,
  path = '',
  keywords = [],
  noIndex = false,
}: {
  title: string
  description: string
  path?: string
  keywords?: string[]
  noIndex?: boolean
}): Metadata {
  const url = `${SITE_URL}${path}`
  const allKeywords = [...PRIMARY_KEYWORDS.slice(0, 10), ...keywords].join(', ')

  return {
    title,
    description,
    keywords: allKeywords,
    authors: [{ name: BRAND_NAME, url: SITE_URL }],
    creator: BRAND_NAME,
    publisher: BRAND_NAME,
    robots: noIndex
      ? 'noindex, nofollow'
      : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1',
    alternates: {
      canonical: url,
      languages: { 'en-IN': url, 'hi-IN': `${url}?lang=hi`, 'x-default': url },
    },
    openGraph: {
      title,
      description,
      url,
      siteName: BRAND_NAME,
      images: [{ url: `${SITE_URL}/og-image.jpg`, width: 1200, height: 630, alt: `${BRAND_NAME} - Solar Energy for UP` }],
      locale: 'en_IN',
      alternateLocale: ['hi_IN'],
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [`${SITE_URL}/og-image.jpg`],
      site: '@solarbijli',
    },
    other: {
      'geo.region': 'IN-UP',
      'geo.placename': 'Uttar Pradesh, India',
      'ICBM': '28.6139, 77.2090',
      'theme-color': '#4F46E5',
    },
  }
}

export function getOrganizationSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': `${SITE_URL}/#organization`,
    name: BRAND_NAME,
    url: SITE_URL,
    logo: { '@type': 'ImageObject', url: `${SITE_URL}/logo.png`, width: 200, height: 60 },
    description: `${BRAND_NAME} is West UP's leading solar panel installation platform. MNRE-certified installers across 12 districts — Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli, Hapur, Bulandshahr, Moradabad & more.`,
    telephone: `+91${PHONE}`,
    email: EMAIL,
    foundingDate: '2024',
    areaServed: [
      { '@type': 'City', name: 'Noida' },
      { '@type': 'City', name: 'Greater Noida' },
      { '@type': 'City', name: 'Ghaziabad' },
      { '@type': 'City', name: 'Meerut' },
      { '@type': 'City', name: 'Baraut' },
      { '@type': 'City', name: 'Baghpat' },
      { '@type': 'City', name: 'Muzaffarnagar' },
      { '@type': 'City', name: 'Saharanpur' },
      { '@type': 'City', name: 'Shamli' },
      { '@type': 'City', name: 'Hapur' },
      { '@type': 'City', name: 'Bulandshahr' },
      { '@type': 'City', name: 'Moradabad' },
    ],
    address: { '@type': 'PostalAddress', addressRegion: 'Uttar Pradesh', addressCountry: 'IN' },
    contactPoint: [{
      '@type': 'ContactPoint',
      telephone: `+91${PHONE}`,
      contactType: 'customer service',
      areaServed: 'IN-UP',
      availableLanguage: ['English', 'Hindi', 'Bhojpuri'],
    }],
    sameAs: [`https://wa.me/91${PHONE}`, `https://wa.me/${PHONE}`],
  }
}

export function getWebsiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': `${SITE_URL}/#website`,
    url: SITE_URL,
    name: BRAND_NAME,
    description: 'Solar panel installation platform for Uttar Pradesh — calculate savings, claim ₹1,08,000 total subsidy (Central+State), connect with certified installers.',
    publisher: { '@id': `${SITE_URL}/#organization` },
    potentialAction: {
      '@type': 'SearchAction',
      target: { '@type': 'EntryPoint', urlTemplate: `${SITE_URL}/search?q={search_term_string}` },
      'query-input': 'required name=search_term_string',
    },
    inLanguage: ['en-IN', 'hi-IN'],
  }
}

export function getLocalBusinessSchema(city: string, district: string) {
  const coords: Record<string, { lat: number; lng: number }> = {
    'Noida': { lat: 28.5355, lng: 77.3910 },
    'Greater Noida': { lat: 28.4744, lng: 77.5040 },
    'Ghaziabad': { lat: 28.6692, lng: 77.4538 },
    'Meerut': { lat: 28.9845, lng: 77.7064 },
    'Baraut': { lat: 29.1006, lng: 77.2610 },
    'Baghpat': { lat: 28.9454, lng: 77.2175 },
    'Muzaffarnagar': { lat: 29.4720, lng: 77.7085 },
    'Saharanpur': { lat: 29.9640, lng: 77.5460 },
    'Shamli': { lat: 29.4508, lng: 77.3106 },
    'Hapur': { lat: 28.7279, lng: 77.7760 },
    'Bulandshahr': { lat: 28.4066, lng: 77.8500 },
    'Moradabad': { lat: 28.8386, lng: 78.7733 },
  }
  const c = coords[city] ?? { lat: 28.9845, lng: 77.7064 }
  const slug = city.toLowerCase().replace(/\s+/g, '-')
  return {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    '@id': `${SITE_URL}/cities/${slug}/#business`,
    name: `${BRAND_NAME} - Solar Panels ${city}`,
    url: `${SITE_URL}/cities/${slug}`,
    telephone: `+91${PHONE}`,
    email: EMAIL,
    description: `Install solar panels in ${city}, ${district}. Get ₹1,08,000 total subsidy (PM Surya Ghar ₹78,000 + UPNEDA ₹30,000). Free calculator, MNRE certified installers. EMI from ₹638/month.`,
    address: { '@type': 'PostalAddress', addressLocality: city, addressRegion: 'Uttar Pradesh', addressCountry: 'IN' },
    geo: { '@type': 'GeoCoordinates', latitude: c.lat, longitude: c.lng },
    priceRange: '₹₹',
    aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.9', reviewCount: '127', bestRating: '5' },
    openingHoursSpecification: { '@type': 'OpeningHoursSpecification', dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'], opens: '09:00', closes: '20:00' },
    areaServed: [{ '@type': 'City', name: city }, { '@type': 'State', name: 'Uttar Pradesh' }],
    serviceType: 'Solar Panel Installation',
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Solar Installation Services',
      itemListElement: [
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: `1kW Solar Installation ${city}` }, price: '5000', priceCurrency: 'INR', description: `After ₹45,000 subsidy` },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: `3kW Solar Installation ${city}` }, price: '42000', priceCurrency: 'INR', description: `After ₹1,08,000 total subsidy` },
      ],
    },
  }
}

export function getCalculatorAppSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: `${BRAND_NAME} Solar Calculator — West UP`,
    url: `${SITE_URL}/calculator`,
    applicationCategory: 'FinanceApplication',
    description: `Free solar savings calculator for all 12 West UP districts. Calculate system size, ₹1,08,000 total subsidy (PM Surya Ghar + UPNEDA), loan EMI across 5/7/10/15 year tenures, and 25-year savings.`,
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
    featureList: [
      'Instant solar system size calculation for 12 West UP cities',
      'PM Surya Ghar central subsidy calculator (up to ₹78,000)',
      'UPNEDA UP state subsidy calculator (up to ₹30,000)',
      'Total ₹1,08,000 subsidy calculator',
      'Loan EMI calculator — choose 5, 7, 10 or 15 year tenure',
      'SBI (7%) and Canara Bank (6.5%) comparison',
      '25-year savings projection with tariff escalation',
      'CO2 offset calculator',
      'Net metering savings estimator',
    ],
    screenshot: `${SITE_URL}/screenshot-calculator.png`,
  }
}

export function getFAQSchema(faqs: { q: string; a: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: { '@type': 'Answer', text: faq.a },
    })),
  }
}

export function getHowToSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'HowTo',
    name: 'How to Install Solar Panels and Claim ₹1,08,000 Total Subsidy in UP',
    description: 'Step by step guide to install rooftop solar panels in Uttar Pradesh and claim PM Surya Ghar + UPNEDA subsidy',
    totalTime: 'P60D',
    estimatedCost: { '@type': 'MonetaryAmount', currency: 'INR', value: '42000' },
    step: [
      { '@type': 'HowToStep', name: 'Calculate your solar requirements', text: `Use ${BRAND_NAME} solar calculator to determine your system size based on monthly electricity bill.`, url: `${SITE_URL}/calculator` },
      { '@type': 'HowToStep', name: 'Connect with a certified installer', text: `Submit your details on ${BRAND_NAME} to get connected with an MNRE-empanelled installer in your UP city within 24 hours.` },
      { '@type': 'HowToStep', name: 'Free site survey and subsidy application', text: 'Free site visit. Installer handles PM Surya Ghar + UPNEDA subsidy applications and PVVNL net meter application.' },
      { '@type': 'HowToStep', name: 'Installation and subsidy receipt', text: 'Solar system installed in 7-14 days. Subsidy transferred to bank in ~30 days after commissioning.', url: 'https://pmsuryaghar.gov.in' },
    ],
  }
}

export function getProductSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: 'Solar Panel Installation Package UP',
    description: '3kW on-grid solar panel installation for residential homes in Uttar Pradesh. Includes MNRE panels, inverter, net meter application and ₹1,08,000 subsidy assistance.',
    offers: { '@type': 'AggregateOffer', lowPrice: '37000', highPrice: '250000', priceCurrency: 'INR', availability: 'https://schema.org/InStock' },
    aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.9', reviewCount: '247', bestRating: '5' },
    review: [
      { '@type': 'Review', author: { '@type': 'Person', name: 'Rajesh Sharma' }, reviewRating: { '@type': 'Rating', ratingValue: '5' }, reviewBody: `Excellent service from ${BRAND_NAME}. Got ₹1,08,000 total subsidy (₹78K central + ₹30K UPNEDA). Monthly bill went from ₹3,500 to ₹120. Highly recommended!`, datePublished: '2025-01-15' },
      { '@type': 'Review', author: { '@type': 'Person', name: 'Priya Singh' }, reviewRating: { '@type': 'Rating', ratingValue: '5' }, reviewBody: 'Professional installation. Full subsidy paperwork handled by SolarBijli team. Got total ₹1.08 lakh subsidy in 35 days.', datePublished: '2025-02-02' },
    ],
  }
}

export function getBreadcrumbSchema(items: { name: string; url: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({ '@type': 'ListItem', position: i + 1, name: item.name, item: item.url })),
  }
}
