import { z } from 'zod'

export const calculatorSchema = z.object({
  monthlyBill: z.number().min(100, 'Bill must be at least ₹100').max(100000),
  city: z.string().min(1, 'Select your city'),
  propertyType: z.enum(['residential', 'commercial']),
  roofArea: z.number().min(50).max(10000),
  financing: z.enum(['cash', 'loan', 'emi']),
})

export const leadSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  phone: z
    .string()
    .regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit Indian mobile number'),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  city: z.string().min(1),
  district: z.string().min(1),
  monthlyBill: z.number().min(100),
  roofArea: z.number().optional(),
  propertyType: z.string(),
  systemSizeKw: z.number(),
  totalCost: z.number(),
  subsidyAmount: z.number(),
  netCost: z.number(),
  paybackYears: z.number(),
  financing: z.string(),
  preferredTime: z.string().optional(),
})

export type CalculatorSchema = z.infer<typeof calculatorSchema>
export type LeadSchema = z.infer<typeof leadSchema>
