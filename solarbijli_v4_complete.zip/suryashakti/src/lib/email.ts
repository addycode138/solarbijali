import { Resend } from 'resend'
import { BRAND_NAME, PHONE_DISPLAY, ADMIN_EMAIL } from './constants'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM = process.env.EMAIL_FROM || `${BRAND_NAME} <no-reply@solarbijli.in>`
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

function baseTemplate(content: string) {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#F8FAFC;font-family:Inter,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 16px">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
<tr><td style="background:linear-gradient(135deg,#4F46E5,#7C3AED);padding:32px 40px;text-align:center">
<h1 style="margin:0;color:#fff;font-size:24px;font-weight:800;letter-spacing:-0.5px">☀️ ${BRAND_NAME}</h1>
<p style="margin:6px 0 0;color:rgba(255,255,255,0.8);font-size:14px">Solar Energy for Uttar Pradesh</p>
</td></tr>
<tr><td style="padding:40px">${content}</td></tr>
<tr><td style="background:#F1F5F9;padding:20px 40px;text-align:center">
<p style="margin:0;color:#64748B;font-size:12px">© 2025 ${BRAND_NAME} | <a href="${SITE_URL}" style="color:#4F46E5">solarbijli.in</a> | ${PHONE_DISPLAY}</p>
<p style="margin:8px 0 0;color:#94A3B8;font-size:11px">MNRE Certified Partners · PM Surya Ghar Registered</p>
</td></tr>
</table></td></tr></table>
</body></html>`
}

export async function sendLeadConfirmationEmail(lead: {
  name: string
  email: string
  city: string
  systemSizeKw?: number
  subsidyAmount?: number
  netCost?: number
  emiMonthly?: number
}) {
  if (!lead.email) return

  const content = `
<h2 style="margin:0 0 8px;color:#0F172A;font-size:22px;font-weight:800">Thank You, ${lead.name}! 🎉</h2>
<p style="margin:0 0 24px;color:#64748B;font-size:15px;line-height:1.6">We've received your solar enquiry for <strong style="color:#0F172A">${lead.city}</strong>. Our certified installer partner will contact you within <strong style="color:#059669">24 hours</strong>.</p>

${lead.systemSizeKw ? `
<div style="background:#EEF2FF;border:1px solid #C7D2FE;border-radius:12px;padding:20px;margin-bottom:24px">
<h3 style="margin:0 0 12px;color:#4F46E5;font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:0.05em">Your Solar Estimate</h3>
<table width="100%" cellpadding="6"><tr><td style="color:#64748B;font-size:14px">System Size</td><td style="color:#0F172A;font-weight:700;text-align:right;font-size:14px">${lead.systemSizeKw} kW</td></tr>
<tr><td style="color:#64748B;font-size:14px">Total Govt Subsidy (Central+State UP)</td><td style="color:#059669;font-weight:700;text-align:right;font-size:14px">- ₹${lead.subsidyAmount?.toLocaleString('en-IN')}</td></tr>
<tr style="border-top:2px solid #C7D2FE"><td style="color:#0F172A;font-weight:700;font-size:15px;padding-top:12px">Your Net Cost</td><td style="color:#4F46E5;font-weight:800;text-align:right;font-size:18px;padding-top:12px">₹${lead.netCost?.toLocaleString('en-IN')}</td></tr>
${lead.emiMonthly ? `<tr><td style="color:#64748B;font-size:14px">Monthly EMI (SBI 7%)</td><td style="color:#0F172A;font-weight:700;text-align:right;font-size:14px">₹${lead.emiMonthly?.toLocaleString('en-IN')}/month</td></tr>` : ''}
</table></div>` : ''}

<div style="background:#ECFDF5;border:1px solid #A7F3D0;border-radius:12px;padding:20px;margin-bottom:24px">
<h3 style="margin:0 0 12px;color:#059669;font-size:14px;font-weight:700">What Happens Next?</h3>
<p style="margin:0 0 8px;color:#0F172A;font-size:14px">📞 <strong>Within 24 hours:</strong> Our installer partner calls you</p>
<p style="margin:0 0 8px;color:#0F172A;font-size:14px">🏠 <strong>Within 3 days:</strong> Free site survey scheduled</p>
<p style="margin:0 0 8px;color:#0F172A;font-size:14px">📋 <strong>Day 4–7:</strong> System design + PM Surya Ghar subsidy application</p>
<p style="margin:0;color:#0F172A;font-size:14px">⚡ <strong>Day 7–21:</strong> Installation complete</p>
</div>

<div style="text-align:center;margin-bottom:24px">
<a href="https://wa.me/917373734778?text=Hi%20SolarBijli!%20I%20submitted%20my%20solar%20enquiry.%20My%20name%20is%20${encodeURIComponent(lead.name)}" style="display:inline-block;background:#25D366;color:#fff;font-weight:700;font-size:15px;padding:14px 32px;border-radius:10px;text-decoration:none;margin-right:10px">💬 Chat on WhatsApp</a>
<a href="tel:7373734778" style="display:inline-block;background:#4F46E5;color:#fff;font-weight:700;font-size:15px;padding:14px 32px;border-radius:10px;text-decoration:none">📞 Call Us</a>
</div>

<p style="margin:0;color:#94A3B8;font-size:12px;text-align:center">If you have any questions, call us at <strong>${PHONE_DISPLAY}</strong> or reply to this email.</p>`

  await resend.emails.send({
    from: FROM,
    to: lead.email,
    subject: `✅ Solar Enquiry Confirmed — ${BRAND_NAME} | ${lead.city}`,
    html: baseTemplate(content),
  }).catch(console.error)
}

export async function sendAdminNotificationEmail(lead: {
  name: string
  phone: string
  email?: string
  city: string
  monthlyBill: number
  systemSizeKw?: number
  netCost?: number
  subsidyAmount?: number
  source?: string
}) {
  const content = `
<h2 style="margin:0 0 8px;color:#0F172A;font-size:22px;font-weight:800">🔔 New Solar Lead!</h2>
<p style="margin:0 0 24px;color:#64748B;font-size:14px">Source: ${lead.source || 'Website'} | ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>

<div style="background:#EEF2FF;border:1px solid #C7D2FE;border-radius:12px;padding:20px;margin-bottom:20px">
<h3 style="margin:0 0 12px;color:#4F46E5;font-size:14px;font-weight:700;text-transform:uppercase">Lead Details</h3>
<table width="100%" cellpadding="6">
<tr><td style="color:#64748B;font-size:14px;width:40%">Name</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.name}</td></tr>
<tr><td style="color:#64748B;font-size:14px">Phone</td><td style="color:#0F172A;font-weight:700;font-size:14px"><a href="tel:${lead.phone}" style="color:#4F46E5">${lead.phone}</a></td></tr>
<tr><td style="color:#64748B;font-size:14px">Email</td><td style="color:#0F172A;font-size:14px">${lead.email || '—'}</td></tr>
<tr><td style="color:#64748B;font-size:14px">City</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.city}</td></tr>
<tr><td style="color:#64748B;font-size:14px">Monthly Bill</td><td style="color:#0F172A;font-weight:700;font-size:14px">₹${lead.monthlyBill?.toLocaleString('en-IN')}</td></tr>
${lead.systemSizeKw ? `<tr><td style="color:#64748B;font-size:14px">System Size</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.systemSizeKw} kW</td></tr>` : ''}
${lead.subsidyAmount ? `<tr><td style="color:#64748B;font-size:14px">Total Subsidy</td><td style="color:#059669;font-weight:700;font-size:14px">₹${lead.subsidyAmount?.toLocaleString('en-IN')}</td></tr>` : ''}
${lead.netCost ? `<tr><td style="color:#64748B;font-size:14px">Net Cost</td><td style="color:#4F46E5;font-weight:800;font-size:16px">₹${lead.netCost?.toLocaleString('en-IN')}</td></tr>` : ''}
</table></div>

<div style="text-align:center">
<a href="https://wa.me/${lead.phone.replace(/\D/g,'')}?text=Hi%20${encodeURIComponent(lead.name)},%20I%20am%20calling%20from%20SolarBijli%20regarding%20your%20solar%20enquiry." style="display:inline-block;background:#25D366;color:#fff;font-weight:700;font-size:15px;padding:14px 28px;border-radius:10px;text-decoration:none;margin-right:10px">📱 WhatsApp Lead</a>
<a href="tel:${lead.phone}" style="display:inline-block;background:#4F46E5;color:#fff;font-weight:700;font-size:15px;padding:14px 28px;border-radius:10px;text-decoration:none">📞 Call Now</a>
</div>`

  await resend.emails.send({
    from: FROM,
    to: ADMIN_EMAIL,
    subject: `🌞 New Lead: ${lead.name} | ${lead.city} | ₹${lead.monthlyBill?.toLocaleString('en-IN')}/mo`,
    html: baseTemplate(content),
  }).catch(console.error)
}

export async function sendAgencyNotificationEmail(lead: {
  name: string
  phone: string
  email?: string
  city: string
  monthlyBill: number
  systemSizeKw?: number
  netCost?: number
}, agencyEmail: string, agencyName: string) {
  const content = `
<h2 style="margin:0 0 8px;color:#0F172A;font-size:22px;font-weight:800">New Installation Lead from ${BRAND_NAME}</h2>
<p style="margin:0 0 24px;color:#64748B;font-size:14px">Dear ${agencyName}, a new customer has enquired about solar installation in your coverage area.</p>

<div style="background:#EEF2FF;border:1px solid #C7D2FE;border-radius:12px;padding:20px;margin-bottom:20px">
<h3 style="margin:0 0 12px;color:#4F46E5;font-size:14px;font-weight:700;text-transform:uppercase">Customer Details</h3>
<table width="100%" cellpadding="6">
<tr><td style="color:#64748B;font-size:14px;width:40%">Name</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.name}</td></tr>
<tr><td style="color:#64748B;font-size:14px">Phone</td><td style="color:#0F172A;font-weight:700;font-size:14px"><a href="tel:${lead.phone}" style="color:#4F46E5">${lead.phone}</a></td></tr>
<tr><td style="color:#64748B;font-size:14px">City</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.city}</td></tr>
<tr><td style="color:#64748B;font-size:14px">Monthly Bill</td><td style="color:#0F172A;font-weight:700;font-size:14px">₹${lead.monthlyBill?.toLocaleString('en-IN')}</td></tr>
${lead.systemSizeKw ? `<tr><td style="color:#64748B;font-size:14px">System Size</td><td style="color:#0F172A;font-weight:700;font-size:14px">${lead.systemSizeKw} kW</td></tr>` : ''}
${lead.netCost ? `<tr><td style="color:#64748B;font-size:14px">Net Cost (after subsidy)</td><td style="color:#4F46E5;font-weight:800;font-size:16px">₹${lead.netCost?.toLocaleString('en-IN')}</td></tr>` : ''}
</table></div>

<p style="margin:0;color:#64748B;font-size:14px;text-align:center">Please contact the customer within 24 hours as per your SolarBijli partnership agreement.</p>`

  await resend.emails.send({
    from: FROM,
    to: agencyEmail,
    subject: `New Lead: ${lead.name} | ${lead.city} | ${lead.systemSizeKw || '?'}kW System`,
    html: baseTemplate(content),
  }).catch(console.error)
}
