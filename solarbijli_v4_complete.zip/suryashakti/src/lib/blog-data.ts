export interface BlogPost {
  slug: string
  title: string
  metaTitle: string
  metaDesc: string
  category: string
  publishDate: string
  updateDate: string
  readTime: number
  author: string
  keywords: string[]
  excerpt: string
  emoji: string
  content: string
  faqSchema?: { q: string; a: string }[]
}

export const BLOG_POSTS: BlogPost[] = [
  {
    slug: 'pm-surya-ghar-subsidy-guide-up-2025',
    title: 'PM Surya Ghar Subsidy 2025: Complete Guide for UP Residents (₹1,08,000 Total)',
    metaTitle: 'PM Surya Ghar Subsidy UP 2025 | ₹1,08,000 Total Subsidy Guide | SolarBijli',
    metaDesc: 'Complete guide to PM Surya Ghar Muft Bijli Yojana subsidy in Uttar Pradesh 2025. Get ₹78,000 central + ₹30,000 UP state = ₹1,08,000 total. Step-by-step application at pmsuryaghar.gov.in.',
    category: 'Subsidy Guide',
    publishDate: '2025-01-15',
    updateDate: '2025-03-01',
    readTime: 8,
    author: 'SolarBijli Team',
    emoji: '☀️',
    keywords: ['PM Surya Ghar subsidy UP 2025', 'solar subsidy Uttar Pradesh', 'UPNEDA subsidy', '₹1,08,000 solar subsidy UP', 'PM Surya Ghar apply'],
    excerpt: 'Step-by-step guide to claim ₹1,08,000 total subsidy in UP. Documents needed, application process, and timeline explained.',
    content: `
<h2>What is PM Surya Ghar Muft Bijli Yojana?</h2>
<p>PM Surya Ghar Muft Bijli Yojana was launched on February 13, 2024 by the Government of India under the Ministry of New and Renewable Energy (MNRE). It is the world's largest domestic rooftop solar scheme with a total financial outlay of ₹75,021 crore.</p>
<p>The scheme aims to install solar panels on 1 crore (10 million) residential homes across India by 2026-27, providing eligible households up to 300 units of free electricity every month.</p>

<h2>Total Solar Subsidy Available in UP in 2025</h2>
<p>Uttar Pradesh residents are eligible for <strong>two subsidies combined</strong>:</p>
<table>
<thead><tr><th>System Size</th><th>Central Subsidy (PM Surya Ghar)</th><th>UP State Subsidy (UPNEDA)</th><th>Total Subsidy in UP</th></tr></thead>
<tbody>
<tr><td>1 kW</td><td>₹30,000</td><td>₹15,000</td><td><strong>₹45,000</strong></td></tr>
<tr><td>2 kW</td><td>₹60,000</td><td>₹30,000</td><td><strong>₹90,000</strong></td></tr>
<tr><td>3 kW</td><td>₹78,000</td><td>₹30,000</td><td><strong>₹1,08,000</strong></td></tr>
<tr><td>Above 3 kW</td><td>₹78,000 (Capped)</td><td>₹30,000 (Capped)</td><td><strong>₹1,08,000 (Maximum)</strong></td></tr>
</tbody>
</table>

<h3>Central Financial Assistance (CFA) — PM Surya Ghar</h3>
<p>The central government provides CFA (Central Financial Assistance) directly to your bank account:</p>
<ul>
<li>₹30,000 per kW for first 2 kW capacity (total ₹60,000 for 2 kW)</li>
<li>₹18,000 for the third kW (total ₹78,000 for 3 kW)</li>
<li>Capped at ₹78,000 for systems above 3 kW</li>
</ul>

<h3>UP State Subsidy — UPNEDA</h3>
<p>The Uttar Pradesh New and Renewable Energy Development Agency (UPNEDA) provides an additional state subsidy of <strong>₹15,000 per kW, capped at ₹30,000 per consumer</strong>.</p>
<p>This state subsidy is automatically released by UPNEDA after the central CFA is disbursed through the national portal. You don't need to apply separately.</p>

<h2>Eligibility for PM Surya Ghar in UP</h2>
<ul>
<li>Must be an Indian citizen</li>
<li>Must own a house with a suitable roof</li>
<li>Must have a valid electricity connection (PVVNL/UPPCL consumer number)</li>
<li>Should not have availed any prior rooftop solar subsidy</li>
<li>Only residential connections qualify (not commercial/industrial)</li>
</ul>

<h2>Step-by-Step Application Process</h2>
<ol>
<li><strong>Visit the Portal:</strong> Go to pmsuryaghar.gov.in and click "Apply for Rooftop Solar"</li>
<li><strong>Register:</strong> Select Uttar Pradesh as your state, choose your DISCOM (PVVNL/UPPCL), and enter your consumer account number</li>
<li><strong>Fill Application:</strong> Enter personal details, electricity bill info, and bank account details</li>
<li><strong>Choose Vendor:</strong> Select an MNRE-empanelled solar installer from the portal (SolarBijli partners are all empanelled)</li>
<li><strong>Installation:</strong> Vendor completes installation as per MNRE specifications</li>
<li><strong>Documentation:</strong> Submit plant details, photos, and commissioning report on the portal</li>
<li><strong>Net Meter:</strong> DISCOM conducts inspection and installs net meter</li>
<li><strong>Subsidy Transfer:</strong> CFA transferred to your bank within 30 days of commissioning certificate</li>
<li><strong>UPNEDA Subsidy:</strong> UP state subsidy automatically released after central CFA</li>
</ol>

<h2>Documents Required</h2>
<ul>
<li>Aadhaar card (identity proof)</li>
<li>Latest electricity bill (consumer number)</li>
<li>Bank account details (for DBT transfer)</li>
<li>Property documents / ownership proof</li>
<li>Mobile number (linked to Aadhaar)</li>
<li>Passport-size photograph</li>
</ul>

<h2>Free Electricity Under PM Surya Ghar</h2>
<p>A 3 kW rooftop solar system generates approximately 360-450 units of electricity per month in Western UP (5.5 hours of sunlight per day). If your monthly consumption is below this, you effectively get <strong>zero or near-zero electricity bills</strong> after installation.</p>

<h2>Loan Facility</h2>
<p>Collateral-free solar loans of up to ₹2 lakh are available at approximately 7% interest rate through public sector banks (SBI, PNB, Bank of Baroda, Canara Bank). Applications can be made through the JanSamarth Portal (jansamarth.in).</p>
    `,
    faqSchema: [
      { q: 'What is the total solar subsidy in UP in 2025?', a: 'UP residents get ₹1,08,000 total subsidy for 3kW+ systems — ₹78,000 from PM Surya Ghar (Central) and ₹30,000 from UPNEDA (UP State).' },
      { q: 'How to apply for PM Surya Ghar subsidy?', a: 'Visit pmsuryaghar.gov.in, register with your DISCOM consumer number, choose an empanelled vendor, get installation done, and subsidy is transferred to your bank within 30 days of commissioning.' },
      { q: 'Is UPNEDA subsidy separate from PM Surya Ghar?', a: 'Yes. UPNEDA provides ₹15,000/kW (max ₹30,000) as a separate state subsidy on top of the central PM Surya Ghar subsidy. It is automatically released after central subsidy.' },
    ],
  },
  {
    slug: 'solar-panel-price-noida-meerut-2025',
    title: 'Solar Panel Price in Noida & Meerut 2025: With & Without Subsidy',
    metaTitle: 'Solar Panel Price Noida Meerut 2025 | With ₹1,08,000 Subsidy | SolarBijli',
    metaDesc: 'Actual solar panel prices in Noida, Meerut, Greater Noida 2025. 1kW=₹50,000, 2kW=₹1,00,000, 3kW=₹1,45,000. After ₹1,08,000 subsidy, 3kW net cost is just ₹37,000-₹57,000.',
    category: 'Pricing',
    publishDate: '2025-01-10',
    updateDate: '2025-02-15',
    readTime: 6,
    author: 'SolarBijli Team',
    emoji: '💡',
    keywords: ['solar panel price Noida 2025', 'solar panel price Meerut', '3kW solar system price UP', 'solar cost after subsidy UP', 'MNRE benchmark price 2025'],
    excerpt: 'Actual solar panel prices from MNRE benchmark costs with full subsidy calculation for Noida, Meerut and Greater Noida.',
    content: `
<h2>Solar Panel Prices in UP — MNRE Benchmark 2025</h2>
<p>As per MNRE (Ministry of New and Renewable Energy) benchmark costs for 2025, the standard prices for grid-connected rooftop solar systems in Uttar Pradesh are:</p>
<ul>
<li>₹50,000 per kW for the first 2 kW of capacity</li>
<li>₹45,000 per kW for capacity beyond 2 kW (up to 3 kW)</li>
</ul>
<p>These are standard benchmark prices. Actual market prices in Noida, Meerut, and Greater Noida may vary by 10-20% depending on panel type, installer, and system configuration.</p>

<h2>Solar System Prices in UP Before and After Subsidy</h2>
<table>
<thead><tr><th>System Size</th><th>Price Before Subsidy</th><th>UP Total Subsidy</th><th>Net Cost After Subsidy</th><th>EMI (84 months)</th></tr></thead>
<tbody>
<tr><td>1 kW</td><td>₹50,000</td><td>₹45,000</td><td>₹5,000</td><td>₹76/month</td></tr>
<tr><td>2 kW</td><td>₹1,00,000</td><td>₹90,000</td><td>₹10,000</td><td>₹152/month</td></tr>
<tr><td>3 kW</td><td>₹1,45,000</td><td>₹1,08,000</td><td>₹37,000</td><td>₹562/month</td></tr>
<tr><td>4 kW</td><td>₹1,90,000</td><td>₹1,08,000</td><td>₹82,000</td><td>₹1,247/month</td></tr>
<tr><td>5 kW</td><td>₹2,35,000</td><td>₹1,08,000</td><td>₹1,27,000</td><td>₹1,932/month</td></tr>
</tbody>
</table>
<p><em>Note: Prices are indicative based on MNRE benchmark. Actual prices may vary. EMI calculated at SBI 7% or Canara 6.5% p.a. Choose 5–15 year tenure.</em></p>

<h2>What's Included in Solar System Price?</h2>
<p>The all-inclusive price covers:</p>
<ul>
<li>Solar panels (monocrystalline, MNRE-approved ALMM listed)</li>
<li>Grid-tied string inverter</li>
<li>Mounting structure (rooftop)</li>
<li>AC/DC cables, conduits, connectors</li>
<li>Safety equipment (MCB, isolators, earthing)</li>
<li>Installation and commissioning charges</li>
<li>PM Surya Ghar portal application assistance</li>
<li>PVVNL net meter application</li>
<li>5-year workmanship warranty</li>
</ul>

<h2>Solar Panel Prices in Specific UP Cities</h2>
<h3>Solar Panel Price in Noida (3 kW)</h3>
<p>In Noida, a 3 kW on-grid solar system typically costs ₹1,45,000–₹1,60,000 before subsidy. After ₹1,08,000 total subsidy (Central + UPNEDA), the net cost is <strong>₹37,000–₹52,000</strong>.</p>

<h3>Solar Panel Price in Meerut (3 kW)</h3>
<p>In Meerut, a 3 kW solar system costs ₹1,40,000–₹1,55,000 before subsidy. After subsidy, net cost ranges <strong>₹32,000–₹47,000</strong>. Meerut has slightly higher sun hours (5.5/day) improving ROI.</p>

<h3>Solar Panel Price in Greater Noida (3 kW)</h3>
<p>Greater Noida system prices are similar to Noida at ₹1,45,000–₹1,60,000. Net cost after subsidy: <strong>₹37,000–₹52,000</strong>.</p>
    `,
    faqSchema: [
      { q: 'What is the price of 3kW solar in West UP with subsidy?', a: 'A 3kW solar system in Noida costs ₹1,45,000–₹1,60,000 before subsidy. After ₹1,08,000 total subsidy (Central ₹78,000 + UP State ₹30,000), net cost is ₹37,000–₹52,000.' },
      { q: 'What is MNRE benchmark price for solar in UP 2025?', a: 'MNRE benchmark price is ₹50,000/kW for first 2kW and ₹45,000/kW for 3rd kW. So 3kW benchmark cost is ₹1,45,000 before subsidy.' },
    ],
  },
  {
    slug: 'net-metering-pvvnl-uppcl-guide',
    title: 'Net Metering in UP: How to Earn from Solar via PVVNL/UPPCL (2025 Guide)',
    metaTitle: 'Net Metering UP 2025 | PVVNL UPPCL Solar Net Meter Application | SolarBijli',
    metaDesc: 'Complete guide to net metering in Uttar Pradesh 2025. How PVVNL and UPPCL net metering works, application process, billing cycle, and how to maximise solar earnings in UP.',
    category: 'Net Metering',
    publishDate: '2024-12-20',
    updateDate: '2025-01-10',
    readTime: 5,
    author: 'SolarBijli Team',
    emoji: '⚡',
    keywords: ['net metering UP', 'PVVNL net metering', 'UPPCL solar net meter', 'solar net metering application UP', 'sell solar power to grid UP'],
    excerpt: 'How net metering works with PVVNL/UPPCL, application process, billing cycle, and maximizing solar savings in UP.',
    content: `
<h2>What is Net Metering?</h2>
<p>Net metering allows you to sell surplus solar electricity generated by your rooftop solar system back to the grid (PVVNL/UPPCL). Instead of wasting excess power, it gets exported to the grid and you receive credits on your electricity bill.</p>

<h2>How Net Metering Works in UP</h2>
<p>In Uttar Pradesh, net metering is supported by all DISCOMs including PVVNL (Paschimanchal Vidyut Vitran Nigam Limited) which covers Noida, Meerut, Greater Noida, and Shamli.</p>
<ol>
<li>Your solar panels generate electricity during the day</li>
<li>Your home uses what it needs first</li>
<li>Surplus electricity flows to the PVVNL grid (export)</li>
<li>At night or cloudy days, you draw from the grid (import)</li>
<li>Your bill = (Units imported × tariff) − (Units exported × tariff)</li>
<li>If you export more than you import, credit carries forward to next bill</li>
</ol>

<h2>Net Metering Application Process with PVVNL</h2>
<ol>
<li>Complete solar installation by MNRE-empanelled vendor</li>
<li>Vendor applies for net meter on PM Surya Ghar portal</li>
<li>PVVNL conducts site inspection within 15-30 days</li>
<li>Net meter (bidirectional) is installed by PVVNL</li>
<li>Commissioning certificate is generated</li>
<li>Your regular meter is replaced with a bidirectional smart meter</li>
</ol>

<h2>Net Metering Benefits for UP Homes</h2>
<ul>
<li>Electricity bill can go to ₹0 or even negative (DISCOM owes you!)</li>
<li>No battery required — grid acts as free storage</li>
<li>Credits carry forward month-to-month within the financial year</li>
<li>Any annual surplus can be settled at FiT (Feed-in Tariff) rate</li>
</ul>
    `,
    faqSchema: [
      { q: 'Does PVVNL support net metering for solar?', a: 'Yes, PVVNL (Paschimanchal Vidyut Vitran Nigam) supports net metering for all grid-connected rooftop solar systems in its coverage areas including Noida, Meerut, Greater Noida, and Shamli.' },
    ],
  },
]

export const BLOG_CATEGORIES = ['All', 'Subsidy Guide', 'Pricing', 'Net Metering', 'Financing', 'UPNEDA', 'Solar Basics']
