import type { CalculatorInputs, CalculatorResult } from '@/types'
import {
  COST_PER_KW_FIRST_2KW, COST_PER_KW_ABOVE_2KW,
  PANEL_WATT, PANEL_SQ_FT, SUBSIDY_SLABS,
  TARIFF_PER_UNIT, KWH_PER_KW_PER_DAY,
  SYSTEM_EFFICIENCY, CO2_KG_PER_KWH, CITY_MAP,
  BANK_LOANS,
} from './constants'

// Verified loan rate lookup — bank name -> rate for ≤3kW
export const LOAN_RATES = {
  canara: { rate: 0.065, months: 120, name: 'Canara Bank (6.5%)' },   // Cheapest verified
  sbi:    { rate: 0.07,  months: 120, name: 'SBI (7.0%)' },
  union:  { rate: 0.07,  months: 120, name: 'Union Bank (7.0%)' },
  pnb:    { rate: 0.07,  months: 120, name: 'PNB (7.0%)' },
  boi:    { rate: 0.07,  months: 120, name: 'Bank of India (7.0%)' },
} as const

export type LoanBank = keyof typeof LOAN_RATES

export function calculateSolar(inputs: CalculatorInputs): CalculatorResult {
  const { monthlyBill, city, financing, roofArea } = inputs
  const cityData = typeof city === 'string' ? CITY_MAP[city] : city
  const sunHours = cityData?.sunHours ?? 5.2

  // System sizing
  const monthlyUnits = monthlyBill / TARIFF_PER_UNIT
  const rawKw = (monthlyUnits / 30) / (sunHours * SYSTEM_EFFICIENCY)
  const systemSizeKw = Math.min(Math.max(Math.ceil(rawKw * 2) / 2, 0.5), 10)

  const panelCount = Math.ceil((systemSizeKw * 1000) / PANEL_WATT)
  const roofAreaRequired = panelCount * PANEL_SQ_FT

  // Cost (MNRE benchmark 2025)
  const totalCost = systemSizeKw <= 2
    ? systemSizeKw * COST_PER_KW_FIRST_2KW
    : 2 * COST_PER_KW_FIRST_2KW + (systemSizeKw - 2) * COST_PER_KW_ABOVE_2KW

  // Subsidies (residential only)
  let centralSubsidy = 0, stateSubsidy = 0
  if (inputs.propertyType === 'residential') {
    const slab = SUBSIDY_SLABS.find(s => systemSizeKw <= s.maxKw)
    if (slab) { centralSubsidy = slab.central; stateSubsidy = slab.state }
  }
  const totalSubsidy = centralSubsidy + stateSubsidy
  const netCost = Math.max(totalCost - totalSubsidy, 0)

  // EMI calculation using actual bank rates (verified 2025)
  // Use SBI 7% as the default "SBI Loan" option; Canara 6.5% as "Easy EMI" (cheapest)
  let emiMonthly = 0
  if (financing !== 'cash') {
    // Determine rate based on selected bank/option
    let annualRate = 0.07   // Default SBI 7%
    let tenureMonths = 120  // 10 years (bank standard)

    if (financing === 'emi') {
      annualRate = 0.065  // Canara Bank best rate
      tenureMonths = 120
    }

    // Loan amount: banks fund up to 90% of post-subsidy cost
    // Borrower pays 10% margin upfront
    const loanAmount = Math.min(netCost * 0.90, systemSizeKw <= 3 ? 200000 : 600000)
    const mr = annualRate / 12
    emiMonthly = loanAmount > 0
      ? Math.round((loanAmount * mr * Math.pow(1 + mr, tenureMonths)) / (Math.pow(1 + mr, tenureMonths) - 1))
      : 0
  }

  // Savings
  const annualUnits = systemSizeKw * KWH_PER_KW_PER_DAY * 365
  const annualSavings = Math.round(annualUnits * TARIFF_PER_UNIT)
  const paybackYears = parseFloat((netCost / annualSavings).toFixed(1))
  const co2OffsetKgPerYear = Math.round(annualUnits * CO2_KG_PER_KWH)

  let savingsOver25Years = 0, tariff = TARIFF_PER_UNIT
  for (let i = 0; i < 25; i++) { savingsOver25Years += annualUnits * tariff; tariff *= 1.02 }

  return {
    systemSizeKw, panelCount, roofAreaRequired, totalCost,
    centralSubsidy, stateSubsidy, subsidyAmount: totalSubsidy,
    netCost, emiMonthly, annualSavings, paybackYears,
    co2OffsetKgPerYear, savingsOver25Years: Math.round(savingsOver25Years),
  }
}

// EMI table for all banks
export function getEmiTable(netCost: number, systemKw: number) {
  const loanAmt = Math.min(netCost * 0.90, systemKw <= 3 ? 200000 : 600000)
  return BANK_LOANS.filter(b => b.bank !== 'Bank of India' || systemKw <= 3).map(b => {
    const rate = systemKw <= 3 ? b.rateUpto3kw : b.rateAbove3kw
    const mr = rate / 100 / 12
    const emi = loanAmt > 0
      ? Math.round((loanAmt * mr * Math.pow(1 + mr, b.maxTenureMonths)) / (Math.pow(1 + mr, b.maxTenureMonths) - 1))
      : 0
    return { bank: b.bank, product: b.product, rate, emi, tenure: b.maxTenureMonths / 12, loanAmt, color: b.color }
  }).sort((a, b) => a.emi - b.emi) // Sort cheapest first
}

export function formatINR(n: number): string {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`
  if (n >= 100000)   return `₹${(n / 100000).toFixed(1)} L`
  return `₹${Math.round(n).toLocaleString('en-IN')}`
}

export function formatINRFull(n: number): string {
  return `₹${Math.round(n).toLocaleString('en-IN')}`
}
