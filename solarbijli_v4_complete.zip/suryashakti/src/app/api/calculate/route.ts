import { NextRequest, NextResponse } from 'next/server'
import { calculatorSchema } from '@/lib/validations'
import { calculateSolar } from '@/lib/calculator'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = calculatorSchema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid inputs', issues: parsed.error.flatten() },
        { status: 400 }
      )
    }

    const result = calculateSolar(parsed.data)
    return NextResponse.json({ result })
  } catch {
    return NextResponse.json({ error: 'Calculation failed' }, { status: 500 })
  }
}
