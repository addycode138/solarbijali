import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET(req: NextRequest) {
  const city = req.nextUrl.searchParams.get('city')

  const where = city ? { city, isActive: true } : { isActive: true }

  const agencies = await prisma.agency.findMany({
    where,
    select: {
      id: true,
      name: true,
      city: true,
      district: true,
      phone: true,
      address: true,
    },
    orderBy: { city: 'asc' },
  })

  return NextResponse.json({ agencies })
}

export async function POST(req: NextRequest) {
  const secret = req.headers.get('x-admin-secret')
  if (secret !== process.env.ADMIN_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()
  const agency = await prisma.agency.create({ data: body })
  return NextResponse.json({ agency }, { status: 201 })
}
