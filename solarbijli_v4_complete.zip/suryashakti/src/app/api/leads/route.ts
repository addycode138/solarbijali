import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { sendLeadConfirmationEmail, sendAdminNotificationEmail, sendAgencyNotificationEmail } from '@/lib/email'
import { calculateSolar } from '@/lib/calculator'
import { CITY_MAP } from '@/lib/constants'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, phone, email, city, monthlyBill, roofArea, propertyType = 'residential', financing = 'loan', preferredTime, source, message } = body

    if (!name || !phone || !city || !monthlyBill) {
      return NextResponse.json({ error: 'name, phone, city, and monthlyBill are required' }, { status: 400 })
    }

    // Calculate solar for this lead
    const cityData = CITY_MAP[city.toLowerCase().replace(' ', '-')] || CITY_MAP['noida']
    let calcResult = null
    if (cityData) {
      calcResult = calculateSolar({ monthlyBill: parseInt(monthlyBill), city: cityData, propertyType, financing, roofArea: roofArea || 200 })
    }

    // Find matching agency
    let agency = null
    try {
      agency = await db.agency.findFirst({ where: { city, isActive: true } })
    } catch {}

    // Save lead to database
    let lead = null
    try {
      lead = await db.lead.create({
        data: {
          name,
          phone,
          email: email || null,
          city,
          district: cityData?.district || city,
          monthlyBill: parseInt(monthlyBill),
          roofArea: roofArea ? parseInt(roofArea) : null,
          propertyType,
          systemSizeKw: calcResult?.systemSizeKw,
          totalCost: calcResult?.totalCost,
          subsidyAmount: calcResult?.subsidyAmount,
          netCost: calcResult?.netCost,
          paybackYears: calcResult?.paybackYears,
          financing,
          status: 'NEW',
          agencyId: agency?.id || null,
          preferredTime: preferredTime || null,
          source: source || 'website',
          message: message || null,
        },
      })
    } catch (dbError) {
      console.error('DB error (non-fatal):', dbError)
    }

    // Send emails (non-blocking)
    const emailData = {
      name,
      phone,
      email,
      city,
      monthlyBill: parseInt(monthlyBill),
      systemSizeKw: calcResult?.systemSizeKw,
      subsidyAmount: calcResult?.subsidyAmount,
      netCost: calcResult?.netCost,
      emiMonthly: calcResult?.emiMonthly,
      source: source || 'website',
    }

    Promise.allSettled([
      // 1. Customer thank you email
      email ? sendLeadConfirmationEmail(emailData) : Promise.resolve(),
      // 2. Admin notification (pankajyadi@gmail.com)
      sendAdminNotificationEmail(emailData),
      // 3. Agency notification
      agency?.email ? sendAgencyNotificationEmail(emailData, agency.email, agency.name) : Promise.resolve(),
    ]).catch(console.error)

    return NextResponse.json({
      success: true,
      leadId: lead?.id || 'temp-' + Date.now(),
      agencyName: agency?.name || null,
      agencyPhone: agency?.phone || null,
      estimate: calcResult ? {
        systemSizeKw: calcResult.systemSizeKw,
        totalCost: calcResult.totalCost,
        centralSubsidy: calcResult.centralSubsidy,
        stateSubsidy: calcResult.stateSubsidy,
        totalSubsidy: calcResult.subsidyAmount,
        netCost: calcResult.netCost,
        emiMonthly: calcResult.emiMonthly,
        annualSavings: calcResult.annualSavings,
        paybackYears: calcResult.paybackYears,
      } : null,
    })
  } catch (err) {
    console.error('Lead API error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const secret = req.headers.get('x-admin-secret')
  if (secret !== process.env.ADMIN_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  try {
    const leads = await db.lead.findMany({
      take: 200,
      orderBy: { createdAt: 'desc' },
      include: { agency: true },
    })
    return NextResponse.json({ leads, total: leads.length })
  } catch {
    return NextResponse.json({ error: 'Database error' }, { status: 500 })
  }
}
