import type { Metadata } from 'next'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import SolarCalculator from '@/components/calculator/SolarCalculator'
import { buildMetadata, getCalculatorAppSchema, getBreadcrumbSchema } from '@/lib/seo'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export const metadata: Metadata = buildMetadata({
  title: 'Solar Calculator UP 2025 | Savings, ₹1,08,000 Subsidy & EMI by Tenure',
  description: 'Free solar calculator for Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli & all West UP. Calculate ₹1,08,000 subsidy (PM Surya Ghar + UPNEDA), EMI for 5/7/10/15 year tenures, and 25-year savings. Real PVVNL tariff data.',
  path: '/calculator',
  keywords: [
    'solar calculator UP 2025',
    'solar EMI tenure calculator UP',
    'PM Surya Ghar subsidy calculator Noida',
    'solar calculator Ghaziabad Meerut Baraut',
    'solar calculator Muzaffarnagar Saharanpur',
    'PVVNL solar EMI calculator',
    'solar panel cost after subsidy UP',
    'rooftop solar calculator West UP',
  ],
})

export default function CalculatorPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getCalculatorAppSchema()) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getBreadcrumbSchema([
        { name: 'Home', url: SITE_URL },
        { name: 'Solar Calculator', url: `${SITE_URL}/calculator` },
      ]))}}/>

      <Navbar/>
      <div className="pt-16 sm:pt-20 pb-20 sm:pb-24 px-4 sm:px-6">
        <div className="max-w-[1160px] mx-auto">
          {/* Header */}
          <div className="text-center mb-10 sm:mb-14">
            <nav aria-label="Breadcrumb" className="flex items-center justify-center gap-2 text-[12px] text-[#3D5068] mb-6">
              <a href="/" className="hover:text-[#E8A020] transition-colors no-underline">Home</a>
              <span>›</span>
              <span className="text-[#94A3B8]">Solar Calculator</span>
            </nav>
            <div className="inline-flex items-center gap-2 bg-[rgba(232,160,32,.08)] border border-[rgba(232,160,32,.2)] px-4 py-2 rounded-full text-[12px] text-[#E8A020] mb-5 font-medium tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E8A020] animate-pulse"/>
              Real UP Tariff Data · Updated 2025 · 12 Cities
            </div>
            <h1 className="font-syne font-extrabold text-[clamp(28px,5vw,60px)] leading-[1.05] tracking-[-2px] mb-4">
              Free Solar Calculator<br/>
              <span className="bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">for Western UP</span>
            </h1>
            <p className="text-[15px] sm:text-[17px] text-[#64748B] max-w-[640px] mx-auto leading-relaxed">
              Enter your monthly bill and city. Get instant savings with{' '}
              <strong className="text-[#E2E8F0] font-medium">₹1,08,000 total subsidy</strong>,
              {' '}choose your EMI tenure (5–15 years), and see your 25-year returns.
              Covers Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur &amp; all West UP.
            </p>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-8 sm:mb-12">
            {[
              '✅ PVVNL tariff ₹7.5/unit',
              '🎁 ₹1,08,000 PM Surya Ghar + UPNEDA',
              '🏦 Canara/SBI @ 6.5–7%',
              '📅 Choose 5–15yr tenure',
              '📊 25-year projection',
              '🌱 CO₂ offset',
            ].map(b => (
              <span key={b} className="bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.08)] rounded-full px-3 sm:px-4 py-1.5 sm:py-2 text-[11.5px] sm:text-[12.5px] text-[#64748B]">
                {b}
              </span>
            ))}
          </div>

          <SolarCalculator/>

          {/* SEO content below fold */}
          <div className="mt-16 sm:mt-20 max-w-[760px] mx-auto">
            <h2 className="font-syne font-bold text-[22px] sm:text-[24px] text-white mb-4">How Our Solar Calculator Works</h2>
            <p className="text-[#94A3B8] text-[14px] sm:text-[15px] leading-relaxed mb-6">
              The SolarBijli solar calculator uses real electricity tariff data from PVVNL (Paschimanchal Vidyut Vitran Nigam)
              to calculate your exact solar savings across all West UP districts — from Noida and Ghaziabad to Muzaffarnagar, Saharanpur, Baraut, and Shamli.
              The residential LMV-1 tariff of ₹7.5/unit determines how much electricity your home consumes and the solar system size you need.
            </p>
            <h3 className="font-syne font-bold text-[16px] sm:text-[18px] text-white mb-3">Total Subsidy: ₹1,08,000 (Central + UP State)</h3>
            <p className="text-[#94A3B8] text-[14px] sm:text-[15px] leading-relaxed mb-4">
              Under PM Surya Ghar 2025, the central government provides up to ₹78,000 DBT subsidy.
              Additionally, UPNEDA (UP New and Renewable Energy Development Agency) adds ₹30,000 state subsidy —
              making the total <strong className="text-[#E2E8F0]">₹1,08,000 for a 3kW system</strong>.
            </p>
            <h3 className="font-syne font-bold text-[16px] sm:text-[18px] text-white mb-3">Choose Your EMI Tenure: 5, 7, 10 or 15 Years</h3>
            <p className="text-[#94A3B8] text-[14px] sm:text-[15px] leading-relaxed mb-4">
              Unlike other calculators that fix a 10-year tenure, SolarBijli lets you compare EMIs across all tenures side-by-side.
              After the ₹1,08,000 subsidy, a 3kW system costs ~₹42,000. That means EMI of just ₹638/month over 7 years
              with SBI at 7% — while saving ₹1,500–₹2,500/month on electricity. Net profit from day one.
            </p>
            <h3 className="font-syne font-bold text-[16px] sm:text-[18px] text-white mb-3">Cities Covered in West UP</h3>
            <p className="text-[#94A3B8] text-[14px] sm:text-[15px] leading-relaxed">
              Our calculator supports: <strong className="text-[#E2E8F0]">Noida, Greater Noida, Ghaziabad, Meerut, Baraut, Baghpat, Muzaffarnagar, Saharanpur, Shamli, Hapur, Bulandshahr, and Moradabad</strong>.
              Each city has accurate sun hour data (5.4–5.7 hrs/day) for precise generation estimates.
            </p>
          </div>
        </div>
      </div>
      <Footer/>
    </>
  )
}

export default function CalculatorPage() {
