import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import SolarCalculator from '@/components/calculator/SolarCalculator'
import { CITIES, CITY_MAP } from '@/lib/constants'
import { calculateSolar } from '@/lib/calculator'
import { buildMetadata, getLocalBusinessSchema, getBreadcrumbSchema, getFAQSchema } from '@/lib/seo'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export async function generateStaticParams() {
  return CITIES.map(c => ({ city: c.slug }))
}

export async function generateMetadata({ params }: { params: { city: string } }): Promise<Metadata> {
  const city = CITY_MAP[params.city]
  if (!city) return {}
  return buildMetadata({
    title: `Solar Panel Installation ${city.name} | ₹1,08,000 Subsidy | SolarBijli`,
    description: `Install solar panels in ${city.name}, ${city.district}. Get ₹1,08,000 total subsidy (PM Surya Ghar ₹78,000 + UPNEDA ₹30,000). Free site survey. MNRE certified. EMI from ₹638/month. ${city.sunHours} sun hrs/day. Payback ~${city.sunHours > 5.5 ? '4' : '4.5'} years.`,
    path: `/cities/${params.city}`,
    keywords: [
      `solar panel ${city.name}`,
      `solar installation ${city.name}`,
      `solar company ${city.name}`,
      `rooftop solar ${city.name}`,
      `solar subsidy ${city.name} 2025`,
      `PVVNL solar ${city.district}`,
      `solar panel price ${city.name} 2025`,
      `solar installer ${city.name} UP`,
      `PM Surya Ghar ${city.name}`,
    ],
  })
}

export default function CityPage({ params }: { params: { city: string } }) {
  const city = CITY_MAP[params.city]
  if (!city) notFound()

  const sampleResult = calculateSolar({
    monthlyBill: city.avgBill,
    city,
    propertyType: 'residential',
    financing: 'loan',
    roofArea: 300,
  })

  const cityFaqs = [
    {
      q: `How much does solar installation cost in ${city.name}?`,
      a: `A 3 kW solar system in ${city.name} costs approximately ₹1,50,000 before subsidy. After ₹1,08,000 total subsidy (₹78,000 PM Surya Ghar + ₹30,000 UPNEDA), your net cost is just ~₹42,000. With Canara Bank loan at 6.5%, that's only ₹638/month EMI for 7 years — far less than your electricity bill savings.`,
    },
    {
      q: `Which solar companies work in ${city.name}?`,
      a: `SolarBijli works with MNRE-empanelled solar installer partners in ${city.name}, ${city.district}. All our partners are certified, insured, and have successfully handled PM Surya Ghar + UPNEDA subsidy applications. We match you to the right partner for free.`,
    },
    {
      q: `What is the payback period for solar in ${city.name}?`,
      a: `With ${city.sunHours} peak sun hours per day and UP electricity tariff of ₹7.5/unit, a ${sampleResult.systemSizeKw} kW solar system in ${city.name} pays back in approximately ${sampleResult.paybackYears} years. After that, you get 20+ years of completely free electricity — total savings of ₹${(sampleResult.savingsOver25Years/100000).toFixed(1)} lakh.`,
    },
    {
      q: `Does PVVNL support net metering in ${city.name}?`,
      a: `Yes, PVVNL supports net metering for all grid-connected solar systems in ${city.name} and ${city.district}. Surplus solar energy exported to the grid earns credits on your next bill — bringing it to ₹0 or even negative. Our partners handle the complete net meter application with PVVNL free of charge.`,
    },
    {
      q: `How do I apply for ₹1,08,000 solar subsidy in ${city.name}?`,
      a: `You need to: 1) Register on pmsuryaghar.gov.in with your PVVNL consumer number. 2) Choose an MNRE-empanelled vendor (like our partners). 3) Get installation done. 4) PVVNL inspection + net meter. 5) ₹1,08,000 transferred to your bank in 30–60 days. Our partners in ${city.name} handle all of this at no charge.`,
    },
  ]

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getLocalBusinessSchema(city.name, city.district))}}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getFAQSchema(cityFaqs))}}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getBreadcrumbSchema([
        { name: 'Home', url: SITE_URL },
        { name: 'Cities', url: `${SITE_URL}/#cities` },
        { name: `Solar in ${city.name}`, url: `${SITE_URL}/cities/${params.city}` },
      ]))}}/>

      <Navbar/>

      <div className="pt-16 sm:pt-20">
        {/* Hero */}
        <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-16">
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-[12px] text-[#3D5068] mb-6 sm:mb-8">
            <Link href="/" className="hover:text-[#E8A020] transition-colors no-underline">Home</Link>
            <span>›</span>
            <Link href="/cities" className="hover:text-[#E8A020] transition-colors no-underline">Cities</Link>
            <span>›</span>
            <span className="text-[#94A3B8]">{city.name}</span>
          </nav>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-[rgba(232,160,32,.08)] border border-[rgba(232,160,32,.2)] px-4 py-2 rounded-full text-[12px] text-[#E8A020] mb-5 font-medium tracking-wider">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E8A020] animate-pulse"/>
                {city.district}, Uttar Pradesh
              </div>
              <h1 className="font-syne font-extrabold text-[clamp(32px,5.5vw,68px)] leading-[1.02] tracking-[-2px] mb-4">
                Solar Panels<br/>
                <span className="bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">
                  in {city.name}
                </span>
              </h1>
              <p className="text-[15px] sm:text-[17px] text-[#94A3B8] leading-[1.75] mb-6 sm:mb-8 max-w-[500px]">
                {city.description}
              </p>

              <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-6 sm:mb-8">
                {[
                  { label: 'Sun hrs/Day', value: `${city.sunHours}`, icon: '☀️' },
                  { label: 'Avg Bill/Mo', value: `₹${(city.avgBill/1000).toFixed(1)}K`, icon: '💡' },
                  { label: 'Est. Payback', value: `${sampleResult.paybackYears}yr`, icon: '⚡' },
                ].map(stat => (
                  <div key={stat.label} className="bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.07)] rounded-2xl p-3 sm:p-4 text-center">
                    <div className="text-xl sm:text-2xl mb-1.5 sm:mb-2">{stat.icon}</div>
                    <div className="font-syne font-bold text-[16px] sm:text-[18px] bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">{stat.value}</div>
                    <div className="text-[10px] sm:text-[11px] text-[#475569] mt-1 tracking-wide">{stat.label}</div>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 flex-wrap">
                <a href="#calculator" className="bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[13px] sm:text-[14px] px-6 sm:px-7 py-3 sm:py-3.5 rounded-full hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(232,160,32,.35)] transition-all no-underline tracking-wide">
                  ⚡ Calculate My Savings
                </a>
                <a href={`https://wa.me/917373734778?text=Hi! I want solar installation in ${city.name}. Please help.`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-[rgba(37,211,102,.1)] border border-[rgba(37,211,102,.25)] text-[#25D366] font-semibold text-[13px] sm:text-[14px] px-6 sm:px-7 py-3 sm:py-3.5 rounded-full hover:bg-[rgba(37,211,102,.15)] transition-all no-underline">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                  WhatsApp
                </a>
              </div>
            </div>

            {/* Sample estimate card */}
            <div className="bg-[#0D1829] border border-[rgba(232,160,32,.12)] rounded-2xl sm:rounded-3xl p-5 sm:p-8">
              <div className="text-[11px] font-bold tracking-[.13em] text-[#0EA472] uppercase flex items-center gap-1.5 mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0EA472] animate-pulse"/>
                Sample for {city.name} avg bill
              </div>
              <div className="font-syne font-extrabold text-[36px] sm:text-[44px] bg-gradient-to-r from-[#0EA472] to-[#12C882] bg-clip-text text-transparent leading-none mb-1">
                ₹{sampleResult.netCost.toLocaleString('en-IN')}
              </div>
              <p className="text-[12px] sm:text-[13px] text-[#64748B] mb-5 sm:mb-6">Net cost after ₹{sampleResult.subsidyAmount.toLocaleString('en-IN')} subsidy</p>
              <div className="grid grid-cols-2 gap-2 sm:gap-3">
                {[
                  { l: 'System Size', v: `${sampleResult.systemSizeKw} kW`, c: 'amber' },
                  { l: 'Monthly EMI', v: `₹${sampleResult.emiMonthly.toLocaleString('en-IN')}`, c: '' },
                  { l: 'Annual Savings', v: `₹${sampleResult.annualSavings.toLocaleString('en-IN')}`, c: 'green' },
                  { l: '25yr Savings', v: `₹${(sampleResult.savingsOver25Years/100000).toFixed(1)}L`, c: 'green' },
                ].map(t2 => (
                  <div key={t2.l} className="bg-[rgba(4,8,15,.6)] border border-[rgba(255,255,255,.05)] rounded-xl sm:rounded-2xl p-3 sm:p-3.5">
                    <div className="text-[10px] text-[#3D5068] mb-1 uppercase tracking-wider font-bold">{t2.l}</div>
                    <div className={`font-syne font-bold text-[15px] sm:text-[18px] ${t2.c === 'amber' ? 'text-[#E8A020]' : t2.c === 'green' ? 'text-[#12C882]' : 'text-white'}`}>{t2.v}</div>
                  </div>
                ))}
              </div>
              <div className="mt-4 bg-[rgba(5,150,105,.08)] border border-[rgba(5,150,105,.2)] rounded-xl p-3">
                <div className="text-[11px] font-bold text-[#059669] mb-1">Subsidies Available in {city.name}</div>
                <div className="text-[12px] text-[#64748B]">
                  🏛️ PM Surya Ghar: <strong className="text-[#0EA472]">₹{sampleResult.centralSubsidy.toLocaleString('en-IN')}</strong><br/>
                  🏗️ UPNEDA State: <strong className="text-[#0EA472]">₹{sampleResult.stateSubsidy.toLocaleString('en-IN')}</strong><br/>
                  ✅ Total: <strong className="text-[#0EA472] text-[13px]">₹{sampleResult.subsidyAmount.toLocaleString('en-IN')}</strong> → Bank transfer
                </div>
              </div>
              <p className="text-[10.5px] text-[#2D3748] mt-3 text-center">* Based on {city.sunHours} hrs/day sun, ₹7.5/unit PVVNL tariff</p>
            </div>
          </div>
        </section>

        {/* Calculator */}
        <section id="calculator" className="px-4 sm:px-6 py-10 sm:py-12 bg-[rgba(7,13,26,.5)]">
          <div className="max-w-[1160px] mx-auto">
            <h2 className="font-syne font-bold text-[22px] sm:text-[28px] text-white mb-2 text-center">Calculate Your Exact Savings in {city.name}</h2>
            <p className="text-[#64748B] text-[13px] sm:text-[15px] text-center mb-8 sm:mb-10">Adjust to your actual bill and choose your preferred EMI tenure.</p>
            <SolarCalculator/>
          </div>
        </section>

        {/* City-specific content */}
        <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-16">
          <h2 className="font-syne font-bold text-[clamp(20px,3.5vw,40px)] text-white mb-6 sm:mb-8">
            Solar Energy in {city.name}: Complete Guide
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6">
            <div className="lg:col-span-2 space-y-4 sm:space-y-6 text-[14px] sm:text-[15px] text-[#64748B] leading-[1.8]">
              <p>
                <strong className="text-[#E2E8F0]">{city.name}, {city.district}</strong> is one of the most solar-suitable locations
                in Uttar Pradesh. With an average of <strong className="text-[#E8A020]">{city.sunHours} peak sun hours per day</strong>,
                rooftop solar systems in {city.name} generate 15–20% more electricity compared to national averages.
              </p>
              <p>
                The average monthly electricity bill of <strong className="text-[#E2E8F0]">₹{city.avgBill.toLocaleString('en-IN')}</strong> for
                a {city.name} home translates to a <strong className="text-[#E8A020]">{sampleResult.systemSizeKw} kW solar system</strong> that
                can offset 80–100% of your electricity consumption. With the ₹1,08,000 total subsidy (PM Surya Ghar + UPNEDA) applied,
                the net investment of ₹{sampleResult.netCost.toLocaleString('en-IN')} pays back in just {sampleResult.paybackYears} years.
              </p>
              <p>
                PVVNL (Paschimanchal Vidyut Vitran Nigam Limited) serves {city.name} and supports net metering for all approved
                rooftop solar installations. This means surplus electricity generated by your solar panels is credited back to
                your account, reducing future bills — or even creating credits that carry forward month to month.
              </p>
            </div>
            <div className="space-y-3">
              <div className="bg-[rgba(232,160,32,.06)] border border-[rgba(232,160,32,.15)] rounded-2xl p-4 sm:p-5">
                <h3 className="font-syne font-bold text-white text-[14px] sm:text-[15px] mb-3">{city.name} Solar Facts</h3>
                <ul className="space-y-2 text-[12.5px] sm:text-[13.5px] text-[#64748B]">
                  <li>☀️ {city.sunHours} peak sun hrs/day</li>
                  <li>📍 {city.district}, West UP</li>
                  <li>⚡ PVVNL tariff: ₹7.5/unit</li>
                  <li>🎁 Max subsidy: <strong className="text-[#E8A020]">₹1,08,000</strong></li>
                  <li>📅 Payback: ~{sampleResult.paybackYears} years</li>
                  <li>🌱 CO₂ saved: {sampleResult.co2OffsetKgPerYear.toLocaleString('en-IN')} kg/yr</li>
                  <li>💳 Min EMI: from ₹638/month</li>
                </ul>
              </div>
              <div className="bg-[rgba(5,150,105,.06)] border border-[rgba(5,150,105,.15)] rounded-2xl p-4 sm:p-5">
                <h3 className="font-syne font-bold text-white text-[14px] mb-2">Quick Actions</h3>
                <div className="space-y-2">
                  <a href="#calculator" className="block w-full text-center bg-[#4F46E5] text-white text-[13px] font-semibold py-2.5 rounded-xl hover:bg-[#4338CA] transition-colors no-underline">Calculate Savings</a>
                  <a href="/calculator" className="block w-full text-center bg-transparent border border-[#4F46E5] text-[#818CF8] text-[13px] font-semibold py-2.5 rounded-xl hover:bg-[#4F46E5] hover:text-white transition-colors no-underline">Full Calculator</a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* City FAQ */}
        <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8 mb-8 sm:mb-10">
          <h2 className="font-syne font-bold text-[22px] sm:text-[28px] text-white mb-6 sm:mb-8">
            Solar FAQs for {city.name}
          </h2>
          <div className="max-w-[760px] space-y-2.5 sm:space-y-3">
            {cityFaqs.map((faq, i) => (
              <details key={i} className="bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.06)] rounded-2xl overflow-hidden group hover:border-[rgba(232,160,32,.15)] transition-colors">
                <summary className="px-4 sm:px-5 py-3.5 sm:py-4 cursor-pointer flex justify-between items-center gap-3 text-[13.5px] sm:text-[14.5px] font-medium text-[#E2E8F0] list-none [&::-webkit-details-marker]:hidden">
                  {faq.q}
                  <span className="w-6 h-6 rounded-full bg-[rgba(232,160,32,.1)] flex items-center justify-center text-[#E8A020] text-sm flex-shrink-0 transition-transform group-open:rotate-90">›</span>
                </summary>
                <p className="px-4 sm:px-5 pb-4 text-[#94A3B8] text-[13px] sm:text-[13.5px] leading-[1.75]">{faq.a}</p>
              </details>
            ))}
          </div>
        </section>
      </div>

      <Footer/>
    </>
  )
}
