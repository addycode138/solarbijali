import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'
import { CITIES } from '@/lib/constants'
import { calculateSolar } from '@/lib/calculator'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Solar Panels in West UP | Noida, Ghaziabad, Meerut, Muzaffarnagar, Saharanpur & 12 Cities | SolarBijli',
  description: 'Solar panel installation across 12 West UP districts — Noida, Ghaziabad, Meerut, Baraut, Baghpat, Muzaffarnagar, Saharanpur, Shamli, Hapur, Bulandshahr, Moradabad. MNRE certified. ₹1,08,000 total subsidy.',
  alternates: { canonical: `${SITE_URL}/cities` },
  keywords: ['solar panel West UP', 'solar Noida Ghaziabad Meerut', 'solar Muzaffarnagar Saharanpur Baraut', 'solar panel 12 cities UP', 'PVVNL solar installation'],
}
export default function CitiesPage() {
  return (<>
    <Navbar/>
    <PageHeader
      tag="Our Coverage"
      h1="Solar Installation Across 12 West UP Districts"
      desc="MNRE-certified installers in all major PVVNL cities — from Noida to Saharanpur. Full subsidy support, net metering, free site survey."
      breadcrumb={[{href:'/',label:'Home'},{href:'/cities',label:'Cities'}]}
    />
    <div className="max-w-[1280px] mx-auto px-4 sm:px-5 py-10 sm:py-14">

      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10">
        {[
          {n:'12',l:'Districts Covered'},
          {n:'₹1,08,000',l:'Max Subsidy'},
          {n:'500+',l:'Installations Done'},
          {n:'5.4–5.7',l:'Sun hrs/day'},
        ].map(s=>(
          <div key={s.l} className="bg-[#EEF2FF] border border-[#C7D2FE] rounded-xl p-4 text-center">
            <div className="font-extrabold text-[20px] sm:text-[24px] text-[#4F46E5]">{s.n}</div>
            <div className="text-[11px] text-[#6366F1] mt-0.5 font-medium">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {CITIES.map(city => {
          const r = calculateSolar({ monthlyBill: city.avgBill, city, propertyType:'residential', financing:'loan', roofArea:200 })
          return (
            <Link key={city.slug} href={`/cities/${city.slug}`}
              className="bg-white border border-[#E2E8F0] rounded-2xl p-5 sm:p-7 hover:border-[#4F46E5] hover:shadow-xl transition-all block no-underline text-inherit group">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h2 className="font-extrabold text-[18px] sm:text-[20px] text-[#0F172A] tracking-tight mb-0.5">{city.name}</h2>
                  <p className="text-[12px] text-[#94A3B8]">{city.district}, UP</p>
                </div>
                <span className="text-[11px] bg-[#ECFDF5] text-[#047857] px-2.5 py-1 rounded-full font-semibold flex-shrink-0">Active ✓</span>
              </div>
              <p className="text-[13px] text-[#64748B] leading-relaxed mb-4 line-clamp-2">{city.description}</p>
              <div className="grid grid-cols-4 gap-2 mb-4">
                {[
                  {l:'Sun', v:`${city.sunHours}h`},
                  {l:'Avg Bill', v:`₹${(city.avgBill/1000).toFixed(1)}K`},
                  {l:'System', v:`${r.systemSizeKw}kW`},
                  {l:'Payback', v:`${r.paybackYears}yr`},
                ].map(m=>(
                  <div key={m.l} className="text-center bg-[#F8FAFC] rounded-lg py-2">
                    <div className="font-extrabold text-[13px] sm:text-[14px] text-[#4F46E5]">{m.v}</div>
                    <div className="text-[9.5px] sm:text-[10.5px] text-[#94A3B8] mt-0.5">{m.l}</div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-[#F1F5F9]">
                <span className="text-[12px] sm:text-[13px] text-[#64748B]">
                  After subsidy: <strong className="text-[#059669]">~₹{r.netCost.toLocaleString('en-IN')}</strong>
                </span>
                <span className="text-[#4F46E5] font-semibold text-[13px] group-hover:translate-x-1 transition-transform">View →</span>
              </div>
            </Link>
          )
        })}
      </div>

      {/* SEO text section */}
      <div className="mt-14 max-w-[760px]">
        <h2 className="text-[20px] sm:text-[22px] font-extrabold text-[#0F172A] mb-4">Solar Panel Installation Across West Uttar Pradesh</h2>
        <p className="text-[14px] sm:text-[15px] text-[#64748B] leading-relaxed mb-4">
          SolarBijli&apos;s MNRE-certified installer network covers all 12 major districts of Western UP under the PVVNL grid.
          Whether you&apos;re in a Noida high-rise, a Ghaziabad township, Meerut residential colony, Baraut market, Muzaffarnagar farmhouse,
          or Saharanpur workshop — our partners handle everything: site survey, PM Surya Ghar portal registration, installation, and net metering.
        </p>
        <p className="text-[14px] sm:text-[15px] text-[#64748B] leading-relaxed">
          West UP receives 5.4–5.7 peak sun hours per day, making it one of India&apos;s best regions for rooftop solar ROI.
          With ₹1,08,000 in combined PM Surya Ghar + UPNEDA subsidy, most 3kW systems cost just ₹42,000 net —
          and pay back in under 5 years.
        </p>
      </div>
    </div>
    <CtaBanner/>
    <Footer/>
  </>)
}
    <CtaBanner/>
    <Footer/>
  </>)
}
