import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'About SolarBijli | UP Solar Platform | MNRE Certified | Our Mission',
  description: 'SolarBijli is UP\'s most trusted solar energy platform connecting homeowners with MNRE-certified installers. Learn about our mission to make solar accessible in Uttar Pradesh.',
  alternates: { canonical: `${SITE_URL}/about` },
}
export default function AboutPage() {
  return (<>
    <Navbar/>
    <PageHeader tag="Our Story" h1="About SolarBijli" desc="Making solar energy accessible to every UP household through transparent information, verified installers, and full subsidy support." breadcrumb={[{href:'/',label:'Home'},{href:'/about',label:'About Us'}]}/>
    <div className="max-w-[1280px] mx-auto px-5 py-14 grid grid-cols-1 lg:grid-cols-3 gap-8">
      <article className="lg:col-span-2 prose-solar">
        <h2>Our Mission</h2>
        <p>SolarBijli was founded with a single mission: <strong>make solar energy simple, affordable, and transparent for every household in Uttar Pradesh</strong>. With India's highest combined solar subsidy of ₹1,08,000 available in UP, we believe every homeowner deserves access to clean energy — without confusion, without middlemen, and without surprise costs.</p>
        <h2>What We Do</h2>
        <p>SolarBijli is not an installer. We are a solar <strong>matchmaking and advisory platform</strong>. We connect UP homeowners with pre-verified, MNRE-empanelled solar installation companies in their city. Our value:</p>
        <ul>
          <li><strong>Accurate, research-backed information</strong> — every subsidy figure, tariff rate, and loan rate on our platform is verified from official sources</li>
          <li><strong>Free solar calculator</strong> — using real PVVNL/UPPCL tariff data and official MNRE benchmark pricing</li>
          <li><strong>Vetted installer network</strong> — all partners are MNRE-empanelled and have verified track records</li>
          <li><strong>Full subsidy support</strong> — we guide you through PM Surya Ghar + UPNEDA paperwork at no extra charge</li>
        </ul>
        <h2>Our Values</h2>
        <ul>
          <li><strong>Transparency:</strong> We show you actual government data — never inflated savings or false claims</li>
          <li><strong>Accuracy:</strong> All information is updated regularly from official MNRE, UPNEDA, and PVVNL sources</li>
          <li><strong>Customer First:</strong> We never take commissions that inflate your installation cost. Our partner fees are transparent.</li>
        </ul>
        <h2>Our Coverage</h2>
        <p>We serve <strong>12 districts in Western Uttar Pradesh</strong>: <Link href="/cities/noida" className="text-[#4F46E5] hover:underline">Noida</Link>, <Link href="/cities/greater-noida" className="text-[#4F46E5] hover:underline">Greater Noida</Link>, <Link href="/cities/ghaziabad" className="text-[#4F46E5] hover:underline">Ghaziabad</Link>, <Link href="/cities/meerut" className="text-[#4F46E5] hover:underline">Meerut</Link>, <Link href="/cities/baraut" className="text-[#4F46E5] hover:underline">Baraut</Link>, <Link href="/cities/baghpat" className="text-[#4F46E5] hover:underline">Baghpat</Link>, <Link href="/cities/muzaffarnagar" className="text-[#4F46E5] hover:underline">Muzaffarnagar</Link>, <Link href="/cities/saharanpur" className="text-[#4F46E5] hover:underline">Saharanpur</Link>, <Link href="/cities/shamli" className="text-[#4F46E5] hover:underline">Shamli</Link>, <Link href="/cities/hapur" className="text-[#4F46E5] hover:underline">Hapur</Link>, <Link href="/cities/bulandshahr" className="text-[#4F46E5] hover:underline">Bulandshahr</Link>, and <Link href="/cities/moradabad" className="text-[#4F46E5] hover:underline">Moradabad</Link>. We are continuously expanding our PVVNL-registered installer network across all UP districts.</p>
        <h2>Contact Us</h2>
        <p>📞 <a href="tel:7373734778" className="text-[#4F46E5] hover:underline">+91 73737 34778</a> | 📧 <a href="mailto:pankajyadi@gmail.com" className="text-[#4F46E5] hover:underline">pankajyadi@gmail.com</a></p>
      </article>
      <aside className="space-y-4">
        <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5">
          <h3 className="font-bold text-[16px] text-[#0F172A] mb-4">Quick Stats</h3>
          {[{n:'500+',l:'Installations'},{n:'₹2Cr+',l:'Subsidy Disbursed'},{n:'4 Cities',l:'UP Coverage'},{n:'4.9★',l:'Customer Rating'}].map(s=>(
            <div key={s.l} className="flex justify-between items-center py-2.5 border-b border-[#E2E8F0] last:border-0">
              <span className="text-[14px] text-[#64748B]">{s.l}</span>
              <span className="font-extrabold text-[16px] text-[#4F46E5]">{s.n}</span>
            </div>
          ))}
        </div>
        <Link href="/contact" className="block bg-[#4F46E5] text-white text-center font-bold text-[15px] py-4 rounded-xl hover:bg-[#4338CA] transition-all no-underline">Get Free Consultation →</Link>
      </aside>
    </div>
    <CtaBanner/>
    <Footer/>
  </>)
}
