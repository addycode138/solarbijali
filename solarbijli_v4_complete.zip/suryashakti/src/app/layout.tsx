import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { I18nProvider } from '@/lib/i18n/context'
import CalcPopupProvider from '@/components/calculator/CalcPopupProvider'
import PopupManager from '@/components/ui/PopupManager'
import WhatsAppButton from '@/components/ui/WhatsAppButton'
import Chatbot from '@/components/chatbot/Chatbot'
import AnnouncementBar from '@/components/ui/AnnouncementBar'
import { getOrganizationSchema, getWebsiteSchema } from '@/lib/seo'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
  preload: true,
})

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
const GTM = process.env.NEXT_PUBLIC_GTM_ID

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: 'SolarBijli — Solar Panels UP | ₹1,08,000 Subsidy | Free Calculator', template: '%s | SolarBijli' },
  description: 'Install solar panels in Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli, Hapur, Bulandshahr & all West UP. Get ₹1,08,000 total subsidy (Central ₹78,000 + UP State ₹30,000). Free solar calculator. MNRE certified installers. Call 7373734778.',
  keywords: ['solar panel Noida', 'solar panel Ghaziabad', 'solar panel Meerut', 'solar panel Muzaffarnagar', 'solar panel Saharanpur', 'solar panel Baraut Baghpat', 'PM Surya Ghar UP', 'UPNEDA subsidy 2025', 'solar subsidy UP 2025', '₹1,08,000 solar subsidy', 'SolarBijli', 'solar calculator UP', 'net metering PVVNL', 'solar EMI 638 per month'],
  authors: [{ name: 'SolarBijli', url: SITE_URL }],
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 } },
  openGraph: { type: 'website', locale: 'en_IN', alternateLocale: ['hi_IN'], siteName: 'SolarBijli' },
  twitter: { card: 'summary_large_image', site: '@solarbijli' },
  other: { 'theme-color': '#4F46E5', 'msapplication-TileColor': '#0F172A', 'mobile-web-app-capable': 'yes', 'apple-mobile-web-app-capable': 'yes', 'apple-mobile-web-app-status-bar-style': 'default', 'geo.region': 'IN-UP', 'geo.placename': 'Uttar Pradesh, India', 'ICBM': '28.6139, 77.2090' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="dns-prefetch" href="//www.googletagmanager.com" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getOrganizationSchema()) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getWebsiteSchema()) }} />
        {GTM && <script dangerouslySetInnerHTML={{ __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${GTM}');` }} />}
        <style dangerouslySetInnerHTML={{ __html: `@keyframes popIn{from{opacity:0;transform:scale(.88) translateY(14px)}to{opacity:1;transform:scale(1) translateY(0)}} @keyframes bgShift{0%{background-position:0%}100%{background-position:200%}}` }} />
      </head>
      <body className="bg-[#F8FAFC] text-[#0F172A] antialiased font-[family-name:var(--font-inter)]">
        {GTM && <noscript><iframe src={`https://www.googletagmanager.com/ns.html?id=${GTM}`} height="0" width="0" style={{ display: 'none', visibility: 'hidden' }} /></noscript>}
        <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[999] focus:px-4 focus:py-2 focus:bg-[#4F46E5] focus:text-white focus:rounded-lg text-sm font-bold">
          Skip to main content
        </a>
        <I18nProvider>
          <CalcPopupProvider>
            <AnnouncementBar />
            <div id="main-content">
              {children}
            </div>
            <WhatsAppButton />
            <Chatbot />
            <PopupManager />
          </CalcPopupProvider>
        </I18nProvider>
      </body>
    </html>
  )
}
