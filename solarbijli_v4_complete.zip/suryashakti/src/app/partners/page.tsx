import type { Metadata } from 'next'
import Link from 'next/link'
import { Shield, Star, MapPin, Phone, ArrowRight } from 'lucide-react'
import SiteLayout from '@/components/layout/SiteLayout'
import Section, { SectionHeading } from '@/components/ui/Section'
import { CITIES } from '@/lib/constants'

export const metadata: Metadata = {
  title: 'Solar Agency Partners in Uttar Pradesh | SolarBijli',
  description: 'SolarBijli certified solar installer partners across 12 West UP districts. MNRE empanelled, government registered, 5-year warranty.',
}

const partnerBenefits = [
  { icon: '🔆', title: 'Qualified leads only', desc: 'Every lead has already calculated their system size and is ready to buy. No tyre-kickers.' },
  { icon: '📋', title: 'Lead details provided', desc: 'Bill amount, city, system size, financing preference — all shared before you call.' },
  { icon: '🏛️', title: 'MNRE empanelment support', desc: 'We help new partners get government empanelment needed for subsidy installations.' },
  { icon: '📈', title: 'Marketing done for you', desc: 'We handle SEO, ads, and content. You focus on installations and closing deals.' },
]

export default function PartnersPage() {
  return (
    <SiteLayout>
      <div className="pt-20">
        {/* Partner listing */}
        <Section>
          <SectionHeading
            badge="Our Network"
            title="Certified Solar"
            highlight="Partners"
            description="Every SolarBijli partner is MNRE-empanelled, government-registered, and has passed our quality and service standards."
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
            {CITIES.map((city) => (
              <div key={city.slug} className="card-dark-solid rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-leaf" />
                  <span className="text-leaf text-xs font-medium">Active</span>
                </div>
                <MapPin className="w-5 h-5 text-sun mb-2" />
                <h3 className="font-syne font-700 text-white mb-0.5">{city.name}</h3>
                <p className="text-slate-400 text-xs mb-3">{city.district}</p>
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-3 h-3 fill-sun text-sun" />)}
                  <span className="text-slate-400 text-xs ml-1">Certified</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Shield className="w-3.5 h-3.5 text-leaf" />
                  MNRE Empanelled
                </div>
              </div>
            ))}
          </div>

          {/* Partner application */}
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sun bg-sun/10 border border-sun/20 px-3 py-1 rounded-full mb-4">
                Become a Partner
              </span>
              <h2 className="font-syne font-700 text-3xl text-white mb-4">
                Grow Your Solar Business With <span className="text-sun">SolarBijli</span>
              </h2>
              <p className="text-slate-400 leading-relaxed mb-6">
                We're looking for certified solar installers across UP to join our network. We bring you
                qualified leads — you do what you do best.
              </p>
              <div className="space-y-4 mb-8">
                {partnerBenefits.map((b) => (
                  <div key={b.title} className="flex gap-4">
                    <span className="text-2xl w-8 shrink-0">{b.icon}</span>
                    <div>
                      <p className="text-white font-medium text-sm">{b.title}</p>
                      <p className="text-slate-400 text-sm">{b.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Phone className="w-4 h-4" />
                Call us: <a href="tel:+919876543200" className="text-sun hover:underline">+91 98765 43200</a>
              </div>
            </div>

            {/* Application form */}
            <div className="card-dark-solid rounded-2xl p-7">
              <h3 className="font-syne font-700 text-white text-lg mb-6">Apply to Join Our Network</h3>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="label-dark">Company / Agency Name</label>
                  <input className="input-dark" placeholder="SolarTech Noida Pvt Ltd" />
                </div>
                <div>
                  <label className="label-dark">Contact Person</label>
                  <input className="input-dark" placeholder="Full name" />
                </div>
                <div>
                  <label className="label-dark">Mobile Number</label>
                  <input className="input-dark" placeholder="10-digit number" />
                </div>
                <div>
                  <label className="label-dark">Email</label>
                  <input className="input-dark" type="email" placeholder="info@company.in" />
                </div>
                <div>
                  <label className="label-dark">City / Cities You Cover</label>
                  <input className="input-dark" placeholder="e.g. Noida, Greater Noida" />
                </div>
                <div>
                  <label className="label-dark">MNRE Registration Number (if available)</label>
                  <input className="input-dark" placeholder="Optional" />
                </div>
                <button type="submit" className="w-full bg-sun text-sky-950 font-syne font-700 py-3 rounded-xl hover:bg-sun-300 transition-colors flex items-center justify-center gap-2">
                  Submit Application <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </Section>
      </div>
    </SiteLayout>
  )
}
