import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export const metadata: Metadata = {
  title: 'Solar Panel Installation Process in UP — Step by Step | SolarBijli',
  description: 'Complete step-by-step solar panel installation process in Uttar Pradesh. From site survey to net metering to ₹1,08,000 subsidy in your bank. Timeline: 45–60 days.',
  keywords: ['solar installation process UP', 'how to install solar panels UP', 'solar installation timeline India', 'PVVNL net meter process', 'PM Surya Ghar installation'],
  alternates: { canonical: `${SITE_URL}/solar-installation-process` },
}

const howToSchema = {
  '@context': 'https://schema.org',
  '@type': 'HowTo',
  name: 'How to Install Rooftop Solar Panels in Uttar Pradesh and Get ₹1,08,000 Subsidy',
  description: 'Complete step-by-step guide to install rooftop solar in UP and claim PM Surya Ghar + UPNEDA subsidy',
  totalTime: 'P60D',
  estimatedCost: { '@type': 'MonetaryAmount', currency: 'INR', value: '42000' },
  supply: [
    { '@type': 'HowToSupply', name: 'Aadhaar Card' },
    { '@type': 'HowToSupply', name: 'Electricity bill with consumer number' },
    { '@type': 'HowToSupply', name: 'Bank account (Aadhaar linked)' },
    { '@type': 'HowToSupply', name: 'Rooftop with adequate space' },
  ],
  step: [
    { '@type': 'HowToStep', name: 'Calculate requirements & get quote', text: 'Use SolarBijli solar calculator to determine system size. Get a free quote from MNRE-empanelled installer.', url: `${SITE_URL}/calculator` },
    { '@type': 'HowToStep', name: 'Register on PM Surya Ghar portal', text: 'Register at pmsuryaghar.gov.in with your PVVNL/UPPCL consumer number.' },
    { '@type': 'HowToStep', name: 'Free site survey', text: 'Installer visits your home for roof assessment, shade analysis, and electrical load calculation.' },
    { '@type': 'HowToStep', name: 'Solar installation', text: 'Panels, inverter, mounting structure installed in 2–3 days by MNRE-certified team.' },
    { '@type': 'HowToStep', name: 'Net meter & commissioning', text: 'PVVNL/UPPCL installs bidirectional net meter (15–30 days) and issues commissioning certificate.' },
    { '@type': 'HowToStep', name: 'Receive ₹1,08,000 subsidy', text: 'Central subsidy ₹78,000 credited (then UP state ₹30,000) in ~30 days. UPNEDA state subsidy ₹30,000 follows in 2–4 weeks.' },
  ],
}

const steps = [
  {
    phase: 'Phase 1: Planning',
    num: '01', day: 'Day 1', icon: '🧮',
    title: 'Calculate Your Requirements',
    desc: 'Use SolarBijli\'s solar calculator to determine your system size based on monthly electricity bill. For a ₹2,500/month bill, you need approximately 2.5–3 kW. For ₹3,500/month, approximately 3.5–4 kW.',
    actions: ['Enter monthly bill in calculator', 'Choose your city (Noida/Meerut/etc.)', 'View subsidy & EMI breakdown', 'Request free quote'],
    tip: 'Most UP homes with bills of ₹1,500–₹4,000/month get 3kW systems — perfect to maximise the ₹1,08,000 subsidy.',
  },
  {
    phase: 'Phase 1: Planning',
    num: '02', day: 'Day 1–3', icon: '🌐',
    title: 'Register on PM Surya Ghar Portal',
    desc: 'Visit pmsuryaghar.gov.in and register using your mobile number and PVVNL/UPPCL consumer number. This is mandatory to claim the government subsidy.',
    actions: ['Visit pmsuryaghar.gov.in', 'Register with mobile + consumer number', 'Select state: Uttar Pradesh', 'Select DISCOM: PVVNL/UPPCL'],
    tip: 'Our partners help you complete portal registration during the site survey — you don\'t need to navigate this alone.',
  },
  {
    phase: 'Phase 2: Survey & Design',
    num: '03', day: 'Day 2–5', icon: '🏠',
    title: 'Free Site Survey by MNRE Engineer',
    desc: 'An MNRE-certified engineer visits your home to assess: roof area and orientation, shading analysis, roof structural integrity, electrical load and current connection, best panel placement for maximum generation.',
    actions: ['Roof measurement & shade analysis', 'Electrical load assessment', 'System design & layout', 'Detailed quotation with subsidy breakdown'],
    tip: 'South-facing rooftop at 15–30° tilt gives best results in UP. Even east-west or flat roofs work well with proper mounting.',
  },
  {
    phase: 'Phase 2: Survey & Design',
    num: '04', day: 'Day 5–10', icon: '📋',
    title: 'Vendor Registration & Loan Application',
    desc: 'The installer registers as your chosen vendor on the PM Surya Ghar national portal. If you\'re taking a bank loan, apply through jansamarth.in. The bank disburses funds directly to the installer.',
    actions: ['Vendor selected on PM Surya Ghar portal', 'Loan application on jansamarth.in (if needed)', 'Bank reviews & approves (usually 3–5 days)', 'Loan disbursed to installer'],
    tip: 'SBI, Canara Bank, PNB, Union Bank all offer 7% loans with no collateral up to ₹2L. Apply on JanSamarth.in.',
  },
  {
    phase: 'Phase 3: Installation',
    num: '05', day: 'Day 10–14', icon: '⚡',
    title: 'Solar Panel Installation',
    desc: 'Installation typically takes 2–3 working days depending on system size. The certified team installs: mounting structure (GI/aluminium), solar panels (MNRE-approved ALMM listed), grid-tied inverter, AC/DC cables & conduits, safety equipment (MCB, isolators, earthing).',
    actions: ['Mounting structure installation', 'Solar panel placement & wiring', 'Inverter & protection equipment', 'Earthing & safety checks', 'Internal wiring to main DB'],
    tip: 'All equipment must be ALMM (Approved List of Models and Manufacturers) listed by MNRE — our partners only use approved brands.',
  },
  {
    phase: 'Phase 3: Installation',
    num: '06', day: 'Day 14–16', icon: '✅',
    title: 'System Testing & Documentation',
    desc: 'After installation, the engineer tests the complete system: panel output testing, inverter commissioning, safety equipment verification, performance monitoring setup, and documentation for portal submission.',
    actions: ['Full system performance test', 'Photos of installation uploaded to portal', 'Plant commissioning report prepared', 'Net meter application filed with PVVNL'],
    tip: 'A well-functioning 3kW system in UP should generate 420–500 units/month in peak summer. Our partners provide performance monitoring.',
  },
  {
    phase: 'Phase 4: Grid Connection',
    num: '07', day: 'Day 15–45', icon: '🔌',
    title: 'PVVNL Net Meter Installation',
    desc: 'After installation, the installer files a net metering application with PVVNL/UPPCL. DISCOM conducts an inspection and replaces your old meter with a bidirectional smart meter. This is the most time-sensitive step.',
    actions: ['Net meter application filed', 'PVVNL inspection scheduled (10–20 days)', 'Bidirectional meter installed', 'Commissioning certificate issued'],
    tip: 'Our partners have established relationships with PVVNL officers across all 12 West UP cities to expedite this process.',
  },
  {
    phase: 'Phase 5: Subsidy',
    num: '08', day: 'Day 30–45', icon: '💰',
    title: 'Subsidies to Your Bank (₹1,08,000 total)',
    desc: 'After the commissioning certificate is uploaded on the PM Surya Ghar portal, MNRE reviews and approves. The Central Financial Assistance (CFA) of ₹78,000 is transferred directly to your Aadhaar-linked bank account via DBT.',
    actions: ['Commissioning certificate uploaded', 'MNRE review & approval', 'CFA of ₹78,000 + UPNEDA ₹30,000 transferred via DBT', 'Credit confirmation SMS received'],
    tip: 'Use the ₹1,08,000 total subsidy to make a part-prepayment on your bank loan immediately — this reduces your EMI significantly.',
  },
  {
    phase: 'Phase 5: Subsidy',
    num: '09', day: 'Day 45–65', icon: '🏛️',
    title: 'UPNEDA State Subsidy (₹30,000)',
    desc: 'The UP State Government (UPNEDA) releases an additional ₹30,000 subsidy automatically after the central CFA is credited. No separate application is needed. UPNEDA processes this based on the central subsidy data.',
    actions: ['Central CFA confirmed with UPNEDA', 'UPNEDA processes state subsidy', '₹30,000 credited to bank account', 'Total received: ₹1,08,000'],
    tip: 'Keep your bank account documents handy. If you don\'t receive UPNEDA subsidy within 60 days of CFA, contact UPNEDA at upneda.org.in.',
  },
  {
    phase: 'Phase 6: Enjoy!',
    num: '10', day: 'Month 2+', icon: '🌟',
    title: 'Start Saving & Earning from Solar',
    desc: 'Your solar system is operational. Your PVVNL bill now shows both imports (from grid) and exports (to grid). Monthly savings typically range from ₹1,500 to ₹3,500 depending on your consumption and system size.',
    actions: ['Monitor generation via inverter app', 'Review monthly net metering bill', 'Annual maintenance check (free, 2 years)', 'Track savings vs old electricity bills'],
    tip: 'A 3kW system generates ~420 units/month in UP. If you use 300 units, you export 120 units — those are credited at ₹7.5/unit.',
  },
]

export default function InstallationProcessPage() {
  const phases = [...new Set(steps.map(s => s.phase))]

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(howToSchema) }} />
      <Navbar />

      <PageHeader
        tag="Complete Installation Guide"
        h1="Solar Panel Installation Process in UP — Step by Step (2025)"
        desc="From enquiry to ₹1,08,000 subsidy in your bank — the complete 10-step journey. Typically 45–60 days end-to-end."
        breadcrumb={[{ href: '/', label: 'Home' }, { href: '/solar-installation-process', label: 'Installation Process' }]}
      />

      {/* Timeline overview */}
      <div className="bg-white border-b border-[#E2E8F0] py-10 px-5">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            {[
              { d: 'Day 1', l: 'Calculate & Quote' },
              { d: 'Day 2–5', l: 'Site Survey' },
              { d: 'Day 10–14', l: 'Installation' },
              { d: 'Day 15–45', l: 'Net Meter' },
              { d: 'Day 30–45', l: '₹78K Subsidy' },
              { d: 'Day 45–65', l: '₹30K Subsidy' },
            ].map((t, i) => (
              <div key={t.d} className="text-center">
                <div className="w-10 h-10 rounded-full bg-[#4F46E5] text-white text-[13px] font-bold flex items-center justify-center mx-auto mb-2">{i + 1}</div>
                <div className="text-[11px] font-bold text-[#4F46E5]">{t.d}</div>
                <div className="text-[12px] text-[#64748B] mt-0.5">{t.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-5 py-14">
        {phases.map(phase => (
          <div key={phase} className="mb-10">
            <div className="inline-flex items-center gap-2 text-[12px] font-bold tracking-[.08em] text-[#4F46E5] uppercase mb-5">
              <span className="w-4 h-[2px] bg-[#4F46E5] rounded" />
              {phase}
            </div>
            <div className="space-y-5">
              {steps.filter(s => s.phase === phase).map(step => (
                <div key={step.num} className="bg-white border border-[#E2E8F0] rounded-2xl p-7 hover:border-[#4F46E5] hover:shadow-md transition-all">
                  <div className="flex flex-col md:flex-row md:items-start gap-5">
                    <div className="flex items-center gap-3 md:flex-col md:items-center md:text-center md:w-[80px] flex-shrink-0">
                      <div className="w-12 h-12 rounded-full bg-[#EEF2FF] flex items-center justify-center text-2xl">{step.icon}</div>
                      <div>
                        <div className="text-[11px] font-black text-[#4F46E5] tracking-wider">STEP {step.num}</div>
                        <div className="text-[11px] text-[#94A3B8]">{step.day}</div>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h2 className="text-[18px] font-extrabold text-[#0F172A] mb-2 tracking-tight">{step.title}</h2>
                      <p className="text-[14.5px] text-[#475569] leading-relaxed mb-4">{step.desc}</p>
                      <div className="grid grid-cols-2 gap-1.5 mb-4">
                        {step.actions.map(a => (
                          <div key={a} className="flex items-center gap-2 text-[13px] text-[#475569]">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#059669] flex-shrink-0" />
                            {a}
                          </div>
                        ))}
                      </div>
                      <div className="bg-[#FFFBEB] border border-[#FDE68A] rounded-xl px-4 py-3">
                        <p className="text-[13px] text-[#92400E]"><span className="font-bold">💡 Expert Tip: </span>{step.tip}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Documents checklist */}
        <div className="bg-[#EEF2FF] border border-[#C7D2FE] rounded-2xl p-7 mb-10">
          <h2 className="text-[22px] font-extrabold text-[#0F172A] mb-4 tracking-tight">Documents Checklist</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              { icon: '🪪', title: 'Aadhaar Card', desc: 'Identity proof, must be mobile-linked for DBT' },
              { icon: '💡', title: 'Latest Electricity Bill', desc: 'With consumer number clearly visible' },
              { icon: '🏦', title: 'Bank Account Details', desc: 'Aadhaar-linked account for subsidy transfer' },
              { icon: '📸', title: 'Passport Photo', desc: 'For vendor registration (some cases)' },
              { icon: '🏠', title: 'Property Documents', desc: 'Or self-declaration of rooftop ownership' },
              { icon: '📱', title: 'Aadhaar-linked Mobile', desc: 'For OTP verification on portal' },
            ].map(d => (
              <div key={d.title} className="flex items-start gap-3 bg-white rounded-xl p-4">
                <span className="text-xl">{d.icon}</span>
                <div>
                  <div className="font-semibold text-[14px] text-[#0F172A]">{d.title}</div>
                  <div className="text-[12.5px] text-[#64748B]">{d.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Internal links */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { href: '/muft-bijli-yojana', title: 'PM Surya Ghar Subsidy Guide', desc: '₹1,08,000 total subsidy details' },
            { href: '/learn/loans', title: 'Solar Loan Options', desc: 'Bank comparison with EMI calculator' },
            { href: '/contact', title: 'Book Free Site Survey', desc: '24-hour callback from MNRE installer' },
          ].map(l => (
            <Link key={l.href} href={l.href}
              className="bg-white border border-[#E2E8F0] rounded-xl p-5 hover:border-[#4F46E5] hover:shadow-md transition-all block">
              <div className="font-bold text-[#0F172A] mb-1">{l.title} →</div>
              <div className="text-[13px] text-[#64748B]">{l.desc}</div>
            </Link>
          ))}
        </div>
      </div>

      <CtaBanner title="Ready to Start Your Solar Journey?" desc="Book a free site survey today. Our MNRE-certified engineers across 12 West UP districts will assess your roof and design the perfect system." />
      <Footer />
    </>
  )
}
