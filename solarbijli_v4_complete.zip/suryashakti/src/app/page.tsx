import dynamic from 'next/dynamic'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import SolarCalculator from '@/components/calculator/SolarCalculator'
import { buildMetadata, getFAQSchema, getProductSchema, getHowToSchema, PRIMARY_KEYWORDS } from '@/lib/seo'
import type { Metadata } from 'next'

const SolarPanelHero3D = dynamic(() => import('@/components/3d/SolarPanelHero3D'), { ssr: false })
const InquiryForm = dynamic(() => import('@/components/forms/InquiryForm'))

export const metadata: Metadata = buildMetadata({
  title: 'SolarBijli — Solar Panels in UP | ₹1,08,000 Subsidy | Free Calculator',
  description: 'Install solar panels in Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli & all West UP districts. Get ₹1,08,000 PM Surya Ghar + UPNEDA subsidy. Free solar savings calculator. MNRE certified. EMI from ₹638/month.',
  keywords: PRIMARY_KEYWORDS,
})

const FAQS = [
  { q: 'Who qualifies for the PM Surya Ghar subsidy in UP?', a: 'Any residential homeowner in Uttar Pradesh with a valid PVVNL/UPPCL consumer number qualifies. You must install through an MNRE-empanelled vendor. All SolarBijli partners are pre-qualified. We serve Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli, Hapur, Bulandshahr, Moradabad and all West UP districts.' },
  { q: 'How accurate is the SolarBijli solar calculator?', a: 'We use real data including PVVNL/UPPCL LMV-1 tariff of ₹7.5/unit, current PM Surya Ghar subsidy slabs (₹78,000 central + ₹30,000 UP state), actual UP solar irradiance (5.4–5.7 hrs/day), and 2025 market pricing. Estimates are within 5–10% of actual installation quotes. You can choose your own tenure — 5, 7, 10, or 15 years.' },
  { q: 'Do I need a battery for solar in UP?', a: 'No. Our on-grid systems connect directly to PVVNL/UPPCL grid. Surplus daytime power earns net metering credits on your next bill. Batteries add ₹60,000–₹1.2L in cost and are rarely worth it for UP homes with normal grid access.' },
  { q: 'How long does solar installation take in UP?', a: 'Site survey: 2–3 days. Installation: 2–3 days once equipment arrives. DISCOM net meter: 15–30 days. Total from enquiry to fully commissioned: typically 45–60 days. Our partners have established DISCOM relationships in all covered UP cities including Noida, Ghaziabad, Meerut, Muzaffarnagar, Saharanpur and Baraut.' },
  { q: 'What is the EMI for a 3kW solar system in UP?', a: 'After the ₹1,08,000 subsidy, the net cost of a 3kW system is approximately ₹42,000. With an SBI loan at 7% p.a., EMI is ₹638/month for 7 years or ₹488/month for 10 years. Meanwhile you save ₹1,500–₹2,500/month on electricity — giving you a net profit from day one.' },
  { q: 'What warranty comes with solar panels?', a: '25-year panel performance warranty, 10-year inverter warranty, and 5-year workmanship warranty from the installer. SolarBijli partners provide annual O&M servicing for the first two years across all West UP cities.' },
]

export default function HomePage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getFAQSchema(FAQS)) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getProductSchema()) }}/>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getHowToSchema()) }}/>
      <Navbar/>

      {/* HERO */}
      <section aria-label="Hero" className="relative min-h-screen flex items-center justify-center pt-16 px-4 sm:px-6 overflow-hidden">
        <div className="relative z-10 w-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center min-h-[88vh] py-12 lg:py-0">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-[rgba(232,160,32,.08)] border border-[rgba(232,160,32,.25)] px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11.5px] sm:text-[12.5px] text-[#E8A020] mb-5 sm:mb-7 font-medium tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E8A020] animate-pulse"/>
              Western UP&apos;s #1 Solar Platform
            </div>
            <h1 className="font-syne font-extrabold text-[clamp(38px,7vw,88px)] leading-[.97] tracking-[-2px] sm:tracking-[-3px] mb-4 sm:mb-5">
              <span className="block text-white">Harness the</span>
              <span className="block bg-gradient-to-r from-[#E8A020] via-[#F06820] to-[#E03010] bg-clip-text text-transparent animate-shimmer bg-[length:200%]">Power of Sun</span>
            </h1>
            <p className="text-[15px] sm:text-[18px] text-[#94A3B8] max-w-[540px] leading-[1.75] mb-6 sm:mb-8 font-light lg:mx-0 mx-auto">
              Claim <strong className="text-[#E2E8F0] font-semibold">₹1,08,000 government subsidy</strong>. Certified solar installers across Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur &amp; Shamli — EMI from <strong className="text-[#E8A020]">₹638/month</strong>.
            </p>
            <div className="flex gap-3 flex-wrap justify-center lg:justify-start mb-8 sm:mb-10">
              <a href="#calculator" className="inline-flex items-center gap-2 bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[14px] sm:text-[15px] px-6 sm:px-9 py-3.5 sm:py-4 rounded-full transition-all hover:-translate-y-1 hover:shadow-[0_16px_40px_rgba(232,160,32,.35)] tracking-wide">⚡ Calculate My Savings</a>
              <a href="#inquiry" className="inline-flex items-center gap-2 bg-transparent border border-[rgba(255,255,255,.14)] text-[#CBD5E1] font-syne font-semibold text-[14px] sm:text-[15px] px-6 sm:px-9 py-3.5 sm:py-4 rounded-full transition-all hover:border-[#E8A020] hover:text-[#E8A020] tracking-wide">Free Site Survey →</a>
            </div>
            <div className="flex gap-2 sm:gap-3 flex-wrap justify-center lg:justify-start">
              {[{n:'500+',l:'Installations'},{n:'₹2Cr+',l:'Subsidy Claimed'},{n:'12 Cities',l:'West UP'},{n:'4.9★',l:'Rating'}].map(s=>(
                <div key={s.l} className="bg-[rgba(17,24,39,.9)] border border-[rgba(255,255,255,.08)] rounded-2xl px-3.5 sm:px-5 py-3 sm:py-3.5 text-center backdrop-blur-lg hover:border-[rgba(232,160,32,.25)] transition-all hover:-translate-y-1">
                  <div className="font-syne font-extrabold text-[18px] sm:text-[22px] bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent leading-none">{s.n}</div>
                  <div className="text-[9.5px] sm:text-[10.5px] text-[#64748B] mt-1 uppercase tracking-wider">{s.l}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative hidden lg:block" style={{height:'560px'}}>
            <SolarPanelHero3D/>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce opacity-40">
          <span className="text-[11px] text-[#64748B] tracking-wider uppercase">Scroll</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
        </div>
      </section>

      {/* TICKER */}
      <div className="overflow-hidden py-3.5 border-y border-[rgba(255,255,255,.06)] bg-[rgba(11,18,30,.7)]">
        <div className="flex gap-10 animate-ticker w-max">
          {[...Array(2)].map((_,ai)=>['PM Surya Ghar Certified','MNRE Empanelled','₹1,08,000 Subsidy','SBI Loan 7% p.a.','25-Year Warranty','Free Site Survey','Net Metering','Noida','Greater Noida','Ghaziabad','Meerut','Baraut','Muzaffarnagar','Saharanpur','Shamli','Hapur','Bulandshahr','Moradabad','500+ Homes Solar'].map((item,i)=>(
            <span key={`${ai}-${i}`} className="flex items-center gap-3 text-[12px] text-[#475569] font-medium whitespace-nowrap tracking-wider">
              <span className="w-1 h-1 rounded-full bg-[#E8A020] flex-shrink-0"/>{item}
            </span>
          )))}
        </div>
      </div>

      {/* WHY SOLAR */}
      <section id="why" aria-label="Why Solar" className="max-w-[1280px] mx-auto px-6 py-20">
        <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Why Solar Now</div>
        <h2 className="font-syne font-extrabold text-[clamp(32px,4.5vw,56px)] leading-[1.05] tracking-[-1.5px] mb-12">Everything works<br/>in your favour</h2>
        <div className="grid grid-cols-12 gap-3">
          {[{cols:5,icon:'☀️',big:'5.5',title:'Peak sun hours daily in UP',desc:'Western UP receives the highest solar irradiance in India — excellent production year-round.',bar:88},{cols:7,icon:'💰',big:'₹78K',title:'Maximum Government Subsidy',desc:'PM Surya Ghar Muft Bijli Yojana transfers up to ₹78,000 directly to your bank. Partners handle all paperwork.',bar:100},{cols:4,icon:'📈',big:'8%',title:'Annual electricity tariff hike',desc:'UP electricity rates rise every year. Solar locks your cost permanently.',bar:null},{cols:4,icon:'⚡',big:'4.5',title:'Year payback — then profit',desc:'After payback, 20+ years of completely free electricity. 25-year guaranteed panels.',bar:null},{cols:4,icon:'🌱',big:'1.2T',title:'CO₂ saved/year (3kW)',desc:'Equal to planting 40 trees every year for 25 years.',bar:null}].map((card,i)=>(
            <div key={i} className={`col-span-12 md:col-span-${card.cols} bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.07)] rounded-[22px] p-7 relative overflow-hidden transition-all hover:-translate-y-[6px] hover:border-[rgba(232,160,32,.22)] hover:shadow-[0_28px_56px_rgba(0,0,0,.5)] group cursor-default`}>
              <div className="absolute top-[-50px] right-[-50px] w-[160px] h-[160px] rounded-full bg-gradient-radial from-[rgba(232,160,32,.12)] to-transparent pointer-events-none"/>
              <span className="text-[32px] mb-3 block">{card.icon}</span>
              <div className="font-syne font-extrabold text-[60px] leading-none bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent mb-1">{card.big}</div>
              <h3 className="font-syne font-bold text-[18px] text-white mb-2">{card.title}</h3>
              <p className="text-[13.5px] text-[#64748B] leading-[1.65]">{card.desc}</p>
              {card.bar&&<div className="mt-5 h-[3px] bg-[rgba(255,255,255,.06)] rounded-full"><div className="h-full rounded-full bg-gradient-to-r from-[#E8A020] to-[#F06820]" style={{width:`${card.bar}%`}}/></div>}
            </div>
          ))}
        </div>
      </section>

      {/* CALCULATOR */}
      <section id="calculator" aria-label="Solar Calculator" className="px-4 sm:px-6 py-14 sm:py-20">
        <div className="max-w-[1160px] mx-auto">
          <div className="text-center mb-8 sm:mb-12">
            <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 justify-center mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Solar Calculator</div>
            <h2 className="font-syne font-extrabold text-[clamp(26px,4.5vw,54px)] leading-[1.06] tracking-[-1.5px] mb-3">Your personalised <span className="bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">solar blueprint</span></h2>
            <p className="text-[#64748B] text-[14px] sm:text-[16px]">Real UP tariff · ₹1,08,000 subsidy · Choose your EMI tenure · Instant results</p>
          </div>
          <SolarCalculator/>
        </div>
      </section>

      {/* CITIES */}
      <section id="cities" aria-label="West UP Cities" className="max-w-[1280px] mx-auto px-4 sm:px-6 py-14 sm:py-20">
        <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Our Network</div>
        <h2 className="font-syne font-extrabold text-[clamp(26px,4vw,52px)] leading-[1.06] tracking-[-1.5px] mb-3">Serving <span className="bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">12 Districts</span> of West UP</h2>
        <p className="text-[#64748B] text-[14px] sm:text-[15px] mb-8 max-w-[600px]">From Noida to Saharanpur — PVVNL-certified solar installation with full subsidy support and net metering in every district.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {[
            {name:'Noida',dist:'Gautam Buddha Nagar',slug:'noida',sun:'5.4',bill:'₹3,200',pb:'4.1 yr'},
            {name:'Greater Noida',dist:'Gautam Buddha Nagar',slug:'greater-noida',sun:'5.4',bill:'₹2,800',pb:'4.3 yr'},
            {name:'Ghaziabad',dist:'Ghaziabad',slug:'ghaziabad',sun:'5.4',bill:'₹3,000',pb:'4.2 yr'},
            {name:'Meerut',dist:'Meerut',slug:'meerut',sun:'5.5',bill:'₹2,400',pb:'4.5 yr'},
            {name:'Baraut',dist:'Baghpat',slug:'baraut',sun:'5.6',bill:'₹1,900',pb:'4.6 yr'},
            {name:'Baghpat',dist:'Baghpat',slug:'baghpat',sun:'5.6',bill:'₹1,700',pb:'4.8 yr'},
            {name:'Muzaffarnagar',dist:'Muzaffarnagar',slug:'muzaffarnagar',sun:'5.7',bill:'₹2,200',pb:'4.3 yr'},
            {name:'Saharanpur',dist:'Saharanpur',slug:'saharanpur',sun:'5.5',bill:'₹2,100',pb:'4.5 yr'},
            {name:'Shamli',dist:'Shamli',slug:'shamli',sun:'5.6',bill:'₹1,800',pb:'4.8 yr'},
            {name:'Hapur',dist:'Hapur',slug:'hapur',sun:'5.5',bill:'₹2,000',pb:'4.6 yr'},
            {name:'Bulandshahr',dist:'Bulandshahr',slug:'bulandshahr',sun:'5.5',bill:'₹1,900',pb:'4.7 yr'},
            {name:'Moradabad',dist:'Moradabad',slug:'moradabad',sun:'5.5',bill:'₹2,300',pb:'4.4 yr'},
          ].map(c=>(
            <a key={c.slug} href={`/cities/${c.slug}`}
              className="group bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.07)] rounded-[18px] sm:rounded-[22px] p-4 sm:p-6 relative overflow-hidden transition-all hover:-translate-y-1.5 hover:border-[rgba(232,160,32,.2)] hover:shadow-[0_20px_48px_rgba(0,0,0,.4)] no-underline text-inherit block">
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-[#E8A020] via-[#F06820] to-[#E03010] scale-x-0 group-hover:scale-x-100 origin-left transition-transform"/>
              <h3 className="font-syne font-extrabold text-[16px] sm:text-[20px] text-white mb-0.5">{c.name}</h3>
              <p className="text-[10.5px] sm:text-[12px] text-[#3D5068] mb-3">{c.dist}</p>
              <div className="flex gap-3 sm:gap-4">
                {[{v:c.sun,l:'Sun hrs'},{v:c.bill,l:'Avg bill'},{v:c.pb,l:'Payback'}].map(m=>(
                  <div key={m.l}>
                    <div className="font-syne font-bold text-[13px] sm:text-[15px] text-[#E8A020]">{m.v}</div>
                    <div className="text-[9px] sm:text-[10.5px] text-[#3D5068] mt-0.5">{m.l}</div>
                  </div>
                ))}
              </div>
            </a>
          ))}
        </div>
        <div className="mt-6 text-center">
          <a href="/cities" className="inline-flex items-center gap-2 text-[#E8A020] font-semibold text-[14px] hover:gap-3 transition-all">
            View all cities &amp; local solar data →
          </a>
        </div>
      </section>

      {/* SUBSIDY */}
      <section id="subsidy" aria-label="PM Surya Ghar Subsidy" className="max-w-[1280px] mx-auto px-4 sm:px-6 py-4">
        <div className="bg-gradient-to-br from-[rgba(232,160,32,.07)] to-[rgba(240,104,32,.04)] border border-[rgba(232,160,32,.15)] rounded-[24px] sm:rounded-[36px] p-6 sm:p-10 lg:p-[56px_52px] relative overflow-hidden">
          <div className="absolute top-[-80px] right-[-40px] w-[260px] h-[260px] rounded-full pointer-events-none" style={{background:'radial-gradient(circle,rgba(232,160,32,.1),transparent 70%)'}}/>
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-center">
            <div>
              <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Government Scheme 2025</div>
              <h2 className="font-syne font-extrabold text-[clamp(26px,4vw,52px)] leading-[1.05] tracking-[-1.5px] mb-4">PM Surya Ghar +<br/>UPNEDA Subsidy<br/><span className="bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent">₹1,08,000 Free</span></h2>
              <p className="text-[#64748B] text-[14px] sm:text-[16px] leading-[1.75] mb-7">India&apos;s central government transfers up to ₹78,000 + UP state adds ₹30,000 = <strong className="text-[#E8A020]">₹1,08,000 total</strong> directly to your bank. Our MNRE-certified partners handle all documentation free of charge.</p>
              <a href="#calculator" className="inline-flex items-center bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[14px] sm:text-[15px] px-7 sm:px-8 py-3.5 sm:py-4 rounded-full transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_36px_rgba(232,160,32,.35)] tracking-wide">Check My Eligibility →</a>
            </div>
            <div className="flex gap-2 sm:gap-3">
              {[{kw:'1',unit:'kilowatt',central:'₹30,000',state:'₹15,000',total:'₹45,000'},{kw:'2',unit:'kilowatt',central:'₹60,000',state:'₹30,000',total:'₹90,000'},{kw:'3+',unit:'kilowatt',central:'₹78,000',state:'₹30,000',total:'₹1,08,000',f:true}].map(s=>(
                <div key={s.kw} className={`flex-1 bg-[rgba(10,14,26,.7)] border rounded-[14px] sm:rounded-[18px] p-4 sm:p-5 text-center transition-all hover:scale-[1.03] backdrop-blur-sm ${s.f?'border-[rgba(232,160,32,.3)]':'border-[rgba(255,255,255,.08)]'}`}>
                  <div className="font-syne font-extrabold text-[28px] sm:text-[36px] bg-gradient-to-r from-[#E8A020] to-[#F06820] bg-clip-text text-transparent leading-none">{s.kw}</div>
                  <div className="text-[10px] sm:text-[11.5px] text-[#64748B] mb-2">{s.unit}</div>
                  <div className="text-[9px] sm:text-[10px] text-[#475569] mb-0.5">Central: {s.central}</div>
                  <div className="text-[9px] sm:text-[10px] text-[#475569] mb-2">UP State: {s.state}</div>
                  <div className="font-syne font-bold text-[14px] sm:text-[18px] text-[#0EA472]">{s.total}</div>
                  {s.f && <div className="text-[9px] sm:text-[10px] text-[#059669] mt-1 font-semibold">MAX SUBSIDY ✓</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section aria-label="How It Works" className="max-w-[1280px] mx-auto px-4 sm:px-6 py-14 sm:py-20">
        <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Process</div>
        <h2 className="font-syne font-extrabold text-[clamp(26px,4vw,52px)] leading-[1.05] tracking-[-1.5px] mb-10 sm:mb-12">From zero to solar in 4 steps</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 relative">
          <div className="absolute top-[26px] left-[12.5%] right-[12.5%] h-px bg-gradient-to-r from-[#E8A020] via-[#F06820] to-[#E03010] hidden lg:block"/>
          {[
            {n:'01',t:'Calculate',d:'Enter your bill and city. Get your personalised estimate with subsidy and EMI in 30 seconds.'},
            {n:'02',t:'Connect',d:'We match you to a certified UP installer within 24 hours — completely free.'},
            {n:'03',t:'Survey',d:'Free site visit. Installer handles all MNRE paperwork and subsidy application.'},
            {n:'04',t:'Shine',d:'Installed in 7–14 days. Start generating — and saving — from day one.'},
          ].map(s=>(
            <div key={s.n} className="text-center relative z-10">
              <div className="w-[44px] sm:w-[52px] h-[44px] sm:h-[52px] rounded-full bg-gradient-to-br from-[#E8A020] to-[#F06820] flex items-center justify-center font-syne font-extrabold text-[16px] sm:text-[18px] text-[#0A0E1A] mx-auto mb-3 sm:mb-4 shadow-[0_0_24px_rgba(232,160,32,.28)]">{s.n}</div>
              <h3 className="font-syne font-bold text-[14px] sm:text-[16px] text-white mb-2">{s.t}</h3>
              <p className="text-[12px] sm:text-[13.5px] text-[#64748B] leading-[1.65]">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* INQUIRY FORM */}
      <section id="inquiry" aria-label="Get Free Solar Quote" className="px-4 sm:px-6 py-12 sm:py-16">
        <div className="max-w-[900px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-0 bg-[#0D1829] border border-[rgba(232,160,32,.12)] rounded-[24px] sm:rounded-[32px] overflow-hidden">
            <div className="lg:col-span-2 p-6 sm:p-10 bg-gradient-to-br from-[rgba(232,160,32,.07)] to-[rgba(240,104,32,.04)] flex flex-col justify-center">
              <h2 className="font-syne font-extrabold text-[22px] sm:text-[28px] text-white mb-4 leading-tight">Get Your Free Solar Quote Today</h2>
              <p className="text-[#64748B] text-[13.5px] sm:text-[14.5px] leading-relaxed mb-5 sm:mb-6">Fill in 3 simple steps. Our certified installer will call within 24 hours with a personalised proposal.</p>
              <div className="space-y-2.5 sm:space-y-3">
                {['✅ 100% free consultation','📋 Handles all MNRE paperwork','⚡ Installation in 7–14 days','💰 ₹1,08,000 subsidy support'].map(p=>(
                  <div key={p} className="text-[12.5px] sm:text-[13.5px] text-[#94A3B8]">{p}</div>
                ))}
              </div>
            </div>
            <div className="lg:col-span-3 p-6 sm:p-10"><InquiryForm/></div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section aria-label="FAQ" className="max-w-[1280px] mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="text-[11px] font-bold tracking-[.14em] text-[#E8A020] uppercase flex items-center gap-2 mb-4"><span className="w-[18px] h-px bg-[#E8A020]"/>Common Questions</div>
        <h2 className="font-syne font-extrabold text-[clamp(26px,4vw,52px)] leading-[1.05] tracking-[-1.5px] mb-8 sm:mb-10">Everything you want to know</h2>
        <div className="max-w-[760px] space-y-2.5">
          {FAQS.map((faq,i)=>(
            <details key={i} className="bg-[rgba(255,255,255,.04)] border border-[rgba(255,255,255,.06)] rounded-2xl overflow-hidden group hover:border-[rgba(232,160,32,.15)] transition-colors">
              <summary className="px-4 sm:px-5 py-3.5 sm:py-4 cursor-pointer flex justify-between items-center gap-3 text-[13.5px] sm:text-[14.5px] font-medium text-[#E2E8F0] list-none select-none [&::-webkit-details-marker]:hidden">
                {faq.q}<span className="w-[26px] h-[26px] rounded-full bg-[rgba(232,160,32,.1)] flex items-center justify-center text-[#E8A020] text-[13px] flex-shrink-0 transition-transform group-open:rotate-90">›</span>
              </summary>
              <p className="px-4 sm:px-5 pb-4 text-[#94A3B8] text-[13px] sm:text-[13.5px] leading-[1.75]">{faq.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* CTA */}
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8 mb-12 sm:mb-16">
        <div className="bg-[rgba(255,255,255,.04)] border border-[rgba(232,160,32,.12)] rounded-[20px] sm:rounded-[28px] px-6 sm:px-12 py-10 sm:py-14 flex flex-col lg:flex-row items-center justify-between gap-6 sm:gap-8 relative overflow-hidden text-center lg:text-left">
          <div className="absolute top-[-80px] right-[-80px] w-[360px] h-[360px] rounded-full pointer-events-none" style={{background:'radial-gradient(circle,rgba(232,160,32,.07),transparent 70%)'}}/>
          <div className="relative">
            <h2 className="font-syne font-extrabold text-[clamp(22px,3.5vw,46px)] text-white mb-3 leading-tight">Ready to switch to solar?</h2>
            <p className="text-[#64748B] text-[14px] sm:text-[16px] max-w-[460px] leading-relaxed lg:mx-0 mx-auto">Get your personalised estimate in 30 seconds. Choose your tenure. See your exact EMI and savings.</p>
          </div>
          <a href="#calculator" className="relative flex-shrink-0 bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[15px] sm:text-[16px] px-9 sm:px-11 py-4 sm:py-5 rounded-full hover:-translate-y-0.5 hover:shadow-[0_16px_50px_rgba(232,160,32,.38)] transition-all tracking-wide whitespace-nowrap">⚡ Calculate Free Now</a>
        </div>
      </div>

      <Footer/>
    </>
  )
}
