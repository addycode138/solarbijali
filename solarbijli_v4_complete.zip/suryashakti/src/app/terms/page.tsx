import type { Metadata } from 'next'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import PageHeader from '@/components/shared/PageHeader'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Terms & Conditions | SolarBijli',
  description: 'SolarBijli terms and conditions for using our solar platform and calculator.',
  alternates: { canonical: `${SITE_URL}/terms` },
  robots: 'noindex',
}
export default function TermsPage() {
  return (<>
    <Navbar/>
    <PageHeader tag="Legal" h1="Terms & Conditions" desc="Last updated: March 1, 2025" breadcrumb={[{href:'/',label:'Home'},{href:'/terms',label:'Terms'}]}/>
    <div className="max-w-[860px] mx-auto px-5 py-12 prose-solar">
      <h2>Service Description</h2>
      <p>SolarBijli is a solar energy marketing and advisory platform. We are not a solar installer. We connect customers with independent, MNRE-certified third-party installer partners in Uttar Pradesh. The installation contract is between you and the installer — SolarBijli is not a party to the installation agreement.</p>
      <h2>Calculator Estimates</h2>
      <p>The Solar Calculator provides estimates based on publicly available data including PVVNL/UPPCL tariff rates, PM Surya Ghar and UPNEDA subsidy amounts, MNRE benchmark pricing, and market data. Estimates are for guidance only and do not constitute a quote or contract. Actual costs, savings, and installation timelines may vary by 5–20%.</p>
      <h2>Subsidy Information</h2>
      <p>Government subsidy schemes including PM Surya Ghar Muft Bijli Yojana and UPNEDA are subject to change without notice. SolarBijli makes reasonable efforts to keep subsidy information current but does not guarantee subsidy availability or amounts. Always verify subsidy details at <a href="https://pmsuryaghar.gov.in" target="_blank" rel="noopener noreferrer" className="text-[#4F46E5] hover:underline">pmsuryaghar.gov.in</a>.</p>
      <h2>Bank Loan Information</h2>
      <p>Bank loan interest rates mentioned on our platform are indicative and based on publicly available bank data. Actual rates depend on individual bank assessment, CIBIL score, and current RBI benchmark rates. Always verify with your bank before applying.</p>
      <h2>Lead Referral</h2>
      <p>By submitting your contact details on SolarBijli, you consent to being contacted by our installer partners. SolarBijli may receive a referral fee from installers for successful leads. This fee does not affect your installation price — installers must quote at MNRE benchmark or below.</p>
      <h2>Contact</h2>
      <p><a href="mailto:pankajyadi@gmail.com" className="text-[#4F46E5] hover:underline">pankajyadi@gmail.com</a> | <a href="tel:7373734778" className="text-[#4F46E5] hover:underline">+91 73737 34778</a></p>
    </div>
    <Footer/>
  </>)
}
