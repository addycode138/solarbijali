'use client'

import { useState, useEffect, useCallback } from 'react'
import { Search, RefreshCw, Sun } from 'lucide-react'
import { formatINR } from '@/lib/utils'
import type { LeadWithAgency } from '@/types'

const STATUS_COLORS: Record<string, string> = {
  NEW: 'bg-sky-500/20 text-sky-400',
  ASSIGNED: 'bg-sun/20 text-sun',
  CONTACTED: 'bg-purple-500/20 text-purple-400',
  QUOTED: 'bg-amber-500/20 text-amber-400',
  CONVERTED: 'bg-leaf/20 text-leaf',
  LOST: 'bg-red-500/20 text-red-400',
}

export default function AdminDashboard() {
  const [secret, setSecret] = useState('')
  const [authenticated, setAuthenticated] = useState(false)
  const [leads, setLeads] = useState<LeadWithAgency[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [error, setError] = useState('')

  const fetchLeads = useCallback(async (s: string) => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/leads', { headers: { 'x-admin-secret': s } })
      if (!res.ok) { setError('Incorrect password'); return }
      const data = await res.json()
      setLeads(data.leads)
      setAuthenticated(true)
    } catch {
      setError('Failed to fetch leads')
    } finally {
      setLoading(false)
    }
  }, [])

  const filtered = leads.filter(
    (l) =>
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.city.toLowerCase().includes(search.toLowerCase()) ||
      l.phone.includes(search)
  )

  const stats = {
    total: leads.length,
    new: leads.filter((l) => l.status === 'NEW').length,
    converted: leads.filter((l) => l.status === 'CONVERTED').length,
    totalValue: leads.reduce((s, l) => s + l.netCost, 0),
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-sky-950 flex items-center justify-center p-4">
        <div className="card-dark-solid rounded-2xl p-10 w-full max-w-md text-center">
          <div className="w-12 h-12 rounded-xl bg-sun flex items-center justify-center mx-auto mb-6">
            <Sun className="w-6 h-6 text-sky-950" />
          </div>
          <h1 className="font-syne font-700 text-white text-2xl mb-2">SolarBijli Admin</h1>
          <p className="text-slate-400 text-sm mb-8">Enter your admin password to continue.</p>
          <input
            type="password"
            className="input-dark mb-4"
            placeholder="Admin secret"
            value={secret}
            onChange={(e) => setSecret(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchLeads(secret)}
          />
          {error && <p className="text-red-400 text-sm mb-3">{error}</p>}
          <button
            onClick={() => fetchLeads(secret)}
            disabled={loading}
            className="w-full bg-sun text-sky-950 font-syne font-700 py-3 rounded-xl hover:bg-sun-300 transition-colors disabled:opacity-50"
          >
            {loading ? 'Verifying...' : 'Sign In'}
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-sky-950 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sun flex items-center justify-center">
            <Sun className="w-5 h-5 text-sky-950" />
          </div>
          <div>
            <h1 className="font-syne font-700 text-white text-xl">SolarBijli Admin</h1>
            <p className="text-slate-400 text-xs">Lead Management Dashboard</p>
          </div>
        </div>
        <button
          onClick={() => fetchLeads(secret)}
          className="flex items-center gap-2 text-slate-400 hover:text-white text-sm border border-sky-700 px-4 py-2 rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Leads', value: stats.total },
          { label: 'New (Uncontacted)', value: stats.new },
          { label: 'Converted', value: stats.converted },
          { label: 'Pipeline Value', value: formatINR(stats.totalValue) },
        ].map(({ label, value }) => (
          <div key={label} className="card-dark-solid rounded-xl p-4">
            <p className="text-slate-400 text-xs mb-1">{label}</p>
            <p className="font-syne font-700 text-white text-2xl">{value}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input
          className="input-dark pl-10"
          placeholder="Search by name, city, or phone…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="card-dark-solid rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-sky-800 text-xs text-slate-400 uppercase tracking-wide">
                <th className="text-left py-3 px-4">Customer</th>
                <th className="text-left py-3 px-4">City</th>
                <th className="text-right py-3 px-4">System</th>
                <th className="text-right py-3 px-4">Net Cost</th>
                <th className="text-left py-3 px-4">Financing</th>
                <th className="text-left py-3 px-4">Agency</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-right py-3 px-4">Date</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="py-12 text-center text-slate-500">No leads found</td></tr>
              )}
              {filtered.map((lead) => (
                <tr key={lead.id} className="border-b border-sky-800/40 hover:bg-sky-900/30 transition-colors">
                  <td className="py-3 px-4">
                    <p className="text-white font-medium">{lead.name}</p>
                    <p className="text-slate-400 text-xs">{lead.phone}</p>
                  </td>
                  <td className="py-3 px-4 text-slate-300">{lead.city}</td>
                  <td className="py-3 px-4 text-right text-white">{lead.systemSizeKw} kW</td>
                  <td className="py-3 px-4 text-right text-sun font-syne font-600">{formatINR(lead.netCost)}</td>
                  <td className="py-3 px-4 text-slate-300 capitalize">{lead.financing}</td>
                  <td className="py-3 px-4 text-slate-300">{lead.agency?.name ?? '—'}</td>
                  <td className="py-3 px-4">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${STATUS_COLORS[lead.status] ?? 'bg-sky-800 text-slate-300'}`}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400 text-xs">
                    {new Date(lead.createdAt).toLocaleDateString('en-IN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
