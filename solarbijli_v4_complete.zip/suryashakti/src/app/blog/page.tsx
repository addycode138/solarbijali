import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import PageHeader from '@/components/shared/PageHeader'
import { BLOG_POSTS } from '@/lib/blog-data'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Solar Energy Blog UP | Subsidy, Installation & Guides | SolarBijli',
  description: 'Expert solar guides for UP homeowners. PM Surya Ghar subsidy, UPNEDA, pricing, installation process, net metering and more. Updated 2025.',
  alternates: { canonical: `${SITE_URL}/blog` },
}
export default function BlogListPage() {
  const featured = BLOG_POSTS[0]
  const rest = BLOG_POSTS.slice(1)
  return (<>
    <Navbar/>
    <PageHeader tag="Knowledge Hub" h1="Solar Energy Blog for Uttar Pradesh" desc="Expert guides on subsidies, installation, loans and solar energy for UP homeowners. Updated 2025." breadcrumb={[{href:'/',label:'Home'},{href:'/blog',label:'Blog'}]}/>
    <div className="max-w-[1280px] mx-auto px-5 py-12">
      {/* Featured */}
      <Link href={`/blog/${featured.slug}`} className="block bg-white border border-[#E2E8F0] rounded-2xl overflow-hidden hover:border-[#4F46E5] hover:shadow-lg transition-all mb-6 no-underline text-inherit">
        <div className="grid grid-cols-1 md:grid-cols-5">
          <div className="md:col-span-2 h-[200px] md:h-auto flex items-center justify-center text-[72px]" style={{background:'linear-gradient(135deg,#EEF2FF,#FFFBEB)'}}>
            {featured.emoji}
          </div>
          <div className="md:col-span-3 p-7">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#4F46E5] bg-[#EEF2FF] px-3 py-1 rounded-full mb-3">{featured.category}</div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A] tracking-tight leading-snug mb-3">{featured.title}</h2>
            <p className="text-[14px] text-[#64748B] leading-relaxed mb-4">{featured.excerpt}</p>
            <div className="flex items-center gap-3 text-[12px] text-[#94A3B8]">
              <span>📅 {new Date(featured.publishDate).toLocaleDateString('en-IN',{month:'short',year:'numeric'})}</span>
              <span>⏱️ {featured.readTime} min read</span>
              <span className="text-[#4F46E5] font-semibold">Read guide →</span>
            </div>
          </div>
        </div>
      </Link>
      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {rest.map(post=>(
          <Link key={post.slug} href={`/blog/${post.slug}`} className="bg-white border border-[#E2E8F0] rounded-2xl overflow-hidden hover:border-[#4F46E5] hover:shadow-md hover:-translate-y-1 transition-all block no-underline text-inherit">
            <div className="h-[140px] flex items-center justify-center text-[48px] relative" style={{background:'linear-gradient(135deg,#EEF2FF,#FFFBEB)'}}>
              {post.emoji}
              <span className="absolute top-3 left-3 text-[10.5px] font-bold bg-[#4F46E5] text-white px-2.5 py-1 rounded-full">{post.category}</span>
            </div>
            <div className="p-5">
              <div className="flex gap-2 text-[11px] text-[#94A3B8] mb-2.5">
                <span>{new Date(post.publishDate).toLocaleDateString('en-IN',{month:'short',year:'numeric'})}</span>
                <span>·</span><span>{post.readTime} min</span>
              </div>
              <h2 className="text-[15px] font-bold text-[#0F172A] leading-snug mb-2 tracking-tight">{post.title}</h2>
              <p className="text-[13px] text-[#64748B] leading-relaxed mb-3 line-clamp-2">{post.excerpt}</p>
              <span className="text-[13px] font-semibold text-[#4F46E5]">Read more →</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
    <Footer/>
  </>)
}
