import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { buildMetadata, getBreadcrumbSchema, getFAQSchema } from '@/lib/seo'
import { BLOG_POSTS } from '@/lib/blog-data'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export async function generateStaticParams() {
  return BLOG_POSTS.map(p => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = BLOG_POSTS.find(p => p.slug === params.slug)
  if (!post) return {}
  return buildMetadata({
    title: post.metaTitle,
    description: post.metaDesc,
    path: `/blog/${post.slug}`,
    keywords: post.keywords,
  })
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = BLOG_POSTS.find(p => p.slug === params.slug)
  if (!post) notFound()

  const breadcrumb = getBreadcrumbSchema([
    { name: 'Home', url: SITE_URL },
    { name: 'Blog', url: `${SITE_URL}/blog` },
    { name: post.title.substring(0, 60), url: `${SITE_URL}/blog/${post.slug}` },
  ])

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.metaDesc,
    author: { '@type': 'Organization', name: 'SolarBijli' },
    publisher: {
      '@type': 'Organization',
      name: 'SolarBijli',
      logo: { '@type': 'ImageObject', url: `${SITE_URL}/logo.png` },
    },
    datePublished: post.publishDate,
    dateModified: post.updateDate,
    mainEntityOfPage: { '@type': 'WebPage', '@id': `${SITE_URL}/blog/${post.slug}` },
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumb) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      {post.faqSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(getFAQSchema(post.faqSchema)) }} />
      )}

      <Navbar />
      <div className="pt-20 bg-[#F8FAFC] min-h-screen">
        <div className="max-w-[820px] mx-auto px-6 py-12">

          {/* Breadcrumb */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-[12px] text-[var(--muted2)] mb-8">
            <Link href="/" className="hover:text-[var(--cta)] transition-colors no-underline">Home</Link>
            <span>›</span>
            <Link href="/blog" className="hover:text-[var(--cta)] transition-colors no-underline">Blog</Link>
            <span>›</span>
            <span className="text-[var(--ink2)]">{post.category}</span>
          </nav>

          {/* Article header */}
          <div className="inline-flex items-center gap-2 bg-[var(--cta-bg)] border border-[var(--cta-light)] text-[var(--cta)] text-[11.5px] font-bold px-3 py-1 rounded-full tracking-wider uppercase mb-5">
            {post.category}
          </div>
          <h1 className="text-[clamp(26px,4vw,40px)] font-black text-[var(--ink)] leading-tight tracking-tight mb-5">
            {post.title}
          </h1>
          <div className="flex items-center flex-wrap gap-4 text-[13px] text-[var(--muted2)] mb-8 pb-6 border-b border-[var(--border)]">
            <span>✍️ {post.author}</span>
            <span>📅 Published: {new Date(post.publishDate).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' })}</span>
            <span>🔄 Updated: {new Date(post.updateDate).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' })}</span>
            <span>⏱️ {post.readTime} min read</span>
          </div>

          {/* Lead CTA */}
          <div className="bg-[var(--cta-bg)] border border-[var(--cta-light)] rounded-2xl p-5 mb-8 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
            <div>
              <div className="font-bold text-[var(--ink)] text-[15px] mb-1">🌞 Get a Free Solar Quote for Your Home</div>
              <div className="text-[13px] text-[var(--muted)]">₹1,08,000 total subsidy · MNRE certified · 24hr callback</div>
            </div>
            <Link href="/#contact" className="bg-[var(--cta)] text-white font-bold text-[14px] px-5 py-2.5 rounded-xl no-underline hover:bg-[var(--cta2)] transition-colors whitespace-nowrap">
              Get Free Quote →
            </Link>
          </div>

          {/* Article content */}
          <article
            className="prose max-w-none text-[var(--ink)]"
            style={{ lineHeight: '1.8' }}
            dangerouslySetInnerHTML={{ __html: post.content }}
          />

          {/* Bottom CTA */}
          <div className="mt-12 bg-gradient-to-r from-[var(--cta)] to-[#7C3AED] rounded-2xl p-7 text-center text-white">
            <h3 className="font-black text-[22px] mb-3">Ready to Install Solar in UP?</h3>
            <p className="text-[15px] opacity-85 mb-5">Get ₹1,08,000 total subsidy + free site survey. MNRE certified partners across 12 West UP districts.</p>
            <div className="flex gap-3 justify-center flex-wrap">
              <Link href="/#calculator" className="bg-white text-[var(--cta)] font-bold text-[14px] px-6 py-3 rounded-xl no-underline hover:-translate-y-0.5 transition-all">⚡ Calculate My Savings</Link>
              <a href="tel:7373734778" className="bg-[rgba(255,255,255,.15)] text-white font-bold text-[14px] px-6 py-3 rounded-xl no-underline border border-[rgba(255,255,255,.3)] hover:bg-[rgba(255,255,255,.25)] transition-all">📞 73737 34778</a>
            </div>
          </div>

          {/* Related posts */}
          <div className="mt-12">
            <h3 className="font-bold text-[20px] text-[var(--ink)] mb-6">Related Solar Guides</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {BLOG_POSTS.filter(p => p.slug !== post.slug).slice(0, 4).map(related => (
                <Link key={related.slug} href={`/blog/${related.slug}`} className="bg-white border border-[var(--border)] rounded-xl p-4 no-underline text-inherit hover:border-[var(--cta)] transition-all">
                  <div className="text-2xl mb-2">{related.emoji}</div>
                  <div className="font-semibold text-[14px] text-[var(--ink)] leading-snug mb-1">{related.title.substring(0, 65)}...</div>
                  <div className="text-[12px] text-[var(--cta)] font-semibold mt-2">Read guide →</div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}
