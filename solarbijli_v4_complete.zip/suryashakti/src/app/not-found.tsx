import Link from 'next/link'
import SiteLayout from '@/components/layout/SiteLayout'

export default function NotFound() {
  return (
    <SiteLayout>
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <div className="font-syne font-800 text-8xl text-sun/20 mb-4">404</div>
          <h1 className="font-syne font-700 text-3xl text-white mb-3">Page Not Found</h1>
          <p className="text-slate-400 mb-8 max-w-md mx-auto">
            The page you're looking for doesn't exist. Try our solar calculator to get started.
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/" className="border border-sky-700 text-slate-300 hover:text-white px-6 py-3 rounded-xl text-sm font-syne font-600 transition-colors">
              Go Home
            </Link>
            <Link href="/calculator" className="bg-sun text-sky-950 font-syne font-700 px-6 py-3 rounded-xl text-sm hover:bg-sun-300 transition-colors">
              Open Calculator
            </Link>
          </div>
        </div>
      </div>
    </SiteLayout>
  )
}
