import type { Metadata } from 'next'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import PageHeader from '@/components/shared/PageHeader'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Privacy Policy | SolarBijli',
  description: 'SolarBijli privacy policy — how we collect, use, and protect your personal data.',
  alternates: { canonical: `${SITE_URL}/privacy` },
  robots: 'noindex',
}
export default function PrivacyPage() {
  return (<>
    <Navbar/>
    <PageHeader tag="Legal" h1="Privacy Policy" desc={`Last updated: March 1, 2025`} breadcrumb={[{href:'/',label:'Home'},{href:'/privacy',label:'Privacy Policy'}]}/>
    <div className="max-w-[860px] mx-auto px-5 py-12 prose-solar">
      <h2>Information We Collect</h2>
      <p>When you use the SolarBijli solar calculator and submit a lead form, we collect: your name, mobile number, email address (optional), city, property type, monthly electricity bill, and the solar estimate inputs. We also collect usage analytics (page views, time on site) via Google Analytics.</p>
      <h2>How We Use Your Information</h2>
      <p>We use your contact information solely to connect you with our MNRE-certified installer partner in your city. We send your details to the relevant installer who will contact you to discuss solar installation. We also send you a confirmation email with your solar estimate summary.</p>
      <h2>Data Sharing</h2>
      <p>We share your contact information only with our verified installer partner in your city. We do not sell, rent, or share your data with advertisers, data brokers, or any other third parties. Our installer partners are bound by confidentiality agreements.</p>
      <h2>Data Retention</h2>
      <p>We retain lead data for 24 months for quality assurance and follow-up purposes. You may request deletion of your data at any time by emailing <a href="mailto:pankajyadi@gmail.com" className="text-[#4F46E5] hover:underline">pankajyadi@gmail.com</a>.</p>
      <h2>Cookies</h2>
      <p>We use Google Analytics cookies to understand how visitors use our website. These are analytics-only cookies and do not track personal information. You can opt out via your browser settings or Google's opt-out tools.</p>
      <h2>Your Rights</h2>
      <p>You have the right to access, correct, or delete your personal data. Contact us at <a href="mailto:pankajyadi@gmail.com" className="text-[#4F46E5] hover:underline">pankajyadi@gmail.com</a> for any privacy requests.</p>
      <h2>Contact</h2>
      <p>For privacy concerns: <a href="mailto:pankajyadi@gmail.com" className="text-[#4F46E5] hover:underline">pankajyadi@gmail.com</a> | Phone: <a href="tel:7373734778" className="text-[#4F46E5] hover:underline">+91 73737 34778</a></p>
    </div>
    <Footer/>
  </>)
}
