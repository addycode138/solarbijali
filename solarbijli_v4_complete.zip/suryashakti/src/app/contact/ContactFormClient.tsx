'use client'
import { useState } from 'react'
import { CITIES, PHONE, WA_NUMBER } from '@/lib/constants'

type Step = 1 | 2 | 3
const prefTimes = ['Morning (9am–12pm)', 'Afternoon (12pm–4pm)', 'Evening (4pm–8pm)']
const finOpts   = ['Cash Purchase', 'SBI Loan (7%)', 'Canara Bank (6.5%)', 'Other Bank Loan']

export default function ContactFormClient() {
  const [step, setStep] = useState<Step>(1)
  const [done, setDone] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name:'', phone:'', email:'', city: CITIES[0].name, bill:'', prop:'residential', fin:'SBI Loan (7%)', time:'Morning (9am–12pm)', msg:'' })
  const set = (k: string, v: string) => setForm(p => ({...p, [k]: v}))

  const submit = async () => {
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: form.name, phone: form.phone, email: form.email || undefined, city: form.city, monthlyBill: parseInt(form.bill) || 2500, propertyType: form.prop, financing: 'loan', preferredTime: form.time, message: form.msg, source: 'contact-page' }),
      })
      setDone(true)
    } catch {
      alert('Something went wrong. Please call us directly at +91 73737 34778.')
    } finally { setLoading(false) }
  }

  const inp = "w-full border border-[#E2E8F0] rounded-xl px-4 py-3 text-[14px] text-[#0F172A] bg-[#F8FAFC] outline-none focus:border-[#4F46E5] focus:bg-white transition-all"
  const ChipRow = ({ opts, val, onChange }: { opts:string[]; val:string; onChange:(v:string)=>void }) => (
    <div className="flex gap-2 flex-wrap">{opts.map(o => <button key={o} type="button" onClick={() => onChange(o)} className={`px-3.5 py-2 rounded-full text-[13px] font-medium border transition-all ${val===o?'bg-[#EEF2FF] border-[#4F46E5] text-[#4F46E5] font-semibold':'border-[#E2E8F0] text-[#64748B] hover:border-[#CBD5E1]'}`}>{o}</button>)}</div>
  )

  if (done) return (
    <div className="bg-white border border-[#E2E8F0] rounded-2xl p-10 text-center shadow-sm">
      <div className="w-[80px] h-[80px] rounded-full bg-[#ECFDF5] border-2 border-[#A7F3D0] flex items-center justify-center text-[36px] mx-auto mb-5">✅</div>
      <h2 className="text-[24px] font-extrabold text-[#0F172A] mb-2">Enquiry Submitted!</h2>
      <p className="text-[15px] text-[#64748B] mb-6">Our MNRE-certified installer will call you within <strong className="text-[#059669]">24 hours</strong>. A confirmation email has been sent.</p>
      <p className="text-[12.5px] text-[#94A3B8] mb-6">Reference ID: SB-{Date.now().toString().slice(-6)}</p>
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <a href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 py-3 px-6 bg-[#25D366] text-white font-bold rounded-xl text-[14px]">
          💬 Chat on WhatsApp
        </a>
        <a href={`tel:${PHONE}`}
          className="flex items-center justify-center gap-2 py-3 px-6 bg-[#4F46E5] text-white font-bold rounded-xl text-[14px]">
          📞 Call Us Now
        </a>
      </div>
    </div>
  )

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-2xl shadow-sm overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#4F46E5] to-[#7C3AED] px-7 py-6">
        <h2 className="text-white font-extrabold text-[20px] mb-1">Get Free Solar Consultation</h2>
        <p className="text-white/80 text-[14px]">Fill 3 quick steps — expert callback within 24 hours</p>
      </div>

      {/* Progress */}
      <div className="px-7 pt-6 pb-2">
        <div className="flex items-center gap-2 mb-2">
          {[1,2,3].map(s => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[13px] font-bold flex-shrink-0 transition-all ${s < step ? 'bg-[#059669] text-white' : s === step ? 'bg-[#4F46E5] text-white' : 'bg-[#F1F5F9] text-[#94A3B8]'}`}>
                {s < step ? '✓' : s}
              </div>
              {s < 3 && <div className={`flex-1 h-[2px] rounded-full transition-all ${s < step ? 'bg-[#059669]' : 'bg-[#E2E8F0]'}`} />}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 text-[11px] font-semibold text-center">
          <span className={step >= 1 ? 'text-[#4F46E5]' : 'text-[#94A3B8]'}>Contact Info</span>
          <span className={step >= 2 ? 'text-[#4F46E5]' : 'text-[#94A3B8]'}>Your Setup</span>
          <span className={step >= 3 ? 'text-[#4F46E5]' : 'text-[#94A3B8]'}>Preferences</span>
        </div>
      </div>

      <div className="px-7 pb-7 pt-4">
        {step === 1 && (
          <div className="space-y-4">
            <div><label className="block text-[13px] font-semibold text-[#1E293B] mb-1.5">Full Name *</label><input className={inp} placeholder="Ramesh Kumar" value={form.name} onChange={e => set('name',e.target.value)} /></div>
            <div><label className="block text-[13px] font-semibold text-[#1E293B] mb-1.5">Mobile Number *</label><input className={inp} type="tel" placeholder="+91 98765 43210" value={form.phone} onChange={e => set('phone',e.target.value)} /></div>
            <div><label className="block text-[13px] font-semibold text-[#1E293B] mb-1.5">Email (optional)</label><input className={inp} type="email" placeholder="you@example.com" value={form.email} onChange={e => set('email',e.target.value)} /></div>
            <div className="flex gap-3 text-[12px] text-[#94A3B8] pt-1"><span>🔒 100% Private</span><span>📞 No spam</span><span>✅ Free service</span></div>
            <button onClick={() => setStep(2)} disabled={!form.name.trim() || form.phone.length < 10}
              className="w-full py-3.5 bg-[#4F46E5] text-white font-bold text-[15px] rounded-xl hover:bg-[#4338CA] transition-all disabled:opacity-40 disabled:cursor-not-allowed">
              Continue →
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <div>
              <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">Your City</label>
              <ChipRow opts={CITIES.map(c=>c.name)} val={form.city} onChange={v=>set('city',v)} />
            </div>
            <div><label className="block text-[13px] font-semibold text-[#1E293B] mb-1.5">Monthly Electricity Bill *</label><input className={inp} type="number" placeholder="e.g. 2500" value={form.bill} onChange={e => set('bill',e.target.value)} /></div>
            <div>
              <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">Property Type</label>
              <ChipRow opts={['🏠 Residential','🏢 Commercial']} val={form.prop==='residential'?'🏠 Residential':'🏢 Commercial'} onChange={v=>set('prop',v.includes('Residential')?'residential':'commercial')} />
            </div>
            {form.prop==='residential' && <p className="text-[12px] text-[#059669] font-semibold">✓ Eligible for ₹1,08,000 total subsidy</p>}
            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="px-5 py-3 border border-[#E2E8F0] text-[#64748B] rounded-xl text-[14px] font-medium hover:border-[#CBD5E1] transition-all">← Back</button>
              <button onClick={() => setStep(3)} disabled={!form.bill} className="flex-1 py-3 bg-[#4F46E5] text-white font-bold text-[15px] rounded-xl hover:bg-[#4338CA] transition-all disabled:opacity-40">Continue →</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <div>
              <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">Preferred Contact Time</label>
              <ChipRow opts={prefTimes} val={form.time} onChange={v=>set('time',v)} />
            </div>
            <div>
              <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">Financing Preference</label>
              <ChipRow opts={finOpts} val={form.fin} onChange={v=>set('fin',v)} />
            </div>
            <div>
              <label className="block text-[13px] font-semibold text-[#1E293B] mb-1.5">Any questions or notes? (optional)</label>
              <textarea className={inp + ' resize-none h-[80px]'} placeholder="e.g. Can you install on a terrace? Is there net metering in my area?" value={form.msg} onChange={e => set('msg',e.target.value)} />
            </div>
            {/* Summary */}
            <div className="bg-[#EEF2FF] border border-[#C7D2FE] rounded-xl p-4 text-[13px] space-y-1.5">
              <div className="font-bold text-[#4F46E5] mb-2 text-[12px] uppercase tracking-wider">Your Summary</div>
              <div className="flex justify-between"><span className="text-[#64748B]">Name</span><span className="font-semibold text-[#0F172A]">{form.name}</span></div>
              <div className="flex justify-between"><span className="text-[#64748B]">City</span><span className="font-semibold text-[#0F172A]">{form.city}</span></div>
              <div className="flex justify-between"><span className="text-[#64748B]">Monthly Bill</span><span className="font-semibold text-[#0F172A]">₹{parseInt(form.bill||'0').toLocaleString('en-IN')}</span></div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(2)} className="px-5 py-3 border border-[#E2E8F0] text-[#64748B] rounded-xl text-[14px] font-medium hover:border-[#CBD5E1] transition-all">← Back</button>
              <button onClick={submit} disabled={loading}
                className="flex-1 py-3 bg-[#4F46E5] text-white font-bold text-[15px] rounded-xl hover:bg-[#4338CA] transition-all disabled:opacity-60">
                {loading ? '⏳ Submitting...' : 'Get Free Quote →'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
