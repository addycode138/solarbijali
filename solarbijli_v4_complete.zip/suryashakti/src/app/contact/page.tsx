import type { Metadata } from 'next'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import PageHeader from '@/components/shared/PageHeader'
import ContactFormClient from './ContactFormClient'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export const metadata: Metadata = {
  title: 'Contact SolarBijli | Free Solar Consultation UP | Call 7373734778',
  description: 'Contact SolarBijli for free solar consultation in Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur, Shamli & all West UP. Call 7373734778 or WhatsApp. MNRE certified. ₹1,08,000 subsidy.',
  keywords: ['contact SolarBijli', 'solar consultation UP', 'solar installer Noida Ghaziabad contact', 'solar company Muzaffarnagar Saharanpur phone', 'solar installer Baraut Baghpat'],
  alternates: { canonical: `${SITE_URL}/contact` },
}

const localBusinessSchema = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  name: 'SolarBijli',
  description: 'Solar panel installation platform for Uttar Pradesh with MNRE certified installers.',
  telephone: '+917373734778',
  email: 'pankajyadi@gmail.com',
  url: SITE_URL,
  address: { '@type': 'PostalAddress', addressRegion: 'Uttar Pradesh', addressCountry: 'IN' },
  areaServed: ['Noida', 'Greater Noida', 'Ghaziabad', 'Meerut', 'Baraut', 'Baghpat', 'Muzaffarnagar', 'Saharanpur', 'Shamli', 'Hapur', 'Bulandshahr', 'Moradabad'],
  openingHoursSpecification: { '@type': 'OpeningHoursSpecification', dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'], opens: '09:00', closes: '20:00' },
  aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.9', reviewCount: '247', bestRating: '5' },
}

export default function ContactPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }} />
      <Navbar />
      <PageHeader
        tag="Get in Touch"
        h1="Contact SolarBijli — Free Solar Consultation"
        desc="Talk to our solar experts. Free site survey, subsidy paperwork handled, MNRE certified installers. We respond within 24 hours."
        breadcrumb={[{ href: '/', label: 'Home' }, { href: '/contact', label: 'Contact' }]}
      />

      <div className="max-w-[1280px] mx-auto px-5 py-14">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] rounded-2xl p-7 text-white">
              <h2 className="font-extrabold text-[20px] mb-4">Contact Details</h2>
              <div className="space-y-4">
                <a href="tel:7373734778" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">📞</div>
                  <div>
                    <div className="font-bold">+91 73737 34778</div>
                    <div className="text-[12px] text-white/70">Mon–Sat 9am–8pm IST</div>
                  </div>
                </a>
                <a href="https://wa.me/917373734778" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">💬</div>
                  <div>
                    <div className="font-bold">WhatsApp Us</div>
                    <div className="text-[12px] text-white/70">Get instant replies</div>
                  </div>
                </a>
                <a href="mailto:pankajyadi@gmail.com" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">📧</div>
                  <div>
                    <div className="font-bold">pankajyadi@gmail.com</div>
                    <div className="text-[12px] text-white/70">Email us anytime</div>
                  </div>
                </a>
              </div>
            </div>

            <div className="bg-white border border-[#E2E8F0] rounded-2xl p-6">
              <h3 className="font-bold text-[16px] text-[#0F172A] mb-4">Cities We Serve</h3>
              {[
                { c: 'Noida', d: 'Gautam Buddha Nagar' },
                { c: 'Greater Noida', d: 'Gautam Buddha Nagar' },
                { c: 'Meerut', d: 'Meerut District' },
                { c: 'Shamli', d: 'Shamli District' },
              ].map(city => (
                <div key={city.c} className="flex items-center justify-between py-2.5 border-b border-[#E2E8F0] last:border-0">
                  <div>
                    <div className="font-semibold text-[14px] text-[#0F172A]">{city.c}</div>
                    <div className="text-[12px] text-[#94A3B8]">{city.d}</div>
                  </div>
                  <span className="text-[11px] bg-[#ECFDF5] text-[#047857] px-2 py-0.5 rounded-full font-semibold">Available</span>
                </div>
              ))}
            </div>

            <div className="bg-[#FFFBEB] border border-[#FDE68A] rounded-2xl p-5">
              <h3 className="font-bold text-[15px] text-[#92400E] mb-2">🎁 What You Get — Free</h3>
              <ul className="space-y-2 text-[13.5px] text-[#78350F]">
                <li className="flex gap-2"><span>✅</span>Solar site survey</li>
                <li className="flex gap-2"><span>✅</span>PM Surya Ghar portal registration</li>
                <li className="flex gap-2"><span>✅</span>UPNEDA subsidy paperwork</li>
                <li className="flex gap-2"><span>✅</span>Bank loan assistance</li>
                <li className="flex gap-2"><span>✅</span>PVVNL net meter application</li>
                <li className="flex gap-2"><span>✅</span>2 years free O&M visits</li>
              </ul>
            </div>
          </div>

          {/* Contact form */}
          <div className="lg:col-span-3">
            <ContactFormClient />
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}
