import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export const metadata: Metadata = {
  title: 'Why Go Solar in UP? 10 Reasons | Benefits, ROI & Savings | SolarBijli',
  description: 'Why you should install rooftop solar in Uttar Pradesh. Save ₹1,500–₹3,000/month on electricity bills, get ₹1,08,000 government subsidy, 4-5 year payback period. Real UP data.',
  keywords: ['why go solar UP', 'benefits of solar energy UP', 'solar panel advantages Noida', 'solar ROI Uttar Pradesh', 'solar savings UP', 'is solar worth it UP'],
  alternates: { canonical: `${SITE_URL}/why-solar` },
}

const schema = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: 'Why Go Solar in Uttar Pradesh? 10 Compelling Reasons (2025)',
  description: 'Detailed analysis of why rooftop solar is one of the best investments for UP homeowners in 2025.',
  author: { '@type': 'Organization', name: 'SolarBijli' },
  datePublished: '2025-01-01',
  dateModified: '2025-03-01',
}

const reasons = [
  {
    num: '01', icon: '💰', title: 'India\'s Highest Solar Subsidy — ₹1,08,000 in UP',
    body: 'UP residents get two subsidies: ₹78,000 from Central Government (PM Surya Ghar) + ₹30,000 from UP State (UPNEDA). Combined ₹1,08,000 makes UP the most subsidised solar state in India. This drastically reduces your net investment.',
    stat: '₹1,08,000', statLabel: 'Total Subsidy',
  },
  {
    num: '02', icon: '☀️', title: '5.4–5.6 Peak Sun Hours — One of India\'s Best',
    body: 'Western Uttar Pradesh receives 5.4–5.6 peak sun hours per day on average, among the highest in India. This means your solar panels generate maximum electricity, improving your ROI significantly compared to states with lower sun hours like Northeast India (3.5–4.5 hours).',
    stat: '5.5 hrs', statLabel: 'Daily Sun Hours',
  },
  {
    num: '03', icon: '📈', title: 'Electricity Bills Rising 8% Every Year in UP',
    body: 'PVVNL and UPPCL electricity tariffs have increased by an average of 8% annually over the past decade. A ₹2,500 bill today will be ₹3,700 in 5 years and ₹5,600 in 10 years. Solar locks your energy cost at ₹0 for 25+ years.',
    stat: '8%', statLabel: 'Annual Tariff Hike',
  },
  {
    num: '04', icon: '⚡', title: 'Fast Payback: 4–5 Years Then Pure Profit',
    body: 'A typical 3kW system in UP pays back in 4–5 years. After payback, you have 20+ years of completely free electricity. If your system lasts 25 years (standard panel warranty), your total savings are ₹7–₹10 lakh.',
    stat: '4–5 yrs', statLabel: 'Payback Period',
  },
  {
    num: '05', icon: '🏦', title: 'Zero Collateral Loans at 6.5–7% — Lower Than Most EMIs',
    body: 'SBI, Canara Bank, Union Bank, and PNB offer 10-year solar loans at 6.5–7% p.a. with no collateral required up to ₹2 lakh. After the ₹1,08,000 subsidy, a 3kW system needs a loan of only ₹37,000–₹42,000 — EMI is just ₹430–₹480/month!',
    stat: '6.5%', statLabel: 'Lowest Loan Rate',
  },
  {
    num: '06', icon: '🌙', title: 'Net Metering — Earn Even at Night',
    body: 'PVVNL supports net metering for all grid-connected solar systems. Electricity your panels generate during the day but you don\'t use flows to the grid, earning you billing credits. Your bill accounts for net consumption (units used − units exported). Many UP homes achieve ₹0 bills.',
    stat: '₹0', statLabel: 'Target Monthly Bill',
  },
  {
    num: '07', icon: '🏠', title: 'Increases Your Property Value',
    body: 'Homes with solar panels command a 3–5% premium in the real estate market in UP. Buyers value the reduced electricity bills and free energy. A ₹1.5 lakh solar investment can add ₹4–₹6 lakh to your property value in urban UP markets.',
    stat: '3–5%', statLabel: 'Property Value Increase',
  },
  {
    num: '08', icon: '🌱', title: 'Significantly Reduce Your Carbon Footprint',
    body: 'A 3kW solar system in UP offsets approximately 1,200–1,400 kg of CO₂ per year — equivalent to planting 40 trees annually. Over 25 years, that\'s 30,000–35,000 kg of CO₂ avoided. Solar is one of the most impactful individual actions for climate change.',
    stat: '1.2T', statLabel: 'CO₂ Saved Annually',
  },
  {
    num: '09', icon: '🔌', title: 'Power Cuts? Solar + Grid = Uninterrupted Power',
    body: 'While on-grid systems need grid power to operate (for safety reasons), the net result is dramatically fewer effective power cuts — your solar reduces your dependence on the grid during peak hours. With an optional battery backup, you get complete energy independence.',
    stat: '25 yrs', statLabel: 'Panel Warranty',
  },
  {
    num: '10', icon: '💼', title: 'Tax Benefits for Commercial Properties',
    body: 'Commercial and industrial solar installations in UP qualify for 40% accelerated depreciation in Year 1 under the Income Tax Act. This means businesses can write off 40% of the solar investment from taxable income, making the effective cost significantly lower.',
    stat: '40%', statLabel: 'Depreciation Benefit',
  },
]

export default function WhySolarPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <Navbar />

      <PageHeader
        tag="Why Solar in UP?"
        h1="10 Reasons Why Solar is the Best Investment for UP Homes in 2025"
        desc="Real data, real numbers. Why rooftop solar in Uttar Pradesh makes more financial sense than anywhere else in India."
        breadcrumb={[{ href: '/', label: 'Home' }, { href: '/why-solar', label: 'Why Solar' }]}
      />

      {/* Key metrics */}
      <div className="bg-white border-b border-[#E2E8F0] py-10 px-5">
        <div className="max-w-[1280px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { n: '₹1,08,000', l: 'Government Subsidy (UP)', c: '#4F46E5' },
            { n: '4–5 Years', l: 'Average Payback Period', c: '#059669' },
            { n: '₹7–10 Lakh', l: '25-Year Total Savings', c: '#D97706' },
            { n: '300 Units', l: 'Free Electricity Monthly', c: '#0F172A' },
          ].map(s => (
            <div key={s.l} className="text-center p-4">
              <div className="text-[28px] font-black tracking-tight" style={{ color: s.c }}>{s.n}</div>
              <div className="text-[13px] text-[#64748B] mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 10 reasons */}
      <div className="max-w-[1280px] mx-auto px-5 py-14">
        <div className="space-y-6">
          {reasons.map((r, i) => (
            <div key={r.num} className="bg-white border border-[#E2E8F0] rounded-2xl p-7 hover:border-[#4F46E5] hover:shadow-lg transition-all">
              <div className="flex flex-col md:flex-row md:items-start gap-5">
                <div className="flex items-center gap-4 md:flex-col md:text-center md:items-center md:w-[100px] flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-[#EEF2FF] flex items-center justify-center text-2xl">{r.icon}</div>
                  <div className="md:mt-2">
                    <div className="text-[22px] font-black text-[#4F46E5] tracking-tight">{r.stat}</div>
                    <div className="text-[11px] text-[#94A3B8] font-medium">{r.statLabel}</div>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[11px] font-black text-[#94A3B8] tracking-wider">{r.num}</span>
                    <h2 className="text-[17px] font-extrabold text-[#0F172A] tracking-tight leading-snug">{r.title}</h2>
                  </div>
                  <p className="text-[14.5px] text-[#64748B] leading-relaxed">{r.body}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison table */}
        <div className="mt-14">
          <h2 className="text-[28px] font-extrabold text-[#0F172A] tracking-tight mb-6">Solar vs Electricity Bill — 25 Year Comparison</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse rounded-xl overflow-hidden shadow-sm">
              <thead>
                <tr className="bg-[#0F172A] text-white">
                  <th className="px-4 py-3 text-left text-[13px] font-bold">Year</th>
                  <th className="px-4 py-3 text-right text-[13px] font-bold">Electricity Bill (8% hike/yr)</th>
                  <th className="px-4 py-3 text-right text-[13px] font-bold">Solar EMI / Cost</th>
                  <th className="px-4 py-3 text-right text-[13px] font-bold text-[#34D399]">Net Saving</th>
                </tr>
              </thead>
              <tbody>
                {[
                  [1, 2500, 638, 1862],
                  [2, 2700, 638, 2062],
                  [3, 2916, 638, 2278],
                  [5, 3400, 638, 2762],
                  [7, 4080, 0, 4080],
                  [10, 5400, 0, 5400],
                  [15, 7900, 0, 7900],
                  [20, 11600, 0, 11600],
                  [25, 17000, 0, 17000],
                ].map(([yr, bill, emi, saving]) => (
                  <tr key={yr} className={`border-b border-[#E2E8F0] ${yr as number >= 7 ? 'bg-[#ECFDF5]' : yr === 1 ? 'bg-white' : 'bg-[#F8FAFC]'}`}>
                    <td className="px-4 py-3 text-[13px] font-semibold text-[#0F172A]">Year {yr}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#EF4444]">₹{(bill as number).toLocaleString('en-IN')}/mo</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#64748B]">
                      {emi as number > 0 ? `₹${(emi as number).toLocaleString('en-IN')}/mo` : <span className="text-[#059669] font-bold">₹0 (Paid off)</span>}
                    </td>
                    <td className="px-4 py-3 text-right text-[13px] font-bold text-[#059669]">₹{(saving as number).toLocaleString('en-IN')}/mo</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-[11.5px] text-[#94A3B8] mt-2">*Assumes ₹2,500/month current bill, 3kW system, Canara Bank loan at 6.5%, loan paid off in Year 7. EMI = ₹638/month after subsidy prepayment. Bill increases 8% annually.</p>
        </div>

        {/* Internal links */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { href: '/muft-bijli-yojana', title: 'PM Surya Ghar Guide', desc: 'Full details of ₹1,08,000 subsidy scheme' },
            { href: '/solar-installation-process', title: 'Installation Process', desc: 'Step-by-step: survey to commissioning' },
            { href: '/calculator', title: 'Solar Calculator', desc: 'Calculate your exact savings & EMI' },
          ].map(l => (
            <Link key={l.href} href={l.href}
              className="bg-white border border-[#E2E8F0] rounded-xl p-5 hover:border-[#4F46E5] hover:shadow-md transition-all block">
              <div className="font-bold text-[#0F172A] mb-1">{l.title} →</div>
              <div className="text-[13px] text-[#64748B]">{l.desc}</div>
            </Link>
          ))}
        </div>
      </div>

      <CtaBanner />
      <Footer />
    </>
  )
}
