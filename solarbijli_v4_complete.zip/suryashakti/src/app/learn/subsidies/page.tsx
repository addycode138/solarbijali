import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'
import { SUBSIDY_SLABS } from '@/lib/constants'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Solar Subsidy Guide UP 2025 | PM Surya Ghar + UPNEDA | SolarBijli',
  description: 'Complete solar subsidy guide for Uttar Pradesh 2025. PM Surya Ghar (₹78,000) + UPNEDA state subsidy (₹30,000) = ₹1,08,000 total. How to claim, eligibility, timeline.',
  alternates: { canonical: `${SITE_URL}/learn/subsidies` },
}
export default function SubsidiesPage() {
  return (<>
    <Navbar/>
    <PageHeader tag="Subsidy Guide" h1="Solar Subsidy Guide for Uttar Pradesh 2025" desc="PM Surya Ghar Central + UPNEDA State = ₹1,08,000 total. India's highest combined solar subsidy." breadcrumb={[{href:'/',label:'Home'},{href:'/learn/subsidies',label:'Subsidy Guide'}]}/>
    <div className="max-w-[1280px] mx-auto px-5 py-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
      <article className="lg:col-span-2 prose-solar">
        <h2>Subsidy Table — Verified 2025</h2>
        <div className="not-prose overflow-x-auto mb-8">
          <table className="w-full border-collapse rounded-xl overflow-hidden shadow-sm text-[13.5px]">
            <thead><tr className="bg-[#4F46E5] text-white"><th className="px-4 py-3 text-left">System Size</th><th className="px-4 py-3 text-right">Central (PM Surya Ghar)</th><th className="px-4 py-3 text-right">UP State (UPNEDA)</th><th className="px-4 py-3 text-right">Total in UP</th></tr></thead>
            <tbody>
              {[['1 kW','₹30,000','₹15,000','₹45,000'],['2 kW','₹60,000','₹30,000','₹90,000'],['3 kW','₹78,000','₹30,000','₹1,08,000'],['Above 3 kW','₹78,000 (Max)','₹30,000 (Max)','₹1,08,000']].map(([sz,c,s,t],i)=>(
                <tr key={sz} className={`border-b border-[#E2E8F0] ${i===2?'bg-[#ECFDF5] font-semibold':i%2===0?'bg-white':'bg-[#EEF2FF]'}`}>
                  <td className="px-4 py-3 font-medium">{sz}</td>
                  <td className="px-4 py-3 text-right text-[#4F46E5]">{c}</td>
                  <td className="px-4 py-3 text-right text-[#4F46E5]">{s}</td>
                  <td className={`px-4 py-3 text-right font-black text-[#059669] ${i===2?'text-[15px]':''}`}>{t}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <h2>How the Central Subsidy (CFA) is Calculated</h2>
        <p>The PM Surya Ghar Central Financial Assistance (CFA) is calculated as a percentage of MNRE benchmark cost:</p>
        <ul>
          <li><strong>For first 2 kW:</strong> 60% of benchmark cost (₹50,000/kW × 60% = ₹30,000/kW)</li>
          <li><strong>For 3rd kW:</strong> 40% of benchmark cost (₹45,000 × 40% = ₹18,000 for the extra 1kW)</li>
          <li><strong>Maximum CFA:</strong> ₹78,000 (₹30,000 + ₹30,000 + ₹18,000) for 3kW+</li>
        </ul>
        <h2>UPNEDA State Subsidy — How It Works</h2>
        <p>The Uttar Pradesh New and Renewable Energy Development Agency (UPNEDA) provides an additional subsidy of <strong>₹15,000 per kW, capped at ₹30,000 per consumer</strong> under the UP Rooftop Solar Policy 2022–2027.</p>
        <p>This state subsidy is <strong>automatically released</strong> after the central CFA is credited to your account — no separate application needed. UPNEDA processes it based on the installation data in the PM Surya Ghar portal.</p>
        <h2>Step-by-Step Subsidy Claim Process</h2>
        <ol>
          <li>Install solar via MNRE-empanelled vendor</li>
          <li>Vendor uploads commissioning documents on pmsuryaghar.gov.in</li>
          <li>DISCOM (PVVNL/UPPCL) inspects and installs net meter</li>
          <li>Commissioning certificate issued on portal</li>
          <li><strong>₹78,000 CFA credited within 30 days</strong> (via MNRE → REC Ltd → bank DBT)</li>
          <li><strong>₹30,000 UPNEDA credited within 2–4 weeks</strong> after CFA</li>
        </ol>
        <div className="not-prose mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {[{href:'/muft-bijli-yojana',t:'PM Surya Ghar Complete Guide'},{href:'/solar-installation-process',t:'Installation Process'},{href:'/learn/loans',t:'Solar Loan Options'},{href:'/calculator',t:'Calculate Your Savings'}].map(l=>(
            <Link key={l.href} href={l.href} className="flex items-center gap-2 bg-[#EEF2FF] border border-[#C7D2FE] rounded-xl px-4 py-3 text-[13.5px] font-semibold text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white transition-all no-underline">
              <span>→</span>{l.t}
            </Link>
          ))}
        </div>
      </article>
      <aside className="space-y-4">
        <div className="bg-[#EEF2FF] border border-[#C7D2FE] rounded-2xl p-5">
          <h3 className="font-bold text-[15px] text-[#4F46E5] mb-3">Quick Links</h3>
          <div className="space-y-2"><a href="https://pmsuryaghar.gov.in" target="_blank" rel="noopener noreferrer" className="block text-[13px] text-[#4F46E5] hover:underline">→ pmsuryaghar.gov.in (Apply)</a><a href="https://www.jansamarth.in" target="_blank" rel="noopener noreferrer" className="block text-[13px] text-[#4F46E5] hover:underline">→ jansamarth.in (Loan)</a><a href="https://upneda.org.in" target="_blank" rel="noopener noreferrer" className="block text-[13px] text-[#4F46E5] hover:underline">→ upneda.org.in (UP State)</a></div>
        </div>
        <Link href="/contact" className="block bg-[#4F46E5] text-white text-center font-bold text-[15px] py-4 rounded-xl hover:bg-[#4338CA] transition-all no-underline">Get Free Consultation →</Link>
      </aside>
    </div>
    <CtaBanner/>
    <Footer/>
  </>)
}
