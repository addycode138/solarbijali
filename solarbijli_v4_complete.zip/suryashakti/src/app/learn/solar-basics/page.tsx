import type { Metadata } from 'next'
import Link from 'next/link'
import { Zap, ArrowRight, Sun } from 'lucide-react'
import SiteLayout from '@/components/layout/SiteLayout'
import Section, { SectionHeading } from '@/components/ui/Section'

export const metadata: Metadata = {
  title: 'Solar Panel Basics — How Solar Works in UP | SolarBijli',
  description: 'Learn how solar panels work, types of panels, on-grid vs off-grid, inverters, net metering, and what to look for when buying solar in UP.',
}

const panelTypes = [
  { name: 'Monocrystalline', efficiency: '20–22%', life: '25+ years', cost: '₹42–48/W', best: 'Best for limited roof space. Highest efficiency. Our top recommendation.', badge: 'Recommended' },
  { name: 'Polycrystalline', efficiency: '16–18%', life: '20–25 years', cost: '₹35–40/W', best: 'Good budget option. Slightly larger footprint for same output.', badge: '' },
  { name: 'Bifacial', efficiency: '22–25%', life: '25+ years', cost: '₹50–58/W', best: 'Generates from both sides. Great for flat roofs or ground mounts.', badge: 'Premium' },
]

export default function SolarBasicsPage() {
  return (
    <SiteLayout>
      <div className="pt-20">
        <Section>
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sun bg-sun/10 border border-sun/20 px-3 py-1 rounded-full mb-4">
              Education Guide
            </span>
            <h1 className="font-syne font-800 text-4xl sm:text-5xl text-white mb-4">
              Solar Panel <span className="text-sun">Basics</span>
            </h1>
            <p className="text-slate-400 text-xl leading-relaxed">
              Everything you need to know before buying solar in Uttar Pradesh — explained simply.
            </p>
          </div>
        </Section>

        <Section dark>
          <div className="max-w-3xl space-y-10">
            <div>
              <h2 className="font-syne font-700 text-2xl text-white mb-4 flex items-center gap-3">
                <Sun className="w-7 h-7 text-sun" /> How Do Solar Panels Work?
              </h2>
              <p className="text-slate-400 leading-relaxed mb-4">
                Solar panels (photovoltaic cells) convert sunlight directly into DC electricity. An inverter converts this to AC
                power used by your home appliances. Any surplus power is fed back to the UPPCL grid through a net meter,
                earning you credits on your next bill.
              </p>
              <p className="text-slate-400 leading-relaxed">
                In Uttar Pradesh, a 1 kW system produces approximately <strong className="text-white">4.2–4.5 units (kWh)</strong> per
                day on average, factoring in cloud cover, dust, and seasonal variation.
              </p>
            </div>

            <div>
              <h2 className="font-syne font-700 text-2xl text-white mb-4 flex items-center gap-3">
                <Zap className="w-7 h-7 text-sun" /> On-Grid vs Off-Grid
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="card-dark-solid rounded-xl p-5 border-l-2 border-leaf">
                  <h3 className="font-syne font-600 text-white mb-2">On-Grid (Recommended)</h3>
                  <ul className="text-slate-400 text-sm space-y-1.5">
                    <li>✓ Connected to UPPCL/PVVNL grid</li>
                    <li>✓ Net metering earns bill credits</li>
                    <li>✓ No battery needed — lower cost</li>
                    <li>✓ Eligible for PM Surya Ghar subsidy</li>
                    <li>✗ No power during grid outage</li>
                  </ul>
                </div>
                <div className="card-dark-solid rounded-xl p-5 border-l-2 border-sky-600">
                  <h3 className="font-syne font-600 text-white mb-2">Off-Grid / Hybrid</h3>
                  <ul className="text-slate-400 text-sm space-y-1.5">
                    <li>✓ Works during power cuts</li>
                    <li>✓ Good for areas with frequent outages</li>
                    <li>✗ Battery adds ₹60,000–₹1,20,000 cost</li>
                    <li>✗ Battery replacement every 5–8 years</li>
                    <li>✗ Not eligible for central subsidy</li>
                  </ul>
                </div>
              </div>
              <p className="text-slate-500 text-sm mt-3">
                For most UP households with grid access, on-grid is the clear choice. Our calculator is designed for on-grid systems.
              </p>
            </div>
          </div>
        </Section>

        <Section>
          <SectionHeading badge="Panels" title="Types of Solar" highlight="Panels" description="Choosing the right panel type depends on your roof size, budget, and long-term goals." />
          <div className="grid lg:grid-cols-3 gap-6">
            {panelTypes.map((p) => (
              <div key={p.name} className="card-dark-solid rounded-2xl p-6">
                {p.badge && (
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium mb-3 inline-block ${p.badge === 'Recommended' ? 'bg-leaf/20 text-leaf' : 'bg-sun/20 text-sun'}`}>
                    {p.badge}
                  </span>
                )}
                <h3 className="font-syne font-700 text-white text-lg mb-4">{p.name}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-slate-400">Efficiency</span><span className="text-white">{p.efficiency}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Lifespan</span><span className="text-white">{p.life}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Cost</span><span className="text-sun">{p.cost}</span></div>
                </div>
                <p className="text-slate-400 text-sm mt-4 pt-4 border-t border-sky-800/40">{p.best}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 card-dark rounded-2xl p-8 text-center">
            <h3 className="font-syne font-700 text-white text-xl mb-3">Still confused which panel to choose?</h3>
            <p className="text-slate-400 mb-6">Our calculator recommends the right system size for your bill. Our certified partners in your city will advise the best panel brand during the free site survey.</p>
            <Link href="/calculator" className="inline-flex items-center gap-2 bg-sun text-sky-950 font-syne font-700 px-8 py-4 rounded-xl hover:bg-sun-300 transition-all">
              Get My Recommendation <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </Section>
      </div>
    </SiteLayout>
  )
}
