import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'
import { BANK_LOANS } from '@/lib/constants'
const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'
export const metadata: Metadata = {
  title: 'Solar Loan Options 2025 | SBI, Canara, Union, PNB Rates | UP | SolarBijli',
  description: 'Compare solar loan options for PM Surya Ghar in UP 2025. SBI 7%, Canara Bank 6.5%, Union Bank 7%, PNB 7%. No collateral up to ₹2L, 10-year tenure, 6-month moratorium.',
  alternates: { canonical: `${SITE_URL}/learn/loans` },
}
function calcEmi(principal: number, ratePA: number, months: number) {
  const mr = ratePA / 100 / 12
  return Math.round((principal * mr * Math.pow(1+mr, months)) / (Math.pow(1+mr, months)-1))
}
export default function LoansPage() {
  const netCost = 42000 // 3kW after ₹1,08,000 subsidy (example)
  const loanAmt = Math.round(netCost * 0.90) // 90% of net cost
  return (<>
    <Navbar/>
    <PageHeader tag="Solar Loans 2025" h1="Solar Loan Comparison for PM Surya Ghar UP (2025)" desc="All major public sector banks offer 6.5–7% solar loans with no collateral and 10-year tenure. Verified data from official bank portals." breadcrumb={[{href:'/',label:'Home'},{href:'/learn/loans',label:'Solar Loans'}]}/>
    <div className="max-w-[1280px] mx-auto px-5 py-12">

      {/* Bank comparison */}
      <h2 className="text-[26px] font-extrabold text-[#0F172A] tracking-tight mb-6">Bank-by-Bank Comparison (≤3kW Systems)</h2>
      <div className="overflow-x-auto mb-10">
        <table className="w-full border-collapse rounded-xl overflow-hidden shadow-sm text-[13.5px]">
          <thead><tr className="bg-[#0F172A] text-white"><th className="px-4 py-3 text-left">Bank</th><th className="px-4 py-3 text-right">Rate (≤3kW)</th><th className="px-4 py-3 text-right">Max Loan</th><th className="px-4 py-3 text-right">Tenure</th><th className="px-4 py-3 text-right">EMI on ₹{loanAmt.toLocaleString('en-IN')}</th><th className="px-4 py-3 text-center">Processing Fee</th></tr></thead>
          <tbody>
            {BANK_LOANS.map((b, i) => (
              <tr key={b.bank} className={`border-b border-[#E2E8F0] ${i===0?'bg-[#ECFDF5] font-semibold':i%2===0?'bg-white':'bg-[#F8FAFC]'}`}>
                <td className="px-4 py-3"><span className="font-bold">{b.bank}</span>{i===0&&<span className="ml-2 text-[10px] bg-[#059669] text-white px-2 py-0.5 rounded-full">Lowest Rate</span>}<br/><span className="text-[11px] text-[#94A3B8]">{b.product}</span></td>
                <td className="px-4 py-3 text-right font-bold text-[#4F46E5]">{b.rateUpto3kw}% p.a.</td>
                <td className="px-4 py-3 text-right">₹{(b.maxLoanUpto3kw/100000).toFixed(1)}L</td>
                <td className="px-4 py-3 text-right">{b.maxTenureMonths/12} yrs</td>
                <td className="px-4 py-3 text-right font-bold text-[#059669]">₹{calcEmi(loanAmt,b.rateUpto3kw,b.maxTenureMonths).toLocaleString('en-IN')}/mo</td>
                <td className="px-4 py-3 text-center text-[#059669] font-semibold">{b.processingFee}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[11.5px] text-[#94A3B8] mb-10">*Example on 3kW system after ₹1,08,000 subsidy. Loan = ₹{loanAmt.toLocaleString('en-IN')} (90% of ₹{netCost.toLocaleString('en-IN')} net cost). Rates are floating linked to EBLR/RLLR. Rates as of March 2025.</p>

      {/* Key features */}
      <h2 className="text-[22px] font-extrabold text-[#0F172A] tracking-tight mb-5">Common Features Across All Banks</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
        {[
          { icon:'🔓', title:'No Collateral', desc:'Zero security required for loans up to ₹2 lakh (up to 3kW systems)' },
          { icon:'⏸️', title:'6-Month Moratorium', desc:'Most banks offer a 6-month grace period before EMIs begin — time for installation + subsidy' },
          { icon:'📑', title:'NIL Processing Fees', desc:'All major public sector banks waive processing charges for PM Surya Ghar loans' },
          { icon:'⏩', title:'No Prepayment Penalty', desc:'Pay off your loan early (after receiving ₹1,08,000 subsidy) without any extra charges' },
          { icon:'🏦', title:'Direct to Vendor', desc:'Bank disburses loan directly to the installer — you don\'t handle large cash amounts' },
          { icon:'📱', title:'Online Application', desc:'Apply via jansamarth.in — the government\'s unified loan application portal' },
        ].map(f=>(
          <div key={f.title} className="bg-white border border-[#E2E8F0] rounded-xl p-5 hover:border-[#4F46E5] transition-all">
            <span className="text-2xl mb-3 block">{f.icon}</span>
            <h3 className="font-bold text-[14.5px] text-[#0F172A] mb-1">{f.title}</h3>
            <p className="text-[13px] text-[#64748B]">{f.desc}</p>
          </div>
        ))}
      </div>

      {/* Smart strategy */}
      <div className="bg-[#FFFBEB] border border-[#FDE68A] rounded-2xl p-7 mb-10">
        <h2 className="text-[20px] font-extrabold text-[#92400E] mb-3">💡 The Smart Subsidy Strategy</h2>
        <p className="text-[14.5px] text-[#78350F] leading-relaxed mb-4">Financial experts recommend this approach to minimise your effective cost:</p>
        <ol className="space-y-2 text-[14px] text-[#78350F]">
          <li><strong>1.</strong> Take a bank loan (no collateral) for the entire net cost after subsidy (approx ₹42,000 for 3kW)</li>
          <li><strong>2.</strong> Start paying EMIs (~₹638/month for Canara 6.5%)</li>
          <li><strong>3.</strong> When ₹1,08,000 subsidy arrives in your bank (30–60 days), use it to make a <strong>full/part prepayment</strong></li>
          <li><strong>4.</strong> Result: Loan is almost entirely paid off! Remaining EMI becomes negligible OR loan closes entirely</li>
          <li><strong>5.</strong> Meanwhile: Save ₹1,500–₹3,000/month on electricity bills from day 1!</li>
        </ol>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[{href:'/muft-bijli-yojana',t:'PM Surya Ghar Subsidy Guide'},{href:'/calculator',t:'Solar Savings Calculator'},{href:'/solar-installation-process',t:'Installation Process'},{href:'/contact',t:'Get Free Quote'}].map(l=>(
          <Link key={l.href} href={l.href} className="flex items-center gap-2 bg-white border border-[#E2E8F0] rounded-xl px-5 py-4 font-semibold text-[14px] text-[#4F46E5] hover:border-[#4F46E5] hover:shadow-md transition-all no-underline">
            <span>→</span>{l.t}
          </Link>
        ))}
      </div>
    </div>
    <CtaBanner/>
    <Footer/>
  </>)
}
