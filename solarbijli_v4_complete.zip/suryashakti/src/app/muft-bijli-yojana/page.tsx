import type { Metadata } from 'next'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CtaBanner from '@/components/shared/CtaBanner'
import PageHeader from '@/components/shared/PageHeader'

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://solarbijli.in'

export const metadata: Metadata = {
  title: 'PM Surya Ghar Muft Bijli Yojana 2025 | Complete Guide | ₹1,08,000 Subsidy UP',
  description: 'Complete guide to PM Surya Ghar Muft Bijli Yojana 2025. Get 300 units free electricity monthly + ₹1,08,000 total subsidy in UP (Central ₹78,000 + UPNEDA ₹30,000). How to apply, eligibility, documents, timeline.',
  keywords: ['PM Surya Ghar Muft Bijli Yojana', 'muft bijli yojana UP', 'free electricity solar UP', 'PM Surya Ghar subsidy 2025', 'UPNEDA solar subsidy', '300 units free electricity'],
  alternates: { canonical: `${SITE_URL}/muft-bijli-yojana` },
}

const schemaMarkup = {
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: 'PM Surya Ghar Muft Bijli Yojana 2025 — Complete Guide for UP Residents',
  description: 'Complete guide to PM Surya Ghar Muft Bijli Yojana for Uttar Pradesh residents. Subsidy amounts, eligibility, application process.',
  author: { '@type': 'Organization', name: 'SolarBijli', url: SITE_URL },
  datePublished: '2025-01-01',
  dateModified: '2025-03-01',
}

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    { '@type': 'Question', name: 'What is PM Surya Ghar Muft Bijli Yojana?', acceptedAnswer: { '@type': 'Answer', text: 'PM Surya Ghar Muft Bijli Yojana is a central government scheme launched on February 13, 2024 to install rooftop solar panels on 1 crore households. It provides up to 300 units of free electricity monthly and a Central Financial Assistance (subsidy) of ₹78,000 for 3kW+ systems.' } },
    { '@type': 'Question', name: 'How much total subsidy is available in UP under PM Surya Ghar?', acceptedAnswer: { '@type': 'Answer', text: 'In Uttar Pradesh, residents get ₹1,08,000 total for 3kW+ systems — ₹78,000 from Central Government (PM Surya Ghar CFA) + ₹30,000 from UP State Government (UPNEDA). For 1kW: ₹45,000. For 2kW: ₹90,000.' } },
    { '@type': 'Question', name: 'How to apply for PM Surya Ghar subsidy?', acceptedAnswer: { '@type': 'Answer', text: 'Visit pmsuryaghar.gov.in, register with your DISCOM consumer number, choose an MNRE-empanelled vendor, get installation done, submit documents on the portal, and the subsidy is transferred to your bank account within 30 days of commissioning.' } },
    { '@type': 'Question', name: 'How many free electricity units per month from PM Surya Ghar?', acceptedAnswer: { '@type': 'Answer', text: 'A 3kW rooftop solar system generates approximately 300–450 units of electricity per month in Uttar Pradesh, which is the free electricity target of the scheme. Most families with bills of ₹2,000–₹3,500/month will bring their bill to near zero.' } },
  ],
}

export default function MuftBijliPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaMarkup) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <Navbar />

      <PageHeader
        tag="Government Solar Scheme 2024–2027"
        h1="PM Surya Ghar Muft Bijli Yojana — Complete Guide for UP (2025)"
        desc="Get 300 units of free electricity every month + ₹1,08,000 total subsidy in Uttar Pradesh. Complete application guide, eligibility, documents and timeline."
        breadcrumb={[
          { href: '/', label: 'Home' },
          { href: '/muft-bijli-yojana', label: 'Muft Bijli Yojana' },
        ]}
      />

      <div className="max-w-[1280px] mx-auto px-5 py-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <article className="lg:col-span-2 prose-solar" itemScope itemType="https://schema.org/Article">

          {/* Quick stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10 not-prose">
            {[
              { n: '₹1,08,000', l: 'Total Subsidy in UP', c: 'text-[#4F46E5]' },
              { n: '300 Units', l: 'Free Electricity/Month', c: 'text-[#059669]' },
              { n: '1 Crore', l: 'Target Homes by 2027', c: 'text-[#D97706]' },
              { n: '₹75,021 Cr', l: 'Total Scheme Outlay', c: 'text-[#0F172A]' },
            ].map(s => (
              <div key={s.l} className="bg-white border border-[#E2E8F0] rounded-2xl p-4 text-center shadow-sm">
                <div className={`text-[22px] font-black tracking-tight ${s.c}`}>{s.n}</div>
                <div className="text-[12px] text-[#64748B] mt-1 leading-tight">{s.l}</div>
              </div>
            ))}
          </div>

          <h2>What is PM Surya Ghar Muft Bijli Yojana?</h2>
          <p>
            <strong>PM Surya Ghar Muft Bijli Yojana</strong> (also known as PM Surya Ghar or Pradhan Mantri Surya Ghar Free Electricity Scheme)
            was launched by Prime Minister Narendra Modi on <strong>February 13, 2024</strong>, under the Ministry of New and Renewable Energy (MNRE).
            It is one of the world's largest residential rooftop solar schemes with a total financial outlay of <strong>₹75,021 crore</strong>.
          </p>
          <p>
            The scheme aims to install solar panels on <strong>1 crore (10 million) residential homes</strong> across India by March 2027,
            providing eligible households with <strong>up to 300 units of free electricity every month</strong> and a substantial
            government subsidy directly transferred to their bank accounts.
          </p>

          <h2>Total Subsidy Available in UP — Central + State Combined</h2>
          <p>
            Uttar Pradesh residents are exceptionally well-positioned as they qualify for <strong>two separate subsidies</strong>:
            the Central Government subsidy (PM Surya Ghar CFA) and the UP State subsidy (UPNEDA).
          </p>

          <div className="not-prose my-6">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse rounded-xl overflow-hidden shadow-sm text-[13.5px]">
                <thead>
                  <tr className="bg-[#4F46E5] text-white">
                    <th className="px-4 py-3 text-left font-bold">System Size</th>
                    <th className="px-4 py-3 text-right font-bold">Central (PM Surya Ghar)</th>
                    <th className="px-4 py-3 text-right font-bold">UP State (UPNEDA)</th>
                    <th className="px-4 py-3 text-right font-bold">Total in UP</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['1 kW', '₹30,000', '₹15,000', '₹45,000'],
                    ['2 kW', '₹60,000', '₹30,000', '₹90,000'],
                    ['3 kW', '₹78,000', '₹30,000', '₹1,08,000'],
                    ['Above 3 kW', '₹78,000 (Capped)', '₹30,000 (Capped)', '₹1,08,000 Max'],
                  ].map(([sz, c, s, t], i) => (
                    <tr key={sz} className={`border-b border-[#E2E8F0] ${i === 2 ? 'bg-[#ECFDF5] font-semibold' : i % 2 === 0 ? 'bg-white' : 'bg-[#EEF2FF]'}`}>
                      <td className="px-4 py-3 font-medium text-[#0F172A]">{sz}</td>
                      <td className="px-4 py-3 text-right text-[#4F46E5]">{c}</td>
                      <td className="px-4 py-3 text-right text-[#4F46E5]">{s}</td>
                      <td className={`px-4 py-3 text-right font-black text-[#059669] ${i === 2 ? 'text-[15px]' : ''}`}>{t}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-[11px] text-[#94A3B8] mt-2">*For residential connections only. Subsidy is transferred directly to bank account (DBT). UPNEDA subsidy released after central CFA is disbursed.</p>
          </div>

          <h2>How Many Units of Free Electricity Will You Get?</h2>
          <p>
            A 3 kW solar system in Western UP (with 5.4–5.6 sun hours per day) generates approximately <strong>378–420 units of electricity per month</strong>.
            The scheme provides up to 300 units of this as "free electricity" — meaning most homes with bills of ₹2,000–₹3,500/month
            will see their bills reduce to nearly <strong>₹0 per month</strong> after installation.
          </p>
          <p>
            If you generate more than you consume during the day, the surplus goes to the PVVNL grid via net metering,
            earning credits on your next electricity bill. Additionally, you can <strong>earn ₹17,000–₹18,000 per year</strong> by selling
            surplus electricity back to the grid.
          </p>

          <h2>Eligibility Criteria</h2>
          <ul>
            <li>Must be an Indian citizen</li>
            <li>Must own a house with a suitable rooftop (own or society flat with permission)</li>
            <li>Must have a valid electricity connection (PVVNL/UPPCL consumer number in UP)</li>
            <li>Should not have availed any prior rooftop solar subsidy under any government scheme</li>
            <li>Only <strong>residential connections</strong> qualify for central subsidy (LT domestic/residential meter)</li>
            <li>No prior criminal conviction or pending dues with electricity department</li>
          </ul>

          <h2>Step-by-Step Application Process (pmsuryaghar.gov.in)</h2>
          <ol>
            <li><strong>Register on National Portal:</strong> Visit <a href="https://pmsuryaghar.gov.in" target="_blank" rel="noopener noreferrer" className="text-[#4F46E5] hover:underline">pmsuryaghar.gov.in</a> and register using your mobile number and electricity consumer number</li>
            <li><strong>Apply for Rooftop Solar:</strong> Select Uttar Pradesh as state, choose PVVNL/UPPCL as DISCOM, enter your consumer account number and apply</li>
            <li><strong>Choose an MNRE-Empanelled Vendor:</strong> Select a registered installer from the portal's approved vendor list — all SolarBijli partners are registered and MNRE-empanelled</li>
            <li><strong>Site Survey:</strong> Vendor conducts a free site survey to assess your roof, shade analysis, and electrical load</li>
            <li><strong>Installation:</strong> Solar system is installed as per MNRE specifications (2–3 working days)</li>
            <li><strong>Submit Plant Details:</strong> Upload photos, plant details, and net meter application on the portal</li>
            <li><strong>DISCOM Inspection:</strong> PVVNL/UPPCL conducts technical inspection and installs the net meter (15–30 days)</li>
            <li><strong>Commissioning Certificate:</strong> DISCOM issues commissioning certificate after successful inspection</li>
            <li><strong>Central Subsidy (CFA):</strong> PM Surya Ghar subsidy transferred to your bank within 30 days of commissioning certificate</li>
            <li><strong>UPNEDA State Subsidy:</strong> Additional ₹30,000 UP state subsidy is automatically released by UPNEDA after central CFA</li>
          </ol>

          <h2>Documents Required</h2>
          <ul>
            <li><strong>Aadhaar Card</strong> (identity proof, must be mobile-linked)</li>
            <li><strong>Latest Electricity Bill</strong> (with consumer number clearly visible)</li>
            <li><strong>Bank Account Details</strong> for Direct Benefit Transfer (DBT)</li>
            <li><strong>Aadhaar-linked Bank Account</strong> for subsidy credit</li>
            <li><strong>Property Documents</strong> or self-declaration of rooftop ownership</li>
            <li><strong>Mobile Number</strong> registered with Aadhaar</li>
            <li>Passport-size photograph (optional, for some vendor applications)</li>
          </ul>

          <h2>Solar Loan Options Under the Scheme</h2>
          <p>
            Multiple public sector banks offer <strong>collateral-free solar loans at 7% p.a.</strong> for up to ₹2 lakh
            (for ≤3kW systems) under PM Surya Ghar. The strategy recommended by financial experts:
          </p>
          <ol>
            <li>Take a bank loan (no collateral required up to ₹2L) for the full amount</li>
            <li>Start paying EMIs (the bank pays the vendor/installer directly)</li>
            <li>When the ₹1,08,000 subsidy is received (30–60 days after commissioning), use it to make a <strong>part prepayment</strong> on the loan</li>
            <li>This dramatically reduces your outstanding principal and interest burden</li>
          </ol>
          <p>
            After part-prepayment with the subsidy, many homeowners find their remaining EMI is <strong>lower than their previous monthly electricity bill</strong> — making solar cash-flow positive from month 1.
          </p>

          <h2>PM Surya Ghar Helpline &amp; Contact</h2>
          <p>
            For queries about the PM Surya Ghar scheme:
          </p>
          <ul>
            <li>National Helpline: <strong>15555</strong></li>
            <li>Official Portal: <a href="https://pmsuryaghar.gov.in" target="_blank" rel="noopener noreferrer" className="text-[#4F46E5] hover:underline">pmsuryaghar.gov.in</a></li>
            <li>Loan Application: <a href="https://www.jansamarth.in" target="_blank" rel="noopener noreferrer" className="text-[#4F46E5] hover:underline">jansamarth.in</a></li>
            <li>UPNEDA (UP State): <a href="https://upneda.org.in" target="_blank" rel="noopener noreferrer" className="text-[#4F46E5] hover:underline">upneda.org.in</a></li>
          </ul>

          <h2>Frequently Asked Questions</h2>
          <div className="not-prose space-y-3 mt-4">
            {[
              { q: 'Can I apply for both central and UP state subsidy?', a: 'Yes! UP residents can claim both the PM Surya Ghar Central Financial Assistance (CFA) and the UPNEDA UP State subsidy. The UPNEDA subsidy is automatically processed after the central subsidy is credited. No separate application is needed for the state subsidy.' },
              { q: 'Is PM Surya Ghar only for below poverty line (BPL) families?', a: 'No. PM Surya Ghar is available to all residential homeowners in India regardless of income. There is no income cap or BPL requirement. Any household with a valid residential electricity connection can apply.' },
              { q: 'Can I get subsidy on a 5kW or 10kW system?', a: 'Yes, but the subsidy is capped at ₹1,08,000 (₹78,000 central + ₹30,000 UP state) regardless of system size for above 3kW. So if you install a 5kW system, you still get ₹1,08,000 in subsidy.' },
              { q: 'How long does the subsidy take to reach my account?', a: 'The central CFA (₹78,000) is typically credited within 30 days of the commissioning certificate being issued. The UPNEDA state subsidy (₹30,000) follows within 2–4 weeks after the central subsidy.' },
            ].map(faq => (
              <details key={faq.q} className="bg-white border border-[#E2E8F0] rounded-xl overflow-hidden hover:border-[#4F46E5] transition-colors group">
                <summary className="px-5 py-4 cursor-pointer font-semibold text-[14.5px] text-[#0F172A] flex justify-between items-center gap-3 list-none [&::-webkit-details-marker]:hidden">
                  {faq.q}
                  <span className="w-6 h-6 rounded-full bg-[#EEF2FF] flex items-center justify-center text-[#4F46E5] text-sm flex-shrink-0 transition-transform group-open:rotate-90">›</span>
                </summary>
                <p className="px-5 pb-4 text-[14px] text-[#64748B] leading-relaxed">{faq.a}</p>
              </details>
            ))}
          </div>
        </article>

        {/* Sidebar */}
        <aside className="space-y-5">
          {/* Quick apply card */}
          <div className="bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] rounded-2xl p-6 text-white sticky top-[80px]">
            <h3 className="font-extrabold text-[18px] mb-2">Claim Your ₹1,08,000 Subsidy</h3>
            <p className="text-[13.5px] text-white/80 mb-5">Get a free site survey from our MNRE-certified installer. We handle all subsidy paperwork.</p>
            <div className="space-y-2.5">
              <Link href="/contact"
                className="block w-full text-center py-3 bg-white text-[#4F46E5] font-bold text-[14px] rounded-xl hover:bg-white/90 transition-all">
                Get Free Quote →
              </Link>
              <a href="tel:7373734778"
                className="block w-full text-center py-3 bg-white/15 text-white font-semibold text-[14px] rounded-xl border border-white/25 hover:bg-white/25 transition-all">
                📞 +91 73737 34778
              </a>
            </div>
            <div className="mt-4 space-y-1.5">
              {['✅ MNRE Empanelled', '📋 Full paperwork handled', '⏱️ 24hr callback'].map(p => (
                <p key={p} className="text-[12.5px] text-white/80">{p}</p>
              ))}
            </div>
          </div>

          {/* Related links */}
          <div className="bg-white border border-[#E2E8F0] rounded-2xl p-5">
            <h3 className="font-bold text-[15px] text-[#0F172A] mb-4">Related Guides</h3>
            <div className="space-y-2.5">
              {[
                { href: '/why-solar', label: 'Why Go Solar in UP?' },
                { href: '/solar-installation-process', label: 'Installation Process' },
                { href: '/learn/subsidies', label: 'Subsidy Calculation Guide' },
                { href: '/learn/loans', label: 'Solar Loan Options 2025' },
                { href: '/calculator', label: 'Solar Savings Calculator' },
                { href: '/blog/pm-surya-ghar-subsidy-guide-up-2025', label: 'PM Surya Ghar Blog Post' },
              ].map(l => (
                <Link key={l.href} href={l.href}
                  className="flex items-center gap-2 text-[13.5px] text-[#4F46E5] hover:text-[#4338CA] transition-colors">
                  <span className="text-[10px]">→</span> {l.label}
                </Link>
              ))}
            </div>
          </div>
        </aside>
      </div>

      <CtaBanner
        title="Apply for PM Surya Ghar Scheme via SolarBijli"
        desc="Our MNRE-certified partners handle your entire application — subsidy, net meter, and bank loan paperwork. Completely free."
      />
      <Footer />
    </>
  )
}
