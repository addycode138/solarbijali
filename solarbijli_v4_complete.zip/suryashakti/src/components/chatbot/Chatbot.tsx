'use client'
import { useState, useRef, useEffect, useCallback } from 'react'
import { useI18n } from '@/lib/i18n/context'
import { calculateSolar, formatINR } from '@/lib/calculator'
import { CITIES, PHONE_DISPLAY, WA_NUMBER } from '@/lib/constants'

interface Msg { id: string; role: 'user' | 'bot'; text: string; isHtml?: boolean; time?: string }

type ConvStage = 'greeting' | 'ask_bill' | 'ask_city' | 'ask_tenure' | 'show_result' | 'ask_name' | 'ask_phone' | 'lead_done' | 'free_chat'

interface LeadData { bill?: number; citySlug?: string; tenure?: number; name?: string; phone?: string }

const ALL_CITY_NAMES = CITIES.map(c => c.name.toLowerCase())
const CITY_KEYWORDS: Record<string, string> = {
  noida: 'noida', 'greater noida': 'greater-noida', ghaziabad: 'ghaziabad',
  meerut: 'meerut', baraut: 'baraut', baghpat: 'baghpat',
  muzaffarnagar: 'muzaffarnagar', saharanpur: 'saharanpur',
  shamli: 'shamli', hapur: 'hapur', bulandshahr: 'bulandshahr', moradabad: 'moradabad',
}

function getTimeStr() {
  return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
}

function detectCity(text: string): string | null {
  const lower = text.toLowerCase()
  for (const [key, slug] of Object.entries(CITY_KEYWORDS)) {
    if (lower.includes(key)) return slug
  }
  return null
}

function detectBill(text: string): number | null {
  const match = text.replace(/,/g, '').match(/(?:rs\.?|₹|inr)?\s*(\d{3,6})/i)
  if (match) {
    const n = parseInt(match[1])
    if (n >= 300 && n <= 50000) return n
  }
  return null
}

function buildCalcResult(lead: LeadData): string {
  const city = CITIES.find(c => c.slug === lead.citySlug) ?? CITIES[0]
  const tenure = lead.tenure ?? 10
  const r = calculateSolar({
    monthlyBill: lead.bill ?? 2500,
    city,
    propertyType: 'residential',
    financing: 'loan',
    roofArea: 200,
  })
  const mr = 0.07 / 12
  const loanAmount = Math.min(r.netCost * 0.90, r.systemSizeKw <= 3 ? 200000 : 600000)
  const months = tenure * 12
  const emi = loanAmount > 0
    ? Math.round((loanAmount * mr * Math.pow(1 + mr, months)) / (Math.pow(1 + mr, months) - 1))
    : 0

  const monthlyNetBenefit = Math.round(r.annualSavings / 12) - emi

  return `<div class="calc-result-card">
<div style="background:linear-gradient(135deg,#4F46E5,#7C3AED);color:white;border-radius:14px;padding:14px;margin-bottom:12px">
  <div style="font-size:11px;font-weight:700;opacity:.8;letter-spacing:.08em;margin-bottom:6px">☀️ YOUR SOLAR ESTIMATE</div>
  <div style="font-size:28px;font-weight:900;line-height:1">${formatINR(r.netCost)}</div>
  <div style="font-size:11px;opacity:.75;margin-top:4px">Net cost after ₹${(r.subsidyAmount).toLocaleString('en-IN')} subsidy</div>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
  <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:10px">
    <div style="font-size:10px;color:#94A3B8;font-weight:700;text-transform:uppercase;margin-bottom:4px">System Size</div>
    <div style="font-size:16px;font-weight:800;color:#D97706">${r.systemSizeKw} kW</div>
    <div style="font-size:10px;color:#94A3B8">${r.panelCount} panels</div>
  </div>
  <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:10px">
    <div style="font-size:10px;color:#94A3B8;font-weight:700;text-transform:uppercase;margin-bottom:4px">EMI (${tenure} yrs SBI)</div>
    <div style="font-size:16px;font-weight:800;color:#4F46E5">₹${emi.toLocaleString('en-IN')}/mo</div>
    <div style="font-size:10px;color:#94A3B8">@ 7% p.a.</div>
  </div>
  <div style="background:#ECFDF5;border:1px solid #A7F3D0;border-radius:10px;padding:10px">
    <div style="font-size:10px;color:#047857;font-weight:700;text-transform:uppercase;margin-bottom:4px">Annual Savings</div>
    <div style="font-size:16px;font-weight:800;color:#059669">${formatINR(r.annualSavings)}</div>
    <div style="font-size:10px;color:#047857">₹${Math.round(r.annualSavings/12).toLocaleString('en-IN')}/mo</div>
  </div>
  <div style="background:#EEF2FF;border:1px solid #C7D2FE;border-radius:10px;padding:10px">
    <div style="font-size:10px;color:#4338CA;font-weight:700;text-transform:uppercase;margin-bottom:4px">Net Monthly Gain</div>
    <div style="font-size:16px;font-weight:800;color:${monthlyNetBenefit >= 0 ? '#059669' : '#DC2626'}">₹${Math.abs(monthlyNetBenefit).toLocaleString('en-IN')}${monthlyNetBenefit >= 0 ? ' profit' : ' cost'}</div>
    <div style="font-size:10px;color:#4338CA">savings - EMI</div>
  </div>
</div>
<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:10px;margin-bottom:10px">
  <div style="font-size:11px;font-weight:700;color:#92400E;margin-bottom:4px">🏛️ Subsidies You'll Get</div>
  <div style="font-size:12px;color:#78350F">🏦 Central (PM Surya Ghar): <strong>₹${r.centralSubsidy.toLocaleString('en-IN')}</strong><br/>
  🏗️ UP State (UPNEDA): <strong>₹${r.stateSubsidy.toLocaleString('en-IN')}</strong><br/>
  ✅ Total Subsidy: <strong style="color:#059669">₹${r.subsidyAmount.toLocaleString('en-IN')}</strong> → Direct to bank!</div>
</div>
<div style="background:#F0FDF4;border:1px solid #A7F3D0;border-radius:10px;padding:10px">
  <div style="font-size:11px;font-weight:700;color:#047857;margin-bottom:4px">📈 25-Year Total Savings</div>
  <div style="font-size:22px;font-weight:900;color:#059669">${formatINR(r.savingsOver25Years)}</div>
  <div style="font-size:10px;color:#047857">Payback in just ${r.paybackYears} years · ${r.co2OffsetKgPerYear.toLocaleString()} kg CO₂/yr offset</div>
</div>
</div>`
}

function getInstantReply(input: string, lead: LeadData, stage: ConvStage): {
  text: string; isHtml?: boolean; nextStage?: ConvStage; updateLead?: Partial<LeadData>
} {
  const q = input.toLowerCase().trim()
  const detectedBill = detectBill(input)
  const detectedCity = detectCity(input)

  // Handle free_chat mode
  if (stage === 'free_chat') {
    if (detectedBill) {
      const citySlug = lead.citySlug ?? 'noida'
      const newLead = { ...lead, bill: detectedBill }
      return {
        isHtml: true,
        text: buildCalcResult({ ...newLead, citySlug, tenure: lead.tenure ?? 10 }),
        nextStage: 'ask_name',
        updateLead: { bill: detectedBill },
      }
    }
    if (q.match(/subsid|1.08|108000|कितन|सब्सिडी/)) {
      return {
        isHtml: true,
        text: `<div><strong>UP Solar Subsidy (2025):</strong><br/><br/>
<div style="background:#EEF2FF;border-radius:10px;padding:12px">
  • 1 kW → Central ₹30,000 + UP ₹15,000 = <strong>₹45,000</strong><br/>
  • 2 kW → Central ₹60,000 + UP ₹30,000 = <strong>₹90,000</strong><br/>
  • 3 kW+ → Central ₹78,000 + UP ₹30,000 = <strong style="color:#059669;font-size:1.1em">₹1,08,000</strong><br/>
</div>
<br/>💰 Transferred directly to bank! Tell me your bill for exact estimate.</div>`,
      }
    }
    if (q.match(/net meter|grid|surplus|excess|sell bijli|बेचना/)) {
      return {
        isHtml: true,
        text: `<div><strong>⚡ Net Metering in UP (PVVNL):</strong><br/><br/>
☀️ Day: Solar generates → home uses what's needed<br/>
🔄 Surplus → goes to PVVNL grid (you earn credits)<br/>
🌙 Night: Draw from grid → credits offset the bill<br/><br/>
<strong style="color:#059669">Result: Monthly bill can reach ₹0 or even NEGATIVE!</strong><br/><br/>
📋 Net metering application handled by our partners for FREE in all UP cities. 45–60 day process.<br/><br/>
Want me to calculate your specific savings? Share your monthly bill!</div>`,
      }
    }
    if (q.match(/time|days|din|install|कितना|समय|weeks/)) {
      return {
        isHtml: true,
        text: `<div><strong>📅 Solar Installation Timeline:</strong><br/><br/>
🔍 <strong>Day 1–3:</strong> Free site survey + roof assessment<br/>
📋 <strong>Day 3–7:</strong> PM Surya Ghar portal registration<br/>
✅ <strong>Day 7–10:</strong> DISCOM approval<br/>
🔧 <strong>Day 10–14:</strong> Equipment delivery + installation<br/>
⚡ <strong>Day 15–45:</strong> PVVNL net meter installation<br/>
💰 <strong>Day 30–60:</strong> ₹1,08,000 subsidy → your bank<br/><br/>
<strong>Total: 45–60 days</strong> from call to earning from solar ☀️</div>`,
      }
    }
    if (q.match(/emi|loan|sbi|bank|किस्त|महीना|monthly payment/)) {
      return {
        isHtml: true,
        text: `<div><strong>🏦 Solar Loan Options 2025:</strong><br/><br/>
<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px">
  <strong>Canara Bank</strong> — <span style="color:#059669">6.5% p.a.</span> ← Best rate<br/>
  <strong>SBI</strong> — 7.0% p.a.<br/>
  <strong>PNB / Union Bank / BOI</strong> — 7.0% p.a.<br/><br/>
  ✅ No collateral up to ₹2 lakh<br/>
  ✅ Tenure: 5, 7, 10, or 15 years<br/>
  ✅ Processing fee: NIL<br/>
  ✅ Apply at JanSamarth portal
</div>
<br/>3kW system after ₹1,08,000 subsidy → Net cost ~₹42,000<br/>
→ EMI as low as <strong style="color:#059669">₹638/month for 7 years!</strong><br/><br/>
Monthly saving ₹1,500–₹2,500 minus EMI = profit from day 1! 🎉</div>`,
      }
    }
    if (q.match(/warranty|guarantee|टूट|break|repair|years|साल/)) {
      return {
        isHtml: true,
        text: `<div><strong>🛡️ Solar System Warranty:</strong><br/><br/>
☀️ <strong>25 years</strong> — Panel performance warranty<br/>
⚡ <strong>10 years</strong> — Inverter product warranty<br/>
🔧 <strong>5 years</strong> — Workmanship (installer)<br/>
🌿 <strong>2 years</strong> — Free O&M service visits<br/><br/>
No moving parts = extremely low maintenance!<br/>
Just wash panels monthly with water. 💧<br/><br/>
Our UP partners provide local service in Noida, Meerut, Ghaziabad, Baraut, Muzaffarnagar, Saharanpur & all covered cities. 🛠️</div>`,
      }
    }
    if (q.match(/city|cities|noida|meerut|ghaziabad|baraut|muzaffarnagar|saharanpur|shamli|baghpat|hapur|moradabad|शहर/)) {
      return {
        isHtml: true,
        text: `<div><strong>🗺️ We Serve All West UP:</strong><br/><br/>
🏙️ Noida (GBN) · Greater Noida · Ghaziabad<br/>
🏙️ Meerut · Baraut · Baghpat<br/>
🏙️ Muzaffarnagar · Saharanpur · Shamli<br/>
🏙️ Hapur · Bulandshahr · Moradabad<br/><br/>
All cities under <strong>PVVNL network</strong> — full net metering support!<br/><br/>
Tell me your city + monthly bill for a personalised estimate! 💡</div>`,
      }
    }
    // Fallback with bill prompt
    return {
      isHtml: true,
      text: `<div>I can help you with:<br/><br/>
💰 <strong>Savings calculation</strong> — share your monthly bill!<br/>
🏛️ <strong>₹1,08,000 subsidy</strong> — how to claim it<br/>
📅 <strong>Installation timeline</strong> — 45–60 days<br/>
💳 <strong>EMI options</strong> — from ₹638/month<br/>
⚡ <strong>Net metering</strong> — zero electricity bills!<br/>
🗺️ <strong>12 cities</strong> in West UP<br/><br/>
<strong>Fastest way:</strong> Tell me your monthly bill (e.g. "₹3,000") and I'll calculate everything instantly! ⚡</div>`,
    }
  }

  // FLOW-BASED RESPONSES
  if (stage === 'ask_bill') {
    if (detectedBill) {
      const citySlug = detectedCity ?? lead.citySlug
      if (citySlug) {
        return {
          text: '✅ Got it! Let me now calculate your personalized solar plan...',
          nextStage: 'ask_tenure',
          updateLead: { bill: detectedBill, citySlug },
        }
      }
      return {
        isHtml: true,
        text: `<div>Great! ₹${detectedBill.toLocaleString('en-IN')} noted 📝<br/><br/>Which city are you in?<br/><br/>
<em>Noida · Greater Noida · Ghaziabad · Meerut · Baraut · Muzaffarnagar · Saharanpur · Shamli · Hapur · Bulandshahr · Moradabad</em></div>`,
        nextStage: 'ask_city',
        updateLead: { bill: detectedBill },
      }
    }
    if (detectedCity) {
      return {
        text: `Perfect, ${CITIES.find(c => c.slug === detectedCity)?.name ?? detectedCity}! Now, what's your average monthly electricity bill? (e.g. ₹2,500)`,
        nextStage: 'ask_bill',
        updateLead: { citySlug: detectedCity },
      }
    }
    const billMatch = input.match(/\d+/)
    if (billMatch) {
      const n = parseInt(billMatch[0])
      if (n < 300) return { text: `₹${n} seems very low for solar to be worthwhile. Did you mean ₹${n * 10} or higher? Please re-enter your bill.` }
      if (n > 50000) return { text: `₹${n} seems high — please double-check. Normal residential bills are ₹500–₹15,000.` }
    }
    return { text: 'Please share your approximate monthly electricity bill amount. Example: type "2500" or "₹3,000" 🔢' }
  }

  if (stage === 'ask_city') {
    const slug = detectedCity ?? (q.includes('noida') ? 'noida' : null)
    if (slug) {
      if (lead.bill) {
        return {
          text: '✅ Got your city! One last thing — what loan tenure suits you?',
          nextStage: 'ask_tenure',
          updateLead: { citySlug: slug },
        }
      }
      return {
        text: `${CITIES.find(c => c.slug === slug)?.name}! Now tell me your monthly electricity bill (e.g. ₹2,500) 💡`,
        nextStage: 'ask_bill',
        updateLead: { citySlug: slug },
      }
    }
    return {
      isHtml: true,
      text: `<div>Please select your city from:<br/><br/>
<strong>Noida · Greater Noida · Ghaziabad · Meerut · Baraut · Baghpat · Muzaffarnagar · Saharanpur · Shamli · Hapur · Bulandshahr · Moradabad</strong><br/><br/>
Or type your city name.</div>`,
    }
  }

  if (stage === 'ask_tenure') {
    const tenureMatch = input.match(/(\d+)\s*(?:year|yr|साल)/i) ?? input.match(/^(\d+)$/)
    const tenure = tenureMatch ? parseInt(tenureMatch[1]) : null
    const validTenures = [5, 7, 10, 15]
    if (tenure && validTenures.includes(tenure)) {
      return {
        text: '⚡ Calculating your complete solar plan...',
        nextStage: 'show_result',
        updateLead: { tenure },
      }
    }
    if (q.includes('cash') || q.includes('full') || q.includes('no emi') || q.includes('no loan')) {
      return {
        text: '⚡ Calculating for cash payment...',
        nextStage: 'show_result',
        updateLead: { tenure: 0 },
      }
    }
    return {
      isHtml: true,
      text: `<div><strong>📅 Choose your loan tenure:</strong><br/><br/>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
  <div style="border:2px solid #E2E8F0;border-radius:10px;padding:10px;text-align:center;cursor:pointer">
    <strong>5 years</strong><br/><span style="font-size:11px;color:#64748B">Higher EMI, less interest</span>
  </div>
  <div style="border:2px solid #4F46E5;border-radius:10px;padding:10px;text-align:center;background:#EEF2FF">
    <strong>7 years ⭐</strong><br/><span style="font-size:11px;color:#4F46E5">Most popular</span>
  </div>
  <div style="border:2px solid #E2E8F0;border-radius:10px;padding:10px;text-align:center">
    <strong>10 years</strong><br/><span style="font-size:11px;color:#64748B">Lower EMI</span>
  </div>
  <div style="border:2px solid #E2E8F0;border-radius:10px;padding:10px;text-align:center">
    <strong>15 years</strong><br/><span style="font-size:11px;color:#64748B">Lowest EMI</span>
  </div>
</div>
<br/>Type 5, 7, 10, or 15 — or "cash" if paying full.</div>`,
    }
  }

  if (stage === 'show_result') return { text: '' } // handled by caller

  if (stage === 'ask_name') {
    if (input.trim().length >= 2 && !input.match(/\d/)) {
      return {
        text: `Nice to meet you, ${input.trim()}! 😊 What's your WhatsApp/mobile number? Our certified expert will call you within 2 hours for a FREE site survey.`,
        nextStage: 'ask_phone',
        updateLead: { name: input.trim() },
      }
    }
    if (q.includes('skip') || q.includes('later') || q.includes('no')) {
      return { text: 'No problem! Feel free to ask me anything else about solar. You can also call us: ' + PHONE_DISPLAY, nextStage: 'free_chat' }
    }
    return { text: 'Please share your name so our expert can address you properly when they call. 🙏' }
  }

  if (stage === 'ask_phone') {
    const phoneMatch = input.replace(/\s|-/g, '').match(/(?:\+91|91)?([6-9]\d{9})/)
    if (phoneMatch) {
      return {
        text: '',
        nextStage: 'lead_done',
        updateLead: { phone: phoneMatch[1] },
      }
    }
    if (q.includes('skip') || q.includes('later') || q.includes('no')) {
      return { text: `Thanks for the info! You can reach us at ${PHONE_DISPLAY} or WhatsApp anytime. 🌞`, nextStage: 'free_chat' }
    }
    return { text: 'Please enter a valid 10-digit Indian mobile number. Example: 98765XXXXX' }
  }

  return { text: '' }
}

export default function Chatbot() {
  const { t } = useI18n()
  const [open, setOpen] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [typing, setTyping] = useState(false)
  const [stage, setStage] = useState<ConvStage>('greeting')
  const [lead, setLead] = useState<LeadData>({})
  const [autoOpened, setAutoOpened] = useState(false)
  const [showPulse, setShowPulse] = useState(false)
  const endRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, typing])

  // Auto-open after 4 seconds
  useEffect(() => {
    const t1 = setTimeout(() => setShowPulse(true), 2000)
    const t2 = setTimeout(() => {
      if (!autoOpened) {
        setAutoOpened(true)
        setOpen(true)
      }
    }, 4000)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [])

  // Focus input when open
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 100)
  }, [open])

  const addBot = useCallback((text: string, isHtml = false) => {
    setMsgs(m => [...m, { id: Date.now().toString(), role: 'bot', text, isHtml, time: getTimeStr() }])
  }, [])

  // Initial greeting on open
  useEffect(() => {
    if (open && msgs.length === 0) {
      const delay = setTimeout(() => {
        addBot(
          `<div>Namaste! 🌞 I'm <strong>SolarBot</strong> — your solar expert for Western UP!<br/><br/>
I can:<br/>
💰 <strong>Calculate your live savings</strong> instantly<br/>
🏛️ <strong>Check your ₹1,08,000 subsidy</strong> eligibility<br/>
💳 <strong>Find your best EMI plan</strong> (5–15 years)<br/>
⚡ <strong>Explain net metering</strong> for zero bills<br/>
📅 <strong>Show installation timeline</strong><br/><br/>
<strong>Let's start — what's your average monthly electricity bill?</strong><br/>
<em>Type e.g. "₹2,500" or just "2500"</em></div>`,
          true
        )
        setStage('ask_bill')
      }, 300)
      return () => clearTimeout(delay)
    }
  }, [open, msgs.length, addBot])

  const processStage = useCallback(async (msg: string, currentStage: ConvStage, currentLead: LeadData) => {
    setTyping(true)
    await new Promise(r => setTimeout(r, 500 + Math.random() * 400))
    setTyping(false)

    const reply = getInstantReply(msg, currentLead, currentStage)

    let newLead = currentLead
    if (reply.updateLead) {
      newLead = { ...currentLead, ...reply.updateLead }
      setLead(newLead)
    }

    const nextStage = reply.nextStage ?? currentStage

    // Handle show_result stage
    if (nextStage === 'show_result') {
      const resultHtml = buildCalcResult(newLead)
      addBot(resultHtml, true)
      await new Promise(r => setTimeout(r, 600))
      setTyping(true)
      await new Promise(r => setTimeout(r, 1000))
      setTyping(false)
      addBot(`<div>🎯 <strong>Your plan is ready!</strong><br/><br/>To get a <strong>FREE site survey & confirmed quote</strong> from our MNRE-certified installer, I need just two quick details.<br/><br/>First — <strong>what's your name?</strong> 😊</div>`, true)
      setStage('ask_name')
      return
    }

    // Handle lead_done
    if (nextStage === 'lead_done') {
      try {
        await fetch('/api/leads', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: newLead.name,
            phone: newLead.phone,
            city: newLead.citySlug ?? 'unknown',
            monthlyBill: newLead.bill ?? 0,
            source: 'chatbot-v2',
          }),
        })
      } catch {}

      addBot(
        `<div style="background:linear-gradient(135deg,#059669,#047857);color:white;border-radius:14px;padding:14px">
<div style="font-size:20px;margin-bottom:6px">🎉 Confirmed!</div>
<strong>Thank you, ${newLead.name}!</strong><br/>
Our MNRE-certified installer will call <strong>${newLead.phone}</strong> within <strong>2 hours</strong> for your FREE site survey.<br/><br/>
In the meantime:<br/>
📱 <a href="https://wa.me/${WA_NUMBER}" style="color:#A7F3D0">WhatsApp us</a> for instant replies<br/>
🔢 Try our <a href="/calculator" style="color:#A7F3D0">detailed calculator →</a>
</div>`,
        true
      )
      setStage('free_chat')
      return
    }

    if (reply.text) addBot(reply.text, reply.isHtml)
    setStage(nextStage)
  }, [addBot])

  const handleSend = useCallback(async (text?: string) => {
    const msg = (text || input).trim()
    if (!msg) return
    setInput('')
    setMsgs(m => [...m, { id: Date.now().toString(), role: 'user', text: msg, time: getTimeStr() }])
    await processStage(msg, stage, lead)
  }, [input, stage, lead, processStage])

  const quickReplies: Record<ConvStage, string[]> = {
    greeting: ['₹2,500/month', '₹5,000/month', 'What subsidy do I get?', 'Tell me about solar'],
    ask_bill: ['₹2,500', '₹3,000', '₹5,000', '₹8,000'],
    ask_city: ['Noida', 'Ghaziabad', 'Meerut', 'Muzaffarnagar', 'Baraut', 'Saharanpur'],
    ask_tenure: ['7 years', '10 years', '5 years', '15 years', 'Cash'],
    show_result: [],
    ask_name: [],
    ask_phone: [],
    lead_done: ['Net metering info', 'Installation timeline', 'Warranty details'],
    free_chat: ['Calculate my savings', 'Subsidy details', 'EMI options', 'Net metering'],
  }

  const currentQuickReplies = quickReplies[stage] ?? []

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-24 right-4 sm:right-5 z-50 w-[54px] h-[54px] rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95 relative"
        style={{ background: 'linear-gradient(135deg,#F59E0B,#D97706)', boxShadow: '0 8px 28px rgba(245,158,11,.45)' }}
        aria-label="Open SolarBot chat">
        {open ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        ) : (
          <span className="text-[22px]">☀️</span>
        )}
        {!open && (
          <>
            <span className={`absolute -top-1 -right-1 w-[14px] h-[14px] rounded-full bg-[#059669] border-2 border-white ${showPulse ? 'animate-pulse' : ''}`} />
            {showPulse && !autoOpened && (
              <span className="absolute -top-10 right-0 bg-[#0F172A] text-white text-[11px] font-semibold px-3 py-1.5 rounded-full whitespace-nowrap shadow-lg">
                Free solar estimate 👆
                <span className="absolute bottom-[-5px] right-4 w-2.5 h-2.5 bg-[#0F172A] rotate-45" />
              </span>
            )}
          </>
        )}
      </button>

      {/* Chat window */}
      {open && (
        <div
          className="fixed bottom-[88px] right-3 sm:right-5 z-50 bg-white border border-[#E2E8F0] rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          style={{
            width: 'min(370px, calc(100vw - 24px))',
            height: 'min(580px, calc(100vh - 120px))',
          }}
          role="dialog" aria-label="SolarBot chat" aria-modal="true">

          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 flex-shrink-0" style={{ background: 'linear-gradient(135deg,#4F46E5,#7C3AED)' }}>
            <div className="relative">
              <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-lg flex-shrink-0">☀️</div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#4ade80] border-2 border-[#4F46E5]" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white text-[14px]">SolarBot — Solar Expert</div>
              <div className="text-[11px] text-white/75 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4ade80] inline-block" />
                Online · Instant replies · Noida to Saharanpur
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <a href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noopener noreferrer"
                className="w-7 h-7 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors"
                aria-label="WhatsApp">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
              </a>
              <button onClick={() => setOpen(false)} className="w-7 h-7 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors text-white" aria-label="Close chat">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2.5 bg-[#F8FAFC]">
            {msgs.map(m => (
              <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} items-end gap-1.5`}>
                {m.role === 'bot' && (
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center text-[11px] flex-shrink-0 mb-0.5">☀️</div>
                )}
                <div className="max-w-[85%]">
                  <div className={`rounded-2xl px-3 py-2.5 text-[12.5px] leading-relaxed shadow-sm ${
                    m.role === 'user'
                      ? 'bg-gradient-to-br from-[#4F46E5] to-[#6366F1] text-white rounded-br-sm'
                      : 'bg-white text-[#0F172A] border border-[#E2E8F0] rounded-bl-sm'
                  }`}
                  dangerouslySetInnerHTML={{ __html: m.text }} />
                  {m.time && <div className={`text-[10px] mt-0.5 ${m.role === 'user' ? 'text-right text-[#94A3B8]' : 'text-[#CBD5E1]'}`}>{m.time}</div>}
                </div>
              </div>
            ))}

            {typing && (
              <div className="flex justify-start items-end gap-1.5">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center text-[11px] flex-shrink-0">☀️</div>
                <div className="bg-white border border-[#E2E8F0] rounded-2xl rounded-bl-sm px-3.5 py-2.5 flex items-center gap-1 shadow-sm">
                  {[0,1,2].map(i => (
                    <span key={i} className="w-1.5 h-1.5 rounded-full bg-[#94A3B8] animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick replies */}
          {currentQuickReplies.length > 0 && (
            <div className="px-3 py-2 flex gap-1.5 flex-wrap border-t border-[#E2E8F0] bg-white flex-shrink-0 max-h-[80px] overflow-y-auto">
              {currentQuickReplies.map((q, i) => (
                <button key={i} onClick={() => handleSend(q)}
                  className="text-[11px] px-2.5 py-1 rounded-full border border-[#E2E8F0] text-[#475569] bg-[#F8FAFC] hover:border-[#4F46E5] hover:text-[#4F46E5] hover:bg-[#EEF2FF] transition-all font-medium">
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="px-3 pb-3 pt-2 border-t border-[#E2E8F0] bg-white flex-shrink-0">
            <div className="flex gap-2 items-center bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3 py-2 focus-within:border-[#4F46E5] focus-within:bg-white transition-all">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
                placeholder={t.chat.placeholder}
                className="flex-1 bg-transparent text-[#0F172A] text-[13px] outline-none placeholder-[#94A3B8]"
                aria-label="Chat message input"
              />
              <button
                onClick={() => handleSend()}
                disabled={!input.trim()}
                className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4F46E5] to-[#7C3AED] flex items-center justify-center flex-shrink-0 disabled:opacity-30 transition-all hover:shadow-md active:scale-95"
                aria-label="Send message">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 2L11 13M22 2L15 22L11 13L2 9L22 2Z"/>
                </svg>
              </button>
            </div>
            <div className="text-center text-[10px] text-[#CBD5E1] mt-1.5">
              Powered by SolarBijli · Western UP Solar Experts
            </div>
          </div>
        </div>
      )}
    </>
  )
}
