'use client'
import { createContext, useContext, useState, ReactNode } from 'react'
import CalcPopup from './CalcPopup'

interface Ctx { openPopup: () => void }
const PopupCtx = createContext<Ctx>({ openPopup: () => {} })
export const useCalcPopup = () => useContext(PopupCtx)

export default function CalcPopupProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false)
  return (
    <PopupCtx.Provider value={{ openPopup: () => setOpen(true) }}>
      {children}
      <CalcPopup open={open} onClose={() => setOpen(false)} />
    </PopupCtx.Provider>
  )
}
