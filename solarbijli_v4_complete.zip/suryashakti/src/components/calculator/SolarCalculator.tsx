'use client'
import { useState, useMemo } from 'react'
import { useI18n } from '@/lib/i18n/context'
import { calculateSolar, formatINR } from '@/lib/calculator'
import { CITIES } from '@/lib/constants'
import { useCalcPopup } from './CalcPopupProvider'

type Financing = 'cash' | 'sbi' | 'canara'
type PropType  = 'residential' | 'commercial'
type Tenure    = 5 | 7 | 10 | 15

const TENURE_OPTIONS: { years: Tenure; label: string }[] = [
  { years: 5,  label: '5 yrs' },
  { years: 7,  label: '7 yrs' },
  { years: 10, label: '10 yrs' },
  { years: 15, label: '15 yrs' },
]

function calcEmiCustom(principal: number, annualRate: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0
  const mr = annualRate / 12
  if (mr === 0) return Math.round(principal / months)
  return Math.round((principal * mr * Math.pow(1 + mr, months)) / (Math.pow(1 + mr, months) - 1))
}

export default function SolarCalculator() {
  const { t } = useI18n()
  const { openPopup } = useCalcPopup()
  const [bill, setBill]         = useState(2500)
  const [roof, setRoof]         = useState(200)
  const [citySlug, setCitySlug] = useState('noida')
  const [prop, setProp]         = useState<PropType>('residential')
  const [financing, setFin]     = useState<Financing>('sbi')
  const [tenure, setTenure]     = useState<Tenure>(10)
  const [showEmiTable, setShowEmiTable] = useState(false)
  const [showAllCities, setShowAllCities] = useState(false)

  const city  = CITIES.find(c => c.slug === citySlug) ?? CITIES[0]
  const finMap: Record<Financing, 'cash' | 'loan' | 'emi'> = { cash: 'cash', sbi: 'loan', canara: 'emi' }
  const r = useMemo(() =>
    calculateSolar({ monthlyBill: bill, city, propertyType: prop, financing: finMap[financing], roofArea: roof }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [bill, city.slug, prop, financing, roof]
  )

  const annualRate = financing === 'canara' ? 0.065 : 0.07
  const loanAmount = Math.min(r.netCost * 0.90, r.systemSizeKw <= 3 ? 200000 : 600000)
  const emiWithTenure = financing !== 'cash' ? calcEmiCustom(loanAmount, annualRate, tenure * 12) : 0

  const pbPct = Math.min((r.paybackYears / 25) * 100, 100)
  const primaryCitySlugs = ['noida', 'greater-noida', 'ghaziabad', 'meerut', 'baraut', 'muzaffarnagar', 'saharanpur', 'shamli']
  const displayCities = showAllCities ? CITIES : CITIES.filter(c => primaryCitySlugs.includes(c.slug))

  const emiOptions = ['sbi', 'canara'].map(bank => {
    const rate = bank === 'canara' ? 0.065 : 0.07
    return {
      bank: bank === 'canara' ? 'Canara Bank' : 'SBI',
      rate: bank === 'canara' ? 6.5 : 7.0,
      emi5:  calcEmiCustom(loanAmount, rate, 60),
      emi7:  calcEmiCustom(loanAmount, rate, 84),
      emi10: calcEmiCustom(loanAmount, rate, 120),
      emi15: calcEmiCustom(loanAmount, rate, 180),
    }
  })

  const Chip = ({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) => (
    <button onClick={onClick}
      className={`px-3 py-1.5 rounded-full text-[12px] font-medium border transition-all ${
        active
          ? 'bg-[#EEF2FF] border-[#4F46E5] text-[#4F46E5] font-semibold shadow-sm'
          : 'border-[#E2E8F0] text-[#64748B] bg-white hover:border-[#CBD5E1] hover:text-[#475569]'
      }`}>
      {label}
    </button>
  )

  const Tile = ({ label, value, sub, color = '' }: { label: string; value: string; sub?: string; color?: string }) => (
    <div className="bg-white border border-[#E2E8F0] rounded-xl p-3 hover:border-[#CBD5E1] transition-colors shadow-sm">
      <div className="text-[10px] text-[#94A3B8] uppercase tracking-wider font-bold mb-1">{label}</div>
      <div className={`text-[15px] font-extrabold tracking-tight leading-tight ${
        color === 'sun' ? 'text-[#D97706]' :
        color === 'green' ? 'text-[#059669]' :
        color === 'cta' ? 'text-[#4F46E5]' :
        'text-[#0F172A]'
      }`}>{value}</div>
      {sub && <div className="text-[10px] text-[#94A3B8] mt-0.5 leading-tight">{sub}</div>}
    </div>
  )

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-2xl shadow-xl overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2">

        {/* LEFT — Inputs */}
        <div className="p-5 sm:p-6 lg:p-8 border-b lg:border-b-0 lg:border-r border-[#E2E8F0]">
          <div className="flex items-center gap-2 text-[10px] font-bold tracking-[.12em] text-[#4F46E5] uppercase mb-5">
            <span className="w-4 h-[2px] bg-[#4F46E5] rounded" />
            {t.calc.configLabel}
          </div>

          {/* Bill slider */}
          <div className="mb-5">
            <div className="flex justify-between items-center mb-2">
              <label className="text-[13px] font-semibold text-[#1E293B]">{t.calc.bill}</label>
              <span className="text-[13px] font-bold text-[#4F46E5] bg-[#EEF2FF] px-2.5 py-0.5 rounded-lg">
                ₹{bill.toLocaleString('en-IN')}
              </span>
            </div>
            <input type="range" min="500" max="15000" value={bill} step="100"
              onChange={e => setBill(+e.target.value)} className="w-full" aria-label="Monthly electricity bill" />
            <div className="flex justify-between text-[11px] text-[#CBD5E1] mt-1"><span>₹500</span><span>₹15,000</span></div>
          </div>

          {/* Roof slider */}
          <div className="mb-5">
            <div className="flex justify-between items-center mb-2">
              <label className="text-[13px] font-semibold text-[#1E293B]">{t.calc.roofArea}</label>
              <span className="text-[13px] font-bold text-[#4F46E5] bg-[#EEF2FF] px-2.5 py-0.5 rounded-lg">{roof} sq ft</span>
            </div>
            <input type="range" min="50" max="1000" value={roof} step="10"
              onChange={e => setRoof(+e.target.value)} className="w-full" aria-label="Roof area" />
            <div className="flex justify-between text-[11px] text-[#CBD5E1] mt-1"><span>50 sq ft</span><span>1,000 sq ft</span></div>
          </div>

          {/* City — scrollable chips */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[13px] font-semibold text-[#1E293B]">{t.calc.city}</label>
              <button onClick={() => setShowAllCities(v => !v)}
                className="text-[11px] text-[#4F46E5] font-medium hover:underline">
                {showAllCities ? 'Show less ▲' : `All cities ▼`}
              </button>
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {displayCities.map(c => (
                <Chip key={c.slug} label={c.name} active={citySlug === c.slug} onClick={() => setCitySlug(c.slug)} />
              ))}
            </div>
            {city && (
              <p className="text-[11px] text-[#64748B] mt-1.5 flex items-center gap-1">
                📍 {city.district} · {city.sunHours} hrs/day sun · Avg bill ₹{city.avgBill.toLocaleString('en-IN')}
              </p>
            )}
          </div>

          {/* Property type */}
          <div className="mb-4">
            <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">{t.calc.propType}</label>
            <div className="flex gap-2">
              <Chip label={t.calc.residential} active={prop === 'residential'} onClick={() => setProp('residential')} />
              <Chip label={t.calc.commercial}  active={prop === 'commercial'}  onClick={() => setProp('commercial')}  />
            </div>
            {prop === 'residential' && (
              <p className="text-[12px] text-[#059669] font-semibold mt-1.5 flex items-center gap-1">
                ✓ {t.calc.subsidyNote}
              </p>
            )}
          </div>

          {/* Financing */}
          <div className="mb-4">
            <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">{t.calc.financing}</label>
            <div className="flex gap-2 flex-wrap">
              <Chip label={t.calc.cash}       active={financing === 'cash'}   onClick={() => setFin('cash')}   />
              <Chip label="🏦 SBI 7%"         active={financing === 'sbi'}    onClick={() => setFin('sbi')}    />
              <Chip label="🏛️ Canara 6.5%"   active={financing === 'canara'} onClick={() => setFin('canara')} />
            </div>
            <p className="text-[11px] text-[#94A3B8] mt-1.5">
              {financing === 'canara' ? 'Canara Bank 6.5% — lowest rate. Apply via JanSamarth portal.' :
               financing === 'sbi'    ? 'SBI 7% p.a. — no collateral up to ₹2L. JanSamarth portal.' :
               'Pay full amount — best long-term ROI. No EMI.'}
            </p>
          </div>

          {/* Tenure selector */}
          {financing !== 'cash' && (
            <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3">
              <label className="block text-[12px] font-semibold text-[#1E293B] mb-2">
                📅 Loan Tenure — pick your comfort level
              </label>
              <div className="flex gap-1.5">
                {TENURE_OPTIONS.map(({ years, label }) => (
                  <button key={years} onClick={() => setTenure(years)}
                    className={`flex-1 py-2 rounded-lg text-[11px] font-bold border transition-all ${
                      tenure === years
                        ? 'bg-[#4F46E5] text-white border-[#4F46E5] shadow-md'
                        : 'bg-white text-[#475569] border-[#E2E8F0] hover:border-[#4F46E5] hover:text-[#4F46E5]'
                    }`}>
                    {label}
                  </button>
                ))}
              </div>
              <div className="mt-2 text-center bg-white rounded-lg py-1.5 border border-[#E2E8F0]">
                <span className="text-[18px] font-extrabold text-[#059669]">₹{emiWithTenure.toLocaleString('en-IN')}/mo</span>
                <span className="text-[11px] text-[#64748B] ml-1">for {tenure} years</span>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT — Results */}
        <div className="p-5 sm:p-6 lg:p-8 bg-gradient-to-br from-[#F8FAFC] to-white">
          <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-[.12em] text-[#059669] uppercase mb-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#059669] animate-pulse inline-block" />
            {t.calc.liveTag}
          </div>

          {/* Big number */}
          <div className="text-[clamp(36px,8vw,52px)] font-black tracking-tight text-[#059669] leading-none mb-1">
            {formatINR(r.netCost)}
          </div>
          <p className="text-[12px] text-[#64748B] mb-4">{t.calc.netCostLabel}</p>

          {/* Tiles */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            <Tile label={t.calc.systemSize}     value={`${r.systemSizeKw} kW`}          sub={`${r.panelCount} panels · ${r.roofAreaRequired} sq ft`} color="sun"   />
            <Tile label="Gross Cost"            value={formatINR(r.totalCost)}           sub={t.calc.beforeSubsidy}                                               />
            <Tile label={t.calc.centralSubsidy} value={r.centralSubsidy > 0 ? formatINR(r.centralSubsidy) : 'N/A'} sub="PM Surya Ghar" color="cta" />
            <Tile label={t.calc.stateSubsidy}   value={r.stateSubsidy > 0 ? formatINR(r.stateSubsidy) : 'N/A'}   sub="UPNEDA UP State"  color="cta" />
            <Tile
              label={financing !== 'cash' ? `EMI (${tenure} yrs)` : 'Payment'}
              value={financing !== 'cash' ? `${formatINR(emiWithTenure)}/mo` : 'Cash buy'}
              sub={financing === 'canara' ? `Canara 6.5% · ${tenure}yr` : financing === 'sbi' ? `SBI 7% · ${tenure}yr` : 'Best ROI'}
            />
            <Tile label={t.calc.annualSavings}  value={formatINR(r.annualSavings)}       sub={t.calc.vsBill}  color="green" />
          </div>

          {/* EMI comparison table */}
          {financing !== 'cash' && (
            <div className="mb-4">
              <button onClick={() => setShowEmiTable(!showEmiTable)}
                className="w-full text-[12px] text-[#4F46E5] font-semibold mb-2 text-left flex items-center gap-1">
                <span>{showEmiTable ? '▲' : '▼'}</span>
                Compare all bank EMIs by tenure
              </button>
              {showEmiTable && (
                <div className="overflow-x-auto rounded-xl border border-[#E2E8F0]">
                  <table className="w-full text-[11px] border-collapse min-w-[320px]">
                    <thead>
                      <tr className="bg-[#EEF2FF]">
                        <th className="text-left px-2 py-2 text-[#4F46E5] font-bold">Bank</th>
                        <th className="text-right px-2 py-2 text-[#4F46E5] font-bold">Rate</th>
                        <th className="text-right px-2 py-2 text-[#4F46E5] font-bold">5yr</th>
                        <th className="text-right px-2 py-2 text-[#4F46E5] font-bold">7yr</th>
                        <th className="text-right px-2 py-2 text-[#4F46E5] font-bold bg-[#D1FAE5]">10yr</th>
                        <th className="text-right px-2 py-2 text-[#4F46E5] font-bold">15yr</th>
                      </tr>
                    </thead>
                    <tbody>
                      {emiOptions.map((row, i) => (
                        <tr key={row.bank} className={`border-b border-[#E2E8F0] ${i === 0 ? 'bg-[#ECFDF5]' : 'bg-white'}`}>
                          <td className="px-2 py-2 font-semibold text-[#0F172A] whitespace-nowrap">
                            {row.bank}{i === 0 && <span className="ml-1 text-[9px] bg-[#059669] text-white px-1 rounded">Best</span>}
                          </td>
                          <td className="px-2 py-2 text-right text-[#475569]">{row.rate}%</td>
                          <td className="px-2 py-2 text-right text-[#475569]">₹{row.emi5.toLocaleString('en-IN')}</td>
                          <td className="px-2 py-2 text-right text-[#475569]">₹{row.emi7.toLocaleString('en-IN')}</td>
                          <td className="px-2 py-2 text-right font-bold text-[#059669] bg-[#F0FDF4]">₹{row.emi10.toLocaleString('en-IN')}</td>
                          <td className="px-2 py-2 text-right text-[#475569]">₹{row.emi15.toLocaleString('en-IN')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="text-[10px] text-[#94A3B8] px-2 py-1.5">*No collateral up to ₹2L. Apply via JanSamarth portal.</p>
                </div>
              )}
            </div>
          )}

          {/* Payback bar */}
          <div className="mb-4">
            <div className="flex justify-between text-[12px] text-[#64748B] mb-1.5">
              <span>{t.calc.payback}</span>
              <span className="text-[#059669] font-bold">{r.paybackYears} years</span>
            </div>
            <div className="h-[6px] bg-[#E2E8F0] rounded-full relative overflow-visible">
              <div className="h-full rounded-full bg-gradient-to-r from-[#059669] to-[#34D399] transition-all duration-700 relative"
                   style={{ width: `${pbPct}%` }}>
                <span className="absolute -top-5 -right-2 text-[10px] text-[#059669] font-bold whitespace-nowrap">
                  Yr {r.paybackYears}
                </span>
              </div>
            </div>
            <div className="flex justify-between text-[11px] text-[#CBD5E1] mt-1"><span>Today</span><span>25 years</span></div>
          </div>

          {/* 25yr savings */}
          <div className="bg-[#ECFDF5] border border-[#A7F3D0] rounded-xl p-3 mb-4">
            <div className="text-[10px] text-[#047857] font-bold uppercase tracking-wider mb-1">{t.calc.savings25}</div>
            <div className="text-[clamp(22px,5vw,28px)] font-black text-[#059669] tracking-tight">{formatINR(r.savingsOver25Years)}</div>
            <div className="text-[11px] text-[#047857] mt-0.5">{r.co2OffsetKgPerYear.toLocaleString('en-IN')} kg CO₂ saved/year 🌱</div>
          </div>

          <button onClick={openPopup}
            className="w-full py-3.5 sm:py-4 bg-[#4F46E5] text-white font-bold text-[14px] sm:text-[15px] rounded-xl hover:bg-[#4338CA] transition-all hover:-translate-y-0.5 hover:shadow-lg group relative overflow-hidden">
            <span className="relative z-10">{t.calc.getQuote}</span>
            <span className="absolute top-0 left-[-100%] w-full h-full bg-gradient-to-r from-transparent via-white/15 to-transparent group-hover:left-[100%] transition-all duration-500" />
          </button>
          <p className="text-center text-[11px] text-[#94A3B8] mt-2">{t.calc.disclaimer}</p>
        </div>
      </div>
    </div>
  )
}
