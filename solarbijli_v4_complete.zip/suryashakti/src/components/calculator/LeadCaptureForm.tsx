'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ArrowLeft, User, Phone, Mail, Clock } from 'lucide-react'
import type { CalculatorResult } from '@/types'
import { CITIES } from '@/lib/constants'
import { formatINR } from '@/lib/calculator'
import Button from '@/components/ui/Button'

const schema = z.object({
  name: z.string().min(2, 'Enter your full name'),
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter valid 10-digit mobile number'),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  preferredTime: z.string().optional(),
})
type FormData = z.infer<typeof schema>

interface Props {
  result: CalculatorResult
  citySlug: string
  onSuccess: () => void
  onBack: () => void
}

export default function LeadCaptureForm({ result, citySlug, onSuccess, onBack }: Props) {
  const [error, setError] = useState<string | null>(null)
  const city = CITIES.find((c) => c.slug === citySlug)

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async (data: FormData) => {
    setError(null)
    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          city: city?.name ?? citySlug,
          district: city?.district ?? '',
          monthlyBill: 0,
          propertyType: 'residential',
          systemSizeKw: result.systemSizeKw,
          totalCost: result.totalCost,
          subsidyAmount: result.subsidyAmount,
          netCost: result.netCost,
          paybackYears: result.paybackYears,
          financing: 'loan',
        }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error ?? 'Submission failed')
      onSuccess()
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
    }
  }

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Summary recap */}
      <div className="card-dark rounded-2xl p-8 h-fit">
        <h3 className="font-syne font-700 text-white text-lg mb-6">Your Solar Summary</h3>
        <div className="space-y-4">
          {[
            { label: 'System Size', value: `${result.systemSizeKw} kW`, color: 'text-white' },
            { label: 'Total Cost', value: formatINR(result.totalCost), color: 'text-white' },
            { label: 'PM Surya Ghar Subsidy', value: `-${formatINR(result.subsidyAmount)}`, color: 'text-sun' },
            { label: 'Your Net Cost', value: formatINR(result.netCost), color: 'text-leaf' },
            { label: 'Payback Period', value: `${result.paybackYears} years`, color: 'text-white' },
            { label: '25-Year Savings', value: formatINR(result.savingsOver25Years), color: 'text-leaf' },
          ].map(({ label, value, color }) => (
            <div key={label} className="flex justify-between items-center border-b border-sky-800/60 pb-3">
              <span className="text-slate-400 text-sm">{label}</span>
              <span className={`font-syne font-600 ${color}`}>{value}</span>
            </div>
          ))}
        </div>

        {city && (
          <div className="mt-6 bg-sky-900/50 rounded-xl p-4">
            <p className="text-slate-300 text-sm">
              Our certified partner in <strong className="text-white">{city.name}</strong> will
              contact you within <strong className="text-sun">24 hours</strong> to schedule a
              free site survey.
            </p>
          </div>
        )}
      </div>

      {/* Contact form */}
      <div className="card-dark-solid rounded-2xl p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-slate-400 hover:text-white text-sm mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to estimate
        </button>

        <h3 className="font-syne font-700 text-white text-lg mb-2">Connect with an Installer</h3>
        <p className="text-slate-400 text-sm mb-7">Free service. No spam. Cancel anytime.</p>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div>
            <label className="label-dark">
              <User className="w-3.5 h-3.5 inline mr-1.5" />Full Name
            </label>
            <input className="input-dark" placeholder="Ramesh Kumar" {...register('name')} />
            {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name.message}</p>}
          </div>

          <div>
            <label className="label-dark">
              <Phone className="w-3.5 h-3.5 inline mr-1.5" />Mobile Number
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">+91</span>
              <input
                className="input-dark pl-12"
                placeholder="98765XXXXX"
                maxLength={10}
                {...register('phone')}
              />
            </div>
            {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone.message}</p>}
          </div>

          <div>
            <label className="label-dark">
              <Mail className="w-3.5 h-3.5 inline mr-1.5" />Email (optional)
            </label>
            <input className="input-dark" placeholder="you@example.com" type="email" {...register('email')} />
            <p className="text-slate-500 text-xs mt-1">We'll send your estimate summary here</p>
          </div>

          <div>
            <label className="label-dark">
              <Clock className="w-3.5 h-3.5 inline mr-1.5" />Preferred Contact Time
            </label>
            <select className="input-dark" {...register('preferredTime')}>
              <option value="">Anytime</option>
              <option value="morning">Morning (9am – 12pm)</option>
              <option value="afternoon">Afternoon (12pm – 4pm)</option>
              <option value="evening">Evening (4pm – 7pm)</option>
              <option value="weekend">Weekend only</option>
            </select>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">
              {error}
            </div>
          )}

          <Button type="submit" size="lg" loading={isSubmitting} className="w-full">
            Get My Free Quote
          </Button>

          <p className="text-slate-500 text-xs text-center leading-relaxed">
            By submitting, you agree to be contacted by our certified partner in {city?.name}.
            We never share your data with third parties.
          </p>
        </form>
      </div>
    </div>
  )
}
