'use client'
import { useState, useEffect, useMemo } from 'react'
import { useI18n } from '@/lib/i18n/context'
import { calculateSolar, formatINR } from '@/lib/calculator'
import { CITIES, PHONE, WA_NUMBER } from '@/lib/constants'

interface Props {
  open: boolean
  onClose: () => void
}

function calcEmiPopup(principal: number, annualRate: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0
  const mr = annualRate / 12
  return Math.round((principal * mr * Math.pow(1 + mr, months)) / (Math.pow(1 + mr, months) - 1))
}

const POPULAR_CITY_SLUGS = ['noida', 'ghaziabad', 'greater-noida', 'meerut', 'baraut', 'muzaffarnagar', 'saharanpur', 'shamli']

export default function CalcPopup({ open, onClose }: Props) {
  const { t } = useI18n()
  const [step, setStep] = useState<'calc' | 'lead' | 'done'>('calc')
  const [bill, setBill] = useState(2500)
  const [citySlug, setCitySlug] = useState('noida')
  const [prop, setProp] = useState<'residential' | 'commercial'>('residential')
  const [tenure, setTenure] = useState<5 | 7 | 10 | 15>(7)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [showAllCities, setShowAllCities] = useState(false)

  const city = CITIES.find(c => c.slug === citySlug) || CITIES[0]
  const r = useMemo(() => calculateSolar({ monthlyBill: bill, city, propertyType: prop, financing: 'loan', roofArea: 200 }), [bill, city, prop])

  const loanAmount = Math.min(r.netCost * 0.90, r.systemSizeKw <= 3 ? 200000 : 600000)
  const emiMonthly = prop === 'residential' ? calcEmiPopup(loanAmount, 0.07, tenure * 12) : 0

  useEffect(() => { if (!open) { setTimeout(() => setStep('calc'), 400) } }, [open])
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [open])

  const handleSubmit = async () => {
    if (!name.trim() || !phone.trim()) return
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name, phone, city: city.name, monthlyBill: bill, propertyType: prop,
          financing: 'loan', systemSizeKw: r.systemSizeKw, subsidyAmount: r.subsidyAmount,
          netCost: r.netCost, emiMonthly, source: 'popup-calculator'
        }),
      })
    } catch {}
    setLoading(false)
    setStep('done')
  }

  if (!open) return null

  const displayCities = showAllCities ? CITIES : CITIES.filter(c => POPULAR_CITY_SLUGS.includes(c.slug))

  return (
    <div className="fixed inset-0 z-[300] bg-[rgba(15,23,42,.65)] backdrop-blur-sm flex items-center justify-center p-3 sm:p-4"
         onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-2xl w-full max-w-[520px] overflow-hidden shadow-2xl max-h-[92vh] overflow-y-auto"
           style={{ animation: 'popIn .35s cubic-bezier(.34,1.56,.64,1)' }}>

        {/* Header */}
        <div className="bg-gradient-to-r from-[#4F46E5] to-[#7C3AED] px-5 sm:px-7 pt-5 sm:pt-7 pb-4 sm:pb-5 relative">
          <button onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors"
            aria-label="Close">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
          <h2 className="text-white font-black text-[18px] sm:text-[20px] tracking-tight mb-1">
            {step === 'done' ? '✅ You\'re all set!' : t.popup.h2}
          </h2>
          <p className="text-white/80 text-[12.5px] sm:text-[13.5px]">
            {step === 'done' ? t.popup.successMsg : t.popup.sub}
          </p>
        </div>

        <div className="px-5 sm:px-7 py-5 sm:py-6">
          {/* STEP 1: Calculator */}
          {step === 'calc' && (
            <>
              {/* Bill slider */}
              <div className="mb-4 sm:mb-5">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-[13px] font-semibold text-[#1E293B]">{t.calc.bill}</label>
                  <span className="text-[13px] font-bold text-[#4F46E5] bg-[#EEF2FF] px-2.5 py-0.5 rounded-lg">
                    ₹{bill.toLocaleString('en-IN')}
                  </span>
                </div>
                <input type="range" min="500" max="15000" value={bill} step="100"
                  onChange={e => setBill(+e.target.value)}
                  className="w-full" aria-label="Monthly bill" />
                <div className="flex justify-between text-[11px] text-[#94A3B8] mt-1"><span>₹500</span><span>₹15,000</span></div>
              </div>

              {/* City */}
              <div className="mb-3 sm:mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[13px] font-semibold text-[#1E293B]">{t.calc.city}</label>
                  <button onClick={() => setShowAllCities(v => !v)}
                    className="text-[11px] text-[#4F46E5] font-medium hover:underline">
                    {showAllCities ? 'Less ▲' : 'All 12 cities ▼'}
                  </button>
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {displayCities.map(c => (
                    <button key={c.slug} onClick={() => setCitySlug(c.slug)}
                      className={`px-2.5 py-1.5 rounded-full text-[11.5px] font-medium border transition-all ${
                        citySlug === c.slug
                          ? 'bg-[#EEF2FF] border-[#4F46E5] text-[#4F46E5] font-semibold'
                          : 'border-[#E2E8F0] text-[#64748B] hover:border-[#CBD5E1]'
                      }`}>
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Property */}
              <div className="mb-4">
                <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">{t.calc.propType}</label>
                <div className="flex gap-2">
                  {(['residential', 'commercial'] as const).map(p => (
                    <button key={p} onClick={() => setProp(p)}
                      className={`flex-1 py-2 rounded-xl text-[12.5px] font-medium border transition-all ${
                        prop === p ? 'bg-[#EEF2FF] border-[#4F46E5] text-[#4F46E5]' : 'border-[#E2E8F0] text-[#64748B]'
                      }`}>
                      {p === 'residential' ? t.calc.residential : t.calc.commercial}
                    </button>
                  ))}
                </div>
                {prop === 'residential' && (
                  <p className="text-[11.5px] text-[#059669] font-semibold mt-1.5">✓ {t.calc.subsidyNote}</p>
                )}
              </div>

              {/* Tenure selector */}
              {prop === 'residential' && (
                <div className="mb-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3">
                  <label className="block text-[12px] font-semibold text-[#1E293B] mb-2">📅 Loan Tenure</label>
                  <div className="flex gap-1.5">
                    {([5, 7, 10, 15] as const).map(y => (
                      <button key={y} onClick={() => setTenure(y)}
                        className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold border transition-all ${
                          tenure === y
                            ? 'bg-[#4F46E5] text-white border-[#4F46E5]'
                            : 'bg-white text-[#475569] border-[#E2E8F0] hover:border-[#4F46E5]'
                        }`}>
                        {y}yr
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Results grid */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                {[
                  { l: t.calc.systemSize, v: `${r.systemSizeKw} kW`, s: `${r.panelCount} panels`, c: 'amber' },
                  { l: 'Gross Cost', v: formatINR(r.totalCost), s: t.calc.beforeSubsidy, c: '' },
                  { l: 'Central Subsidy', v: r.centralSubsidy > 0 ? formatINR(r.centralSubsidy) : '—', s: 'PM Surya Ghar', c: 'indigo' },
                  { l: 'UP State Subsidy', v: r.stateSubsidy > 0 ? formatINR(r.stateSubsidy) : '—', s: 'UPNEDA', c: 'green' },
                  { l: 'Net Cost', v: formatINR(r.netCost), s: 'After ₹' + r.subsidyAmount.toLocaleString('en-IN') + ' subsidy', c: 'indigo' },
                  { l: `EMI (${tenure}yr SBI 7%)`, v: emiMonthly > 0 ? `₹${emiMonthly.toLocaleString('en-IN')}/mo` : 'Cash buy', s: `Save ₹${Math.round(r.annualSavings/12).toLocaleString('en-IN')}/mo`, c: '' },
                ].map((tile, i) => (
                  <div key={i} className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-2.5 sm:p-3">
                    <div className="text-[9.5px] sm:text-[10.5px] text-[#64748B] uppercase tracking-wider font-bold mb-1">{tile.l}</div>
                    <div className={`text-[14px] sm:text-[16px] font-extrabold tracking-tight leading-tight ${
                      tile.c === 'indigo' ? 'text-[#4F46E5]' :
                      tile.c === 'green' ? 'text-[#059669]' :
                      tile.c === 'amber' ? 'text-[#D97706]' :
                      'text-[#0F172A]'
                    }`}>{tile.v}</div>
                    <div className="text-[10px] text-[#94A3B8] mt-0.5 leading-tight">{tile.s}</div>
                  </div>
                ))}
              </div>

              {/* 25yr savings */}
              <div className="bg-[#ECFDF5] border border-[#A7F3D0] rounded-xl p-3 mb-4 text-center">
                <div className="text-[10.5px] text-[#047857] font-bold uppercase tracking-wider mb-1">25-Year Total Savings</div>
                <div className="text-[26px] sm:text-[28px] font-black text-[#059669] tracking-tight">{formatINR(r.savingsOver25Years)}</div>
                <div className="text-[11px] text-[#047857]">Payback: {r.paybackYears} years · {r.co2OffsetKgPerYear.toLocaleString()} kg CO₂ saved/yr</div>
              </div>

              <button onClick={() => setStep('lead')}
                className="w-full py-3.5 sm:py-4 bg-[#4F46E5] text-white font-bold text-[14px] sm:text-[15px] rounded-xl hover:bg-[#4338CA] transition-all hover:-translate-y-0.5 hover:shadow-lg">
                {t.popup.getQuoteNow} →
              </button>
              <div className="flex justify-center gap-3 sm:gap-4 mt-3 flex-wrap">
                {t.popup.trust.map((s, i) => <span key={i} className="text-[11px] sm:text-[12px] text-[#94A3B8]">{s}</span>)}
              </div>
            </>
          )}

          {/* STEP 2: Contact form */}
          {step === 'lead' && (
            <>
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3 sm:p-4 mb-4 sm:mb-5">
                <div className="text-[11px] text-[#64748B] font-bold uppercase tracking-wider mb-3">{t.popup.yourEstimate}</div>
                <div className="space-y-2">
                  {[
                    [`${r.systemSizeKw} kW system (${r.panelCount} panels)`, ''],
                    ['Total Subsidy (Central + UPNEDA)', `₹${r.subsidyAmount.toLocaleString('en-IN')}`],
                    ['Your Net Cost', formatINR(r.netCost)],
                    [`EMI (${tenure}yr @ SBI 7%)`, `₹${emiMonthly.toLocaleString('en-IN')}/month`],
                    ['Annual Savings', formatINR(r.annualSavings)],
                  ].map(([l, v], i) => (
                    <div key={i} className={`flex justify-between text-[12.5px] sm:text-[13.5px] ${i === 2 ? 'font-bold border-t border-[#E2E8F0] pt-2' : ''}`}>
                      <span className="text-[#64748B]">{l}</span>
                      <span className={i === 2 ? 'text-[#4F46E5] font-black' : 'text-[#0F172A] font-semibold'}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">{t.popup.nameLabel} *</label>
                <input value={name} onChange={e => setName(e.target.value)}
                  placeholder="Your full name"
                  className="w-full border border-[#E2E8F0] rounded-xl px-4 py-3 text-[14px] text-[#0F172A] bg-[#F8FAFC] outline-none focus:border-[#4F46E5] focus:bg-white transition-all" />
              </div>
              <div className="mb-5">
                <label className="block text-[13px] font-semibold text-[#1E293B] mb-2">{t.popup.phoneLabel} *</label>
                <input value={phone} onChange={e => setPhone(e.target.value)} type="tel"
                  placeholder="+91 98765 43210"
                  className="w-full border border-[#E2E8F0] rounded-xl px-4 py-3 text-[14px] text-[#0F172A] bg-[#F8FAFC] outline-none focus:border-[#4F46E5] focus:bg-white transition-all" />
              </div>

              <div className="flex gap-2">
                <button onClick={() => setStep('calc')}
                  className="px-4 py-3.5 border border-[#E2E8F0] text-[#64748B] rounded-xl text-[13px] font-medium hover:border-[#CBD5E1] transition-all">
                  ← Back
                </button>
                <button onClick={handleSubmit} disabled={loading || !name.trim() || !phone.trim()}
                  className="flex-1 py-3.5 bg-[#4F46E5] text-white font-bold text-[14px] sm:text-[15px] rounded-xl hover:bg-[#4338CA] transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                  {loading ? 'Sending...' : t.popup.submitBtn}
                </button>
              </div>
            </>
          )}

          {/* STEP 3: Success */}
          {step === 'done' && (
            <div className="text-center py-4">
              <div className="w-[72px] h-[72px] rounded-full bg-[#ECFDF5] border-2 border-[#A7F3D0] flex items-center justify-center text-[32px] mx-auto mb-4">✅</div>
              <h3 className="text-[18px] sm:text-[20px] font-black text-[#0F172A] mb-2">{t.popup.successTitle}</h3>
              <p className="text-[13px] sm:text-[14px] text-[#64748B] mb-6">{t.popup.successMsg}</p>
              <div className="flex flex-col gap-3">
                <a href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-[14px] text-white transition-all" style={{ background: '#25D366' }}>
                  💬 {t.lead.whatsappCta}
                </a>
                <a href={`tel:${PHONE}`}
                  className="flex items-center justify-center gap-2 py-3 rounded-xl bg-[#4F46E5] text-white font-bold text-[14px]">
                  📞 {t.lead.callCta}
                </a>
                <button onClick={onClose} className="text-[#94A3B8] text-[13px] hover:text-[#475569] transition-colors">Close</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
