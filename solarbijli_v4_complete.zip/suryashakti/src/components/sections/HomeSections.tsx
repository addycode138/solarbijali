'use client'

import Link from 'next/link'
import { Sun, Zap, Shield, TrendingUp, MapPin, ChevronRight, Star, ArrowRight } from 'lucide-react'
import { CITIES } from '@/lib/constants'
import Section, { SectionHeading } from '@/components/ui/Section'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="absolute right-0 top-1/4 w-[500px] h-[500px] rounded-full bg-sun/5 blur-3xl pointer-events-none" />
      <div className="absolute left-1/4 bottom-0 w-[400px] h-[400px] rounded-full bg-leaf/5 blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto w-full pt-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-sun bg-sun/10 border border-sun/20 px-4 py-2 rounded-full mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-sun animate-pulse" />
              Officially registered under PM Surya Ghar Yojana
            </div>

            <h1 className="font-syne font-800 text-5xl sm:text-6xl text-white leading-tight mb-6">
              Go Solar in <span className="text-sun">Uttar Pradesh</span> — Get ₹1,08,000 Govt Subsidy
            </h1>

            <p className="text-slate-400 text-lg leading-relaxed mb-8 font-300">
              Calculate your solar savings instantly. Claim government subsidies. Connect with our certified
              installers across 12 West UP districts: Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur & more — all for free.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <Link
                href="/calculator"
                className="inline-flex items-center justify-center gap-2 bg-sun hover:bg-sun-300 text-sky-950 font-syne font-700 text-base px-8 py-4 rounded-xl transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-sun/20"
              >
                Calculate My Savings <Zap className="w-5 h-5" />
              </Link>
              <Link
                href="/learn/subsidies"
                className="inline-flex items-center justify-center gap-2 border border-sky-700 text-slate-300 hover:border-sun/40 hover:text-white font-syne font-600 text-base px-8 py-4 rounded-xl transition-all"
              >
                PM Subsidy Guide <ChevronRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Social proof */}
            <div className="flex items-center gap-6 text-sm text-slate-400">
              <div className="flex items-center gap-1.5">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-sun fill-sun" />
                  ))}
                </div>
                <span>4.9/5 rating</span>
              </div>
              <div className="w-px h-4 bg-sky-700" />
              <span>500+ installations in UP</span>
              <div className="w-px h-4 bg-sky-700" />
              <span>₹2Cr+ subsidies claimed</span>
            </div>
          </div>

          {/* Right — Stats card */}
          <div className="hidden lg:block animate-fade-up" style={{ animationDelay: '200ms' }}>
            <div className="card-dark-solid rounded-3xl p-8 space-y-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-sun flex items-center justify-center">
                  <Sun className="w-5 h-5 text-sky-950" />
                </div>
                <div>
                  <p className="text-white font-syne font-700">SolarBijli Calculator</p>
                  <p className="text-slate-400 text-sm">Live estimate preview</p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { label: 'Monthly Bill', value: '₹3,000', note: 'Your input' },
                  { label: 'System Size', value: '3 kW', note: 'Recommended' },
                  { label: 'Total Cost', value: '₹1,35,000', note: 'Before subsidy' },
                  { label: 'PM Subsidy', value: '-₹1,08,000', note: 'Government scheme', accent: 'text-sun' },
                  { label: 'Net Cost', value: '₹57,000', note: 'You pay this', accent: 'text-leaf' },
                  { label: 'Payback', value: '4.2 years', note: 'Then pure savings' },
                  { label: '25-Year Savings', value: '₹8.4 Lakh', note: 'At 2% tariff increase', accent: 'text-leaf' },
                ].map(({ label, value, note, accent }) => (
                  <div key={label} className="flex justify-between items-center border-b border-sky-800/40 pb-2.5">
                    <span className="text-slate-400 text-sm">{label}</span>
                    <div className="text-right">
                      <span className={`font-syne font-600 text-sm ${accent ?? 'text-white'}`}>{value}</span>
                      <p className="text-slate-500 text-xs">{note}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link
                href="/calculator"
                className="block w-full text-center bg-sun text-sky-950 font-syne font-700 text-sm py-3 rounded-xl hover:bg-sun-300 transition-colors mt-2"
              >
                Calculate Your Numbers →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export function BenefitsSection() {
  const benefits = [
    { icon: <TrendingUp className="w-6 h-6" />, title: 'Up to ₹1,08,000 Subsidy', desc: 'PM Surya Ghar Muft Bijli Yojana gives residential customers up to ₹1,08,000 total subsidy (Central + UPNEDA UP) directly to your bank.', color: 'sun' },
    { icon: <Zap className="w-6 h-6" />, title: 'Zero Electricity Bills', desc: 'A 3 kW system covers 90–100% of an average UP household bill of ₹2,000–₹3,000/month.', color: 'leaf' },
    { icon: <Shield className="w-6 h-6" />, title: 'Certified Installers Only', desc: 'Every partner agency is government-registered, MNRE approved, and covered by a 5-year workmanship warranty.', color: 'blue' },
    { icon: <Sun className="w-6 h-6" />, title: '25-Year Panel Warranty', desc: 'Tier-1 monocrystalline panels with 25-year performance guarantee and local service support.', color: 'sun' },
  ]

  const colorMap: Record<string, string> = {
    sun: 'text-sun bg-sun/10',
    leaf: 'text-leaf bg-leaf/10',
    blue: 'text-sky-400 bg-sky-400/10',
  }

  return (
    <Section dark>
      <SectionHeading
        badge="Why Solar Now"
        title="The Best Time to Go Solar is"
        highlight="Today"
        description="Electricity tariffs in UP rise ~8% annually. The sooner you switch, the more you save — and the government subsidy makes entry cheaper than ever."
      />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {benefits.map((b) => (
          <div key={b.title} className="card-dark-solid rounded-2xl p-6 hover:border-sun/20 transition-colors group">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorMap[b.color]}`}>
              {b.icon}
            </div>
            <h3 className="font-syne font-700 text-white mb-2 text-base">{b.title}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{b.desc}</p>
          </div>
        ))}
      </div>
    </Section>
  )
}

export function CitiesSection() {
  return (
    <Section>
      <SectionHeading
        badge="Our Coverage"
        title="Serving Across Western"
        highlight="Uttar Pradesh"
        description="Certified solar installers in every city we operate. Click your city for local information, agency details, and city-specific solar data."
      />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {CITIES.map((city) => (
          <Link
            key={city.slug}
            href={`/cities/${city.slug}`}
            className="card-dark-solid rounded-2xl p-6 hover:border-sun/30 hover:-translate-y-1 transition-all group"
          >
            <div className="flex items-start justify-between mb-4">
              <MapPin className="w-5 h-5 text-sun" />
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sun transition-colors" />
            </div>
            <h3 className="font-syne font-700 text-white text-lg mb-1">{city.name}</h3>
            <p className="text-slate-500 text-xs mb-4">{city.district} District</p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Avg. bill</span>
                <span className="text-white">₹{city.avgBill.toLocaleString('en-IN')}/mo</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Sun hours</span>
                <span className="text-sun">{city.sunHours} hrs/day</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </Section>
  )
}

export function HowItWorksSection() {
  const steps = [
    { num: '01', title: 'Calculate', desc: 'Use our free calculator. Enter your bill, city, and roof area to get your personalised estimate in 30 seconds.' },
    { num: '02', title: 'Review', desc: 'See your system size, subsidy amount, EMI options, payback period, and 25-year savings — all in one place.' },
    { num: '03', title: 'Connect', desc: 'Submit your contact details and we instantly match you with our certified partner in your city.' },
    { num: '04', title: 'Install', desc: 'The installer does a free site survey, handles all MNRE paperwork, net-meter application, and full installation.' },
  ]

  return (
    <Section dark>
      <SectionHeading badge="Process" title="How It" highlight="Works" center description="From curiosity to clean energy — in 4 simple steps." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((step, i) => (
          <div key={step.num} className="relative">
            {i < steps.length - 1 && (
              <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-gradient-to-r from-sun/30 to-transparent z-0" />
            )}
            <div className="card-dark-solid rounded-2xl p-6 relative z-10">
              <div className="font-syne font-800 text-4xl text-sun/20 mb-4">{step.num}</div>
              <h3 className="font-syne font-700 text-white text-lg mb-2">{step.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="text-center mt-10">
        <Link href="/calculator" className="inline-flex items-center gap-2 bg-sun text-sky-950 font-syne font-700 px-8 py-4 rounded-xl hover:bg-sun-300 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-sun/20">
          Start Your Calculation <Zap className="w-5 h-5" />
        </Link>
      </div>
    </Section>
  )
}

export function SubsidyBannerSection() {
  return (
    <Section>
      <div className="bg-gradient-to-br from-sun/15 via-sky-900/60 to-leaf/10 border border-sun/20 rounded-3xl p-10 sm:p-16 text-center">
        <div className="text-6xl mb-4">☀️</div>
        <h2 className="font-syne font-800 text-3xl sm:text-4xl text-white mb-4">
          PM Surya Ghar Muft Bijli Yojana
        </h2>
        <p className="text-slate-300 text-lg max-w-2xl mx-auto mb-6">
          The Government of India offers up to <strong className="text-sun">₹78,000 direct subsidy</strong> for rooftop
          solar under this 2024 scheme. Limited slots per district — apply before they run out.
        </p>
        <div className="flex flex-wrap justify-center gap-4 mb-8 text-sm">
          {['₹30,000 for 1 kW', '₹60,000 for 2 kW', '₹1,08,000 for 3+ kW (Central+UPNEDA)'].map((s) => (
            <div key={s} className="bg-sun/10 border border-sun/20 text-sun px-4 py-2 rounded-full font-medium">{s}</div>
          ))}
        </div>
        <Link href="/learn/subsidies" className="inline-flex items-center gap-2 bg-sun text-sky-950 font-syne font-700 px-8 py-4 rounded-xl hover:bg-sun-300 transition-all">
          Full Subsidy Guide <ArrowRight className="w-5 h-5" />
        </Link>
      </div>
    </Section>
  )
}

export function FaqSection() {
  const faqs = [
    { q: 'Who is eligible for the PM Surya Ghar subsidy?', a: 'Any residential homeowner in India with a valid electricity consumer number. Commercial properties are not eligible for the central subsidy, but UP state has separate incentives for commercial solar.' },
    { q: 'How long does installation take?', a: 'From site survey to commissioning takes 7–14 days for residential systems. Our partners handle all paperwork including DISCOM net-meter application and MNRE registration.' },
    { q: 'What is net metering?', a: 'Net metering allows you to export surplus solar electricity back to the UPPCL/PVVNL grid and earn credits on your bill. Your meter literally runs backward during the day.' },
    { q: 'What happens on cloudy days?', a: 'Modern monocrystalline panels produce 20–30% of rated capacity even on overcast days. You remain grid-connected so power is always available. Excess daytime production offsets night usage via net metering.' },
    { q: 'Is my roof suitable for solar?', a: 'South-facing or flat concrete roofs with minimal shading work best. Our certified partners do a free site survey and will advise if your roof needs any preparation.' },
    { q: 'What is the SBI solar loan scheme?', a: 'SBI offers solar home loans at 7% p.a. (up to 10 years, no collateral up to ₹2L) under PM Surya Ghar. The subsidy is deducted from the loan principal directly, so your EMI is calculated on the net amount.' },
  ]

  return (
    <Section dark>
      <SectionHeading badge="FAQs" title="Common" highlight="Questions" center />
      <div className="max-w-3xl mx-auto space-y-4">
        {faqs.map(({ q, a }) => (
          <details key={q} className="card-dark-solid rounded-xl group">
            <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
              <span className="font-syne font-600 text-white text-sm sm:text-base pr-4">{q}</span>
              <ChevronRight className="w-4 h-4 text-sun shrink-0 transition-transform group-open:rotate-90" />
            </summary>
            <p className="text-slate-400 text-sm leading-relaxed px-5 pb-5">{a}</p>
          </details>
        ))}
      </div>
    </Section>
  )
}

export function CtaSection() {
  return (
    <Section>
      <div className="card-dark-solid rounded-3xl p-10 sm:p-16 flex flex-col sm:flex-row items-center justify-between gap-8">
        <div>
          <h2 className="font-syne font-800 text-3xl text-white mb-3">Ready to Switch to Solar?</h2>
          <p className="text-slate-400 max-w-lg">
            Get your free estimate in 30 seconds. No commitment. Our calculator uses real UP electricity tariff rates,
            actual subsidy figures, and local solar irradiance data.
          </p>
        </div>
        <Link
          href="/calculator"
          className="shrink-0 inline-flex items-center gap-2 bg-sun text-sky-950 font-syne font-700 text-lg px-10 py-5 rounded-2xl hover:bg-sun-300 transition-all hover:-translate-y-1 hover:shadow-2xl hover:shadow-sun/20 whitespace-nowrap"
        >
          Calculate Free <Zap className="w-5 h-5" />
        </Link>
      </div>
    </Section>
  )
}
