'use client'
import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useI18n } from '@/lib/i18n/context'
import LanguageSwitcher from '@/components/ui/LanguageSwitcher'
import { PHONE, PHONE_DISPLAY } from '@/lib/constants'

export default function Navbar() {
  const { t } = useI18n()
  const pathname = usePathname()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [moreOpen, setMoreOpen] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 16)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const close = useCallback(() => { setMenuOpen(false); setMoreOpen(false) }, [])

  const mainLinks = [
    { href: '/calculator', label: t.nav.calculator },
    { href: '/why-solar', label: t.nav.whySolar },
    { href: '/muft-bijli-yojana', label: t.nav.muftBijli },
    { href: '/cities', label: t.nav.cities },
    { href: '/blog', label: t.nav.blog },
    { href: '/contact', label: t.nav.contact },
  ]

  const isActive = (href: string) => pathname === href || pathname?.startsWith(href + '/')

  return (
    <nav
      className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-xl shadow-sm' : 'bg-white/90 backdrop-blur-lg'} border-b border-[#E2E8F0]`}
      role="navigation" aria-label="Main navigation"
    >
      <div className="max-w-[1280px] mx-auto px-5 h-[64px] flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" onClick={close} className="flex items-center gap-2.5 shrink-0" aria-label="SolarBijli Home">
          <div className="w-[36px] h-[36px] rounded-[9px] flex items-center justify-center shrink-0"
               style={{ background: 'linear-gradient(135deg,#F59E0B,#D97706)', boxShadow: '0 3px 10px rgba(245,158,11,.3)' }}>
            <svg width="20" height="20" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <circle cx="16" cy="16" r="7" fill="white" opacity=".9"/>
              <line x1="16" y1="2" x2="16" y2="5.5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="16" y1="26.5" x2="16" y2="30" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="2" y1="16" x2="5.5" y2="16" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="26.5" y1="16" x2="30" y2="16" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="5.5" y1="5.5" x2="7.9" y2="7.9" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="24.1" y1="24.1" x2="26.5" y2="26.5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="26.5" y1="5.5" x2="24.1" y2="7.9" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <line x1="7.9" y1="24.1" x2="5.5" y2="26.5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <span className="font-black text-[18px] text-[#0F172A] tracking-tight">Solar<span className="text-[#4F46E5]">Bijli</span></span>
        </Link>

        {/* Desktop links */}
        <div className="hidden lg:flex items-center gap-0.5">
          {mainLinks.map(link => (
            <Link key={link.href} href={link.href}
              className={`px-3 py-2 rounded-lg text-[13.5px] font-medium transition-all whitespace-nowrap ${isActive(link.href) ? 'text-[#4F46E5] bg-[#EEF2FF]' : 'text-[#64748B] hover:text-[#0F172A] hover:bg-[#F8FAFC]'}`}>
              {link.label}
            </Link>
          ))}
        </div>

        {/* Right actions */}
        <div className="hidden lg:flex items-center gap-2 shrink-0">
          <LanguageSwitcher />
          <a href={`tel:${PHONE}`}
            className="flex items-center gap-1.5 text-[13px] font-bold px-3 py-2 rounded-xl transition-all text-[#047857] bg-[#ECFDF5] border border-[#A7F3D0] hover:bg-[#059669] hover:text-white hover:border-[#059669]"
            aria-label={`Call SolarBijli: ${PHONE_DISPLAY}`}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
            </svg>
            {PHONE_DISPLAY}
          </a>
          <Link href="/contact"
            className="text-[13.5px] font-bold px-4 py-2 rounded-xl bg-[#4F46E5] text-white hover:bg-[#4338CA] transition-all shadow-sm hover:shadow-md whitespace-nowrap">
            {t.nav.cta}
          </Link>
        </div>

        {/* Mobile */}
        <div className="flex lg:hidden items-center gap-2">
          <LanguageSwitcher />
          <a href={`tel:${PHONE}`} className="flex items-center justify-center w-9 h-9 rounded-xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#047857]" aria-label="Call">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
            </svg>
          </a>
          <button onClick={() => setMenuOpen(o => !o)}
            className="flex flex-col justify-center items-center w-9 h-9 gap-[5px]"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen}>
            <span className={`block w-5 h-0.5 bg-[#475569] transition-all ${menuOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
            <span className={`block w-5 h-0.5 bg-[#475569] transition-all ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block w-5 h-0.5 bg-[#475569] transition-all ${menuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="lg:hidden border-t border-[#E2E8F0] bg-white shadow-lg">
          <div className="max-w-[1280px] mx-auto px-4 py-3">
            {mainLinks.map(link => (
              <Link key={link.href} href={link.href} onClick={close}
                className={`flex items-center px-4 py-3 rounded-xl mb-1 text-[15px] font-medium transition-all ${isActive(link.href) ? 'text-[#4F46E5] bg-[#EEF2FF]' : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F8FAFC]'}`}>
                {link.label}
              </Link>
            ))}
            <div className="pt-2 pb-1">
              <Link href="/contact" onClick={close}
                className="flex items-center justify-center w-full py-3 rounded-xl bg-[#4F46E5] text-white font-bold text-[15px]">
                {t.nav.cta}
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
