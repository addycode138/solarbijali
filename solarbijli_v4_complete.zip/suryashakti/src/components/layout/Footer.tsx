'use client'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n/context'
import { PHONE, PHONE_DISPLAY, WA_NUMBER, EMAIL } from '@/lib/constants'

export default function Footer() {
  const { t } = useI18n()
  const year = new Date().getFullYear()

  const cols = [
    {
      title: 'Learn Solar',
      links: [
        { href: '/why-solar', label: 'Why Go Solar?' },
        { href: '/muft-bijli-yojana', label: 'Muft Bijli Yojana' },
        { href: '/solar-installation-process', label: 'Installation Process' },
        { href: '/learn/subsidies', label: 'Subsidy Guide' },
        { href: '/learn/solar-basics', label: 'Solar Basics' },
        { href: '/learn/loans', label: 'Solar Loans' },
      ],
    },
    {
      title: 'Our Cities',
      links: [
        { href: '/cities/noida', label: 'Solar in Noida' },
        { href: '/cities/ghaziabad', label: 'Solar in Ghaziabad' },
        { href: '/cities/meerut', label: 'Solar in Meerut' },
        { href: '/cities/baraut', label: 'Solar in Baraut' },
        { href: '/cities/muzaffarnagar', label: 'Solar in Muzaffarnagar' },
        { href: '/cities/saharanpur', label: 'Solar in Saharanpur' },
        { href: '/cities/shamli', label: 'Solar in Shamli' },
        { href: '/cities', label: 'All 12 Cities →' },
      ],
    },
    {
      title: 'Company',
      links: [
        { href: '/about', label: 'About SolarBijli' },
        { href: '/blog', label: 'Solar Blog' },
        { href: '/contact', label: 'Contact Us' },
        { href: '/partners', label: 'Become a Partner' },
        { href: '/privacy', label: 'Privacy Policy' },
        { href: '/terms', label: 'Terms & Conditions' },
      ],
    },
  ]

  return (
    <footer className="bg-[#0F172A] pt-14 pb-8" role="contentinfo">
      <div className="max-w-[1280px] mx-auto px-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-[34px] h-[34px] rounded-[9px] flex items-center justify-center shrink-0"
                   style={{ background: 'linear-gradient(135deg,#F59E0B,#D97706)' }}>
                <svg width="18" height="18" viewBox="0 0 32 32" fill="none" aria-hidden="true">
                  <circle cx="16" cy="16" r="7" fill="white" opacity=".9"/>
                  <line x1="16" y1="2" x2="16" y2="5.5" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <line x1="16" y1="26.5" x2="16" y2="30" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <line x1="2" y1="16" x2="5.5" y2="16" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <line x1="26.5" y1="16" x2="30" y2="16" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                </svg>
              </div>
              <span className="font-black text-[17px] text-white tracking-tight">Solar<span className="text-[#F59E0B]">Bijli</span></span>
            </Link>
            <p className="text-[13.5px] text-[#475569] leading-[1.75] max-w-[268px] mb-5">
              West UP&apos;s most trusted solar platform. MNRE certified installers in Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur &amp; 12 districts.
            </p>
            <div className="flex flex-col gap-2.5">
              <a href={`tel:${PHONE}`} className="flex items-center gap-2 text-[13px] font-semibold text-[#94A3B8] hover:text-[#F59E0B] transition-colors">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
                  <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
                </svg>
                {PHONE_DISPLAY}
              </a>
              <a href={`mailto:${EMAIL}`} className="flex items-center gap-2 text-[13px] font-semibold text-[#94A3B8] hover:text-[#F59E0B] transition-colors">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                </svg>
                {EMAIL}
              </a>
              <a href={`https://wa.me/${WA_NUMBER}`} target="_blank" rel="noopener noreferrer"
                 className="flex items-center gap-2 text-[13px] font-semibold text-[#94A3B8] hover:text-[#25D366] transition-colors">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
              </a>
            </div>
          </div>

          {/* Link columns */}
          {cols.map(col => (
            <div key={col.title}>
              <h3 className="text-[13.5px] font-bold text-white mb-4 tracking-wide">{col.title}</h3>
              <ul className="space-y-2.5" role="list">
                {col.links.map(link => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-[13px] text-[#475569] hover:text-[#F59E0B] transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="border-t border-[#1E293B] pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[12px] text-[#334155]">© {year} SolarBijli. All rights reserved. | {EMAIL}</p>
          <div className="flex items-center gap-1.5 text-[12px] text-[#059669]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#059669] animate-pulse inline-block" />
            PM Surya Ghar Registered · MNRE Approved Partners
          </div>
        </div>
      </div>
    </footer>
  )
}
