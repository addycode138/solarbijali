'use client'
import { useEffect, useRef } from 'react'
import { useCalcPopup } from '@/components/calculator/CalcPopupProvider'

export default function PopupManager() {
  const { openPopup } = useCalcPopup()
  const shown = useRef(false)

  const show = () => {
    if (shown.current) return
    shown.current = true
    openPopup()
  }

  useEffect(() => {
    // Check session storage - show only once per session
    if (sessionStorage.getItem('sb-popup-shown')) return

    // Delay popup: 15 seconds
    const delayTimer = setTimeout(() => {
      sessionStorage.setItem('sb-popup-shown', '1')
      show()
    }, 15000)

    // Exit intent popup
    const onMouseLeave = (e: MouseEvent) => {
      if (e.clientY < 50 && !sessionStorage.getItem('sb-popup-shown')) {
        sessionStorage.setItem('sb-popup-shown', '1')
        clearTimeout(delayTimer)
        show()
      }
    }
    document.addEventListener('mouseleave', onMouseLeave)

    return () => {
      clearTimeout(delayTimer)
      document.removeEventListener('mouseleave', onMouseLeave)
    }
  }, [])

  return null
}
