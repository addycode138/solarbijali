import { cn } from '@/lib/utils'

interface StatCardProps {
  label: string
  value: string
  sub?: string
  accent?: 'sun' | 'leaf' | 'blue'
  className?: string
}

export default function StatCard({ label, value, sub, accent = 'sun', className }: StatCardProps) {
  const accents = {
    sun: 'border-sun-400/20 text-sun',
    leaf: 'border-leaf/20 text-leaf',
    blue: 'border-sky-600/40 text-sky-400',
  }

  return (
    <div className={cn('card-dark-solid rounded-xl p-5 border', accents[accent], className)}>
      <p className="text-slate-400 text-xs font-medium uppercase tracking-wide mb-2">{label}</p>
      <p className={cn('font-syne font-700 text-2xl', accents[accent].split(' ')[1])}>{value}</p>
      {sub && <p className="text-slate-500 text-xs mt-1">{sub}</p>}
    </div>
  )
}
