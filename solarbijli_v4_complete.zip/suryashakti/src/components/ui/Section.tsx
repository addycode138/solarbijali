import { cn } from '@/lib/utils'

interface SectionProps {
  children: React.ReactNode
  className?: string
  id?: string
  dark?: boolean
}

export default function Section({ children, className, id, dark }: SectionProps) {
  return (
    <section
      id={id}
      className={cn(
        'py-20 px-4 sm:px-6 lg:px-8',
        dark ? 'bg-sky-900/40' : '',
        className
      )}
    >
      <div className="max-w-7xl mx-auto">{children}</div>
    </section>
  )
}

interface SectionHeadingProps {
  badge?: string
  title: string
  highlight?: string
  description?: string
  center?: boolean
}

export function SectionHeading({ badge, title, highlight, description, center }: SectionHeadingProps) {
  return (
    <div className={cn('mb-12', center && 'text-center')}>
      {badge && (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sun bg-sun/10 border border-sun/20 px-3 py-1 rounded-full mb-4">
          <span className="w-1.5 h-1.5 rounded-full bg-sun animate-pulse" />
          {badge}
        </span>
      )}
      <h2 className="font-syne font-700 text-3xl sm:text-4xl text-white">
        {title}{' '}
        {highlight && <span className="text-sun">{highlight}</span>}
      </h2>
      {description && (
        <p className="mt-4 text-slate-400 text-lg max-w-2xl leading-relaxed">
          {description}
        </p>
      )}
    </div>
  )
}
