'use client'
import { useState } from 'react'
import { useI18n } from '@/lib/i18n/context'
import { locales, localeNames, Locale } from '@/lib/i18n/translations'

export default function LanguageSwitcher() {
  const { locale, setLocale } = useI18n()
  const [open, setOpen] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#E2E8F0] text-[12.5px] font-medium text-[#64748B] bg-[#F8FAFC] hover:border-[#4F46E5] hover:text-[#4F46E5] transition-all"
        aria-label="Change language"
        aria-expanded={open}
      >
        <span>🌐</span>
        <span>{localeNames[locale]}</span>
        <svg width="9" height="9" viewBox="0 0 10 10" fill="none" className={`transition-transform ${open ? 'rotate-180' : ''}`}>
          <path d="M2 3.5l3 3 3-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute top-full right-0 mt-1.5 bg-white border border-[#E2E8F0] rounded-xl overflow-hidden z-50 min-w-[140px] shadow-lg py-1">
            {locales.map(l => (
              <button
                key={l}
                onClick={() => { setLocale(l); setOpen(false) }}
                className={`w-full text-left px-4 py-2.5 text-[13px] font-medium flex items-center gap-2 transition-all ${locale === l ? 'text-[#4F46E5] bg-[#EEF2FF]' : 'text-[#64748B] hover:text-[#0F172A] hover:bg-[#F8FAFC]'}`}
              >
                {locale === l && <span className="w-1.5 h-1.5 rounded-full bg-[#4F46E5]" />}
                {locale !== l && <span className="w-1.5 h-1.5" />}
                {localeNames[l]}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
