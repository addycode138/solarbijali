'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n/context'
import { PHONE } from '@/lib/constants'

export default function AnnouncementBar() {
  const [visible, setVisible] = useState(true)
  const { t } = useI18n()
  if (!visible) return null
  return (
    <div className="relative z-50 text-center py-2.5 px-4 text-[12.5px] font-semibold text-white overflow-hidden"
         style={{ background: 'linear-gradient(90deg,#4F46E5,#7C3AED,#4F46E5)', backgroundSize: '200% auto', animation: 'bgShift 5s linear infinite' }}
         role="banner">
      <span>{t.ann.text}&nbsp;</span>
      <Link href="/contact" className="underline text-yellow-200 font-bold hover:text-white mx-2">{t.ann.cta}</Link>
      <span className="hidden sm:inline">|</span>
      <a href={`tel:${PHONE}`} className="underline text-yellow-200 font-bold hover:text-white ml-2">{t.ann.call}: {t.phone}</a>
      <button onClick={() => setVisible(false)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-white/60 hover:text-white text-xl leading-none cursor-pointer bg-transparent border-none"
        aria-label="Close announcement">×</button>
    </div>
  )
}
