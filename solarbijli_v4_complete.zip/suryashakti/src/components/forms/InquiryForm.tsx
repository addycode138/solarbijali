'use client'
import { useState } from 'react'
import { useI18n } from '@/lib/i18n/context'
import { CITIES } from '@/lib/constants'

interface FormData {
  name: string
  phone: string
  email: string
  city: string
  monthlyBill: string
  propertyType: string
  preferredTime: string
  financing: string
  roofOwned: string
  message: string
}

type Step = 1 | 2 | 3

export default function InquiryForm({ onSuccess }: { onSuccess?: () => void }) {
  const { t } = useI18n()
  const [step, setStep] = useState<Step>(1)
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [data, setData] = useState<FormData>({
    name: '', phone: '', email: '', city: CITIES[0].name,
    monthlyBill: '', propertyType: 'residential',
    preferredTime: 'morning', financing: 'loan',
    roofOwned: 'yes', message: '',
  })

  const set = (field: keyof FormData, val: string) =>
    setData(prev => ({ ...prev, [field]: val }))

  const canStep1 = data.name.trim().length > 1 && data.phone.trim().length >= 10
  const canStep2 = data.city && data.monthlyBill
  const canStep3 = true

  const submit = async () => {
    setLoading(true)
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: data.name,
          phone: data.phone,
          email: data.email || undefined,
          city: data.city,
          monthlyBill: parseInt(data.monthlyBill) || 2500,
          propertyType: data.propertyType,
          preferredTime: data.preferredTime,
          financing: data.financing,
          source: 'inquiry-form',
          message: data.message,
        }),
      })
      setSubmitted(true)
      onSuccess?.()
    } catch {
      alert('Something went wrong. Please try WhatsApp or call us directly.')
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="text-center py-8">
        <div className="w-20 h-20 rounded-full bg-[rgba(14,164,114,.14)] border-2 border-[rgba(14,164,114,.3)] flex items-center justify-center text-4xl mx-auto mb-5 animate-bounce">
          ✅
        </div>
        <h3 className="font-syne font-extrabold text-2xl text-white mb-2">{t.lead.successTitle}</h3>
        <p className="text-[#64748B] text-[15px] mb-1">{t.lead.successMsg}</p>
        <p className="text-[#2D3748] text-[13px]">Ref: SS-{Date.now().toString().slice(-6)}</p>
        <div className="mt-6 flex flex-col gap-3">
          <a
            href={`https://wa.me/917373734778?text=${encodeURIComponent(`Hi! I just submitted my solar enquiry (${data.name}, ${data.city}). Please help me.`)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#25D366] text-white font-semibold text-[14px] hover:bg-[#22c55e] transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            {t.lead.whatsappCta}
          </a>
        </div>
      </div>
    )
  }

  const InputField = ({ label, value, onChange, placeholder, type = 'text', required = false }: {
    label: string; value: string; onChange: (v: string) => void;
    placeholder: string; type?: string; required?: boolean
  }) => (
    <div>
      <label className="block text-[12.5px] font-semibold text-[#64748B] mb-2 tracking-wide">
        {label} {required && <span className="text-[#E8A020]">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-[rgba(255,255,255,.05)] border border-[rgba(255,255,255,.1)] rounded-2xl px-4 py-3.5 text-[14px] text-white placeholder-[#334155] outline-none transition-all focus:border-[#E8A020] focus:shadow-[0_0_0_3px_rgba(232,160,32,.1)]"
      />
    </div>
  )

  const SelectField = ({ label, value, onChange, options, scrollable = false }: {
    label: string; value: string; onChange: (v: string) => void;
    options: { value: string; label: string }[]; scrollable?: boolean
  }) => (
    <div>
      <label className="block text-[12.5px] font-semibold text-[#64748B] mb-2 tracking-wide">{label}</label>
      <div className={`flex gap-2 flex-wrap${scrollable ? ' max-h-[100px] overflow-y-auto' : ''}`}>
        {options.map(opt => (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange(opt.value)}
            className={`px-3.5 py-2 rounded-xl text-[12.5px] font-medium border transition-all flex-shrink-0 ${
              value === opt.value
                ? 'bg-[rgba(232,160,32,.12)] border-[#E8A020] text-[#E8A020]'
                : 'bg-transparent border-[rgba(255,255,255,.1)] text-[#64748B] hover:border-[rgba(255,255,255,.2)] hover:text-[#94A3B8]'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  )

  return (
    <div>
      {/* Progress */}
      <div className="flex items-center gap-3 mb-8">
        {[1,2,3].map(s => (
          <div key={s} className="flex items-center gap-3 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[13px] font-bold transition-all flex-shrink-0 ${
              step > s ? 'bg-[#0EA472] text-white' :
              step === s ? 'bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A]' :
              'bg-[rgba(255,255,255,.07)] text-[#475569]'
            }`}>
              {step > s ? '✓' : s}
            </div>
            {s < 3 && (
              <div className={`flex-1 h-0.5 rounded-full transition-all ${step > s ? 'bg-[#0EA472]' : 'bg-[rgba(255,255,255,.08)]'}`}/>
            )}
          </div>
        ))}
      </div>

      {/* Step labels */}
      <div className="grid grid-cols-3 text-center mb-6">
        <span className={`text-[11px] font-semibold ${step >= 1 ? 'text-[#E8A020]' : 'text-[#334155]'}`}>Contact Info</span>
        <span className={`text-[11px] font-semibold ${step >= 2 ? 'text-[#E8A020]' : 'text-[#334155]'}`}>Your Setup</span>
        <span className={`text-[11px] font-semibold ${step >= 3 ? 'text-[#E8A020]' : 'text-[#334155]'}`}>Preferences</span>
      </div>

      {/* Step 1: Contact */}
      {step === 1 && (
        <div className="space-y-4">
          <InputField label={t.lead.name} value={data.name} onChange={v => set('name', v)} placeholder="Ramesh Kumar" required />
          <InputField label={t.lead.phone} value={data.phone} onChange={v => set('phone', v)} placeholder="+91 98765 43210" type="tel" required />
          <InputField label={t.lead.email} value={data.email} onChange={v => set('email', v)} placeholder="ramesh@example.com" type="email" />

          {/* Trust signals */}
          <div className="flex flex-wrap gap-3 pt-2">
            {['🔒 100% Private', '📞 No spam', '⚡ Expert callback <24hrs'].map(s => (
              <span key={s} className="text-[11.5px] text-[#475569] flex items-center gap-1">{s}</span>
            ))}
          </div>
        </div>
      )}

      {/* Step 2: Property */}
      {step === 2 && (
        <div className="space-y-5">
          <SelectField
            label={t.lead.city}
            value={data.city}
            onChange={v => set('city', v)}
            options={CITIES.map(c => ({ value: c.name, label: c.name }))}
            scrollable
          />
          <InputField
            label={t.calc.bill}
            value={data.monthlyBill}
            onChange={v => set('monthlyBill', v)}
            placeholder="e.g. 2500"
            type="number"
            required
          />
          <SelectField
            label={t.calc.propType}
            value={data.propertyType}
            onChange={v => set('propertyType', v)}
            options={[
              { value: 'residential', label: t.calc.residential },
              { value: 'commercial', label: t.calc.commercial },
            ]}
          />
          <SelectField
            label="Do you own the roof?"
            value={data.roofOwned}
            onChange={v => set('roofOwned', v)}
            options={[
              { value: 'yes', label: '✅ Yes, I own it' },
              { value: 'rented', label: '🏠 I rent' },
              { value: 'flat', label: '🏢 Society flat' },
            ]}
          />
        </div>
      )}

      {/* Step 3: Preferences */}
      {step === 3 && (
        <div className="space-y-5">
          <SelectField
            label={t.calc.financing}
            value={data.financing}
            onChange={v => set('financing', v)}
            options={[
              { value: 'cash', label: t.calc.cash },
              { value: 'loan', label: t.calc.sbiLoan },
              { value: 'emi', label: t.calc.easyEmi },
            ]}
          />
          <SelectField
            label={t.lead.preferredTime}
            value={data.preferredTime}
            onChange={v => set('preferredTime', v)}
            options={[
              { value: 'morning', label: '🌅 ' + t.lead.morning },
              { value: 'afternoon', label: '☀️ ' + t.lead.afternoon },
              { value: 'evening', label: '🌆 ' + t.lead.evening },
            ]}
          />
          <div>
            <label className="block text-[12.5px] font-semibold text-[#64748B] mb-2 tracking-wide">Any specific questions? (optional)</label>
            <textarea
              value={data.message}
              onChange={e => set('message', e.target.value)}
              placeholder="e.g. Can you install on a terrace? Is there a net metering delay in Noida?"
              rows={3}
              className="w-full bg-[rgba(255,255,255,.05)] border border-[rgba(255,255,255,.1)] rounded-2xl px-4 py-3 text-[14px] text-white placeholder-[#334155] outline-none transition-all focus:border-[#E8A020] resize-none"
            />
          </div>

          {/* Summary */}
          <div className="bg-[rgba(232,160,32,.06)] border border-[rgba(232,160,32,.15)] rounded-2xl p-4">
            <div className="text-[11px] font-bold text-[#E8A020] uppercase tracking-wider mb-3">Your Summary</div>
            <div className="space-y-1.5 text-[13px]">
              <div className="flex justify-between"><span className="text-[#64748B]">Name</span><span className="text-white font-medium">{data.name}</span></div>
              <div className="flex justify-between"><span className="text-[#64748B]">City</span><span className="text-white font-medium">{data.city}</span></div>
              <div className="flex justify-between"><span className="text-[#64748B]">Monthly Bill</span><span className="text-white font-medium">₹{parseInt(data.monthlyBill || '0').toLocaleString('en-IN')}</span></div>
              <div className="flex justify-between"><span className="text-[#64748B]">Property</span><span className="text-white font-medium capitalize">{data.propertyType}</span></div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex gap-3 mt-8">
        {step > 1 && (
          <button
            type="button"
            onClick={() => setStep((step - 1) as Step)}
            className="px-6 py-4 rounded-2xl border border-[rgba(255,255,255,.1)] text-[#64748B] hover:text-white hover:border-[rgba(255,255,255,.2)] transition-all text-[14px] font-medium"
          >
            ← Back
          </button>
        )}
        {step < 3 ? (
          <button
            type="button"
            onClick={() => setStep((step + 1) as Step)}
            disabled={step === 1 ? !canStep1 : !canStep2}
            className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[15px] tracking-wide transition-all hover:shadow-[0_12px_40px_rgba(232,160,32,.35)] disabled:opacity-40 disabled:cursor-not-allowed hover:-translate-y-0.5"
          >
            Continue →
          </button>
        ) : (
          <button
            type="button"
            onClick={submit}
            disabled={loading}
            className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#E8A020] to-[#F06820] text-[#0A0E1A] font-syne font-bold text-[15px] tracking-wide transition-all hover:shadow-[0_12px_40px_rgba(232,160,32,.35)] disabled:opacity-60 hover:-translate-y-0.5"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="white" strokeWidth="3" strokeDasharray="30 60" strokeLinecap="round"/></svg>
                Submitting...
              </span>
            ) : (
              t.lead.submit
            )}
          </button>
        )}
      </div>
    </div>
  )
}
