'use client'
import { useEffect, useRef } from 'react'

export default function SolarPanelHero3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let W = canvas.width = canvas.offsetWidth
    let H = canvas.height = canvas.offsetHeight
    let frame = 0
    let raf: number

    const resize = () => {
      W = canvas.width = canvas.offsetWidth
      H = canvas.height = canvas.offsetHeight
    }
    window.addEventListener('resize', resize)

    // Solar panel 3D isometric renderer
    const drawPanel = (
      cx: number, cy: number,
      w: number, h: number,
      depth: number,
      t: number,
      alpha: number
    ) => {
      ctx.save()
      ctx.globalAlpha = alpha

      // Isometric transform
      const cos30 = Math.cos(Math.PI / 6)
      const sin30 = Math.sin(Math.PI / 6)

      // Tilt angle
      const tilt = Math.sin(t * 0.3) * 0.08 + 0.15
      const rotY = t * 0.008

      // Top face (panel surface)
      ctx.save()
      ctx.translate(cx, cy)

      // Panel glow
      const grd = ctx.createRadialGradient(0, 0, 0, 0, 0, w * 1.5)
      grd.addColorStop(0, `rgba(232,160,32,${0.12 * alpha})`)
      grd.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.beginPath()
      ctx.ellipse(0, 0, w * 1.8, h * 1.8, 0, 0, Math.PI * 2)
      ctx.fillStyle = grd
      ctx.fill()

      // Draw isometric panel
      const px = w / 2
      const py = h / 2

      // Top-left, top-right, bottom-right, bottom-left in 3D
      const pts = [
        { x: -px, y: -py },
        { x: px, y: -py },
        { x: px, y: py },
        { x: -px, y: py },
      ].map(p => {
        // Apply Y rotation
        const rx = p.x * Math.cos(rotY) + depth * Math.sin(rotY)
        // Apply X tilt for isometric
        const ry = p.y
        const rz = -p.x * Math.sin(rotY) + depth * Math.cos(rotY)
        return {
          x: rx * cos30 - ry * sin30,
          y: rx * sin30 + ry * cos30 - rz * tilt,
        }
      })

      // Panel face
      ctx.beginPath()
      ctx.moveTo(pts[0].x, pts[0].y)
      pts.forEach(p => ctx.lineTo(p.x, p.y))
      ctx.closePath()

      // Solar panel gradient
      const panelGrad = ctx.createLinearGradient(pts[0].x, pts[0].y, pts[2].x, pts[2].y)
      panelGrad.addColorStop(0, `rgba(10,50,100,${0.95 * alpha})`)
      panelGrad.addColorStop(0.4, `rgba(15,60,120,${0.9 * alpha})`)
      panelGrad.addColorStop(1, `rgba(8,40,80,${0.85 * alpha})`)
      ctx.fillStyle = panelGrad
      ctx.fill()

      // Panel grid lines
      ctx.strokeStyle = `rgba(30,100,180,${0.4 * alpha})`
      ctx.lineWidth = 0.8

      // Horizontal grid lines
      const cols = 4, rows = 3
      for (let i = 1; i < cols; i++) {
        const r = i / cols
        const p0x = pts[0].x + (pts[1].x - pts[0].x) * r
        const p0y = pts[0].y + (pts[1].y - pts[0].y) * r
        const p1x = pts[3].x + (pts[2].x - pts[3].x) * r
        const p1y = pts[3].y + (pts[2].y - pts[3].y) * r
        ctx.beginPath()
        ctx.moveTo(p0x, p0y)
        ctx.lineTo(p1x, p1y)
        ctx.stroke()
      }
      for (let j = 1; j < rows; j++) {
        const r = j / rows
        const p0x = pts[0].x + (pts[3].x - pts[0].x) * r
        const p0y = pts[0].y + (pts[3].y - pts[0].y) * r
        const p1x = pts[1].x + (pts[2].x - pts[1].x) * r
        const p1y = pts[1].y + (pts[2].y - pts[1].y) * r
        ctx.beginPath()
        ctx.moveTo(p0x, p0y)
        ctx.lineTo(p1x, p1y)
        ctx.stroke()
      }

      // Border
      ctx.beginPath()
      ctx.moveTo(pts[0].x, pts[0].y)
      pts.forEach(p => ctx.lineTo(p.x, p.y))
      ctx.closePath()
      ctx.strokeStyle = `rgba(60,140,220,${0.6 * alpha})`
      ctx.lineWidth = 1.5
      ctx.stroke()

      // Shimmer/reflection
      const shimX = Math.sin(t * 0.5) * 0.5 + 0.5
      const shine = ctx.createLinearGradient(
        pts[0].x + (pts[1].x - pts[0].x) * shimX,
        pts[0].y + (pts[1].y - pts[0].y) * shimX,
        pts[0].x + (pts[1].x - pts[0].x) * (shimX + 0.3),
        pts[0].y + (pts[1].y - pts[0].y) * (shimX + 0.3)
      )
      shine.addColorStop(0, `rgba(255,255,255,0)`)
      shine.addColorStop(0.5, `rgba(255,255,255,${0.08 * alpha})`)
      shine.addColorStop(1, `rgba(255,255,255,0)`)
      ctx.fillStyle = shine
      ctx.beginPath()
      ctx.moveTo(pts[0].x, pts[0].y)
      pts.forEach(p => ctx.lineTo(p.x, p.y))
      ctx.closePath()
      ctx.fill()

      // Solar energy particles
      for (let i = 0; i < 3; i++) {
        const progress = ((t * 0.5 + i * 2) % 6) / 6
        const startX = pts[0].x + (pts[1].x - pts[0].x) * ((i + 1) / 4)
        const startY = pts[0].y + (pts[1].y - pts[0].y) * ((i + 1) / 4)
        const px2 = startX + (Math.sin(t + i) * 20 * progress)
        const py2 = startY - (80 * progress)
        ctx.beginPath()
        ctx.arc(px2, py2, 2 * (1 - progress), 0, Math.PI * 2)
        ctx.fillStyle = `rgba(232,160,32,${(1 - progress) * 0.7 * alpha})`
        ctx.fill()
      }

      ctx.restore()
      ctx.restore()
    }

    // Sun rays
    const drawSunRays = (cx: number, cy: number, r: number, t: number) => {
      const rays = 12
      for (let i = 0; i < rays; i++) {
        const angle = (i / rays) * Math.PI * 2 + t * 0.2
        const pulse = 1 + Math.sin(t * 2 + i) * 0.15
        const inner = r * 1.4 * pulse
        const outer = r * (2.2 + Math.sin(t + i * 0.5) * 0.3) * pulse
        const width = (0.5 + Math.sin(t * 0.8 + i) * 0.3) * 3

        const x1 = cx + Math.cos(angle) * inner
        const y1 = cy + Math.sin(angle) * inner
        const x2 = cx + Math.cos(angle) * outer
        const y2 = cy + Math.sin(angle) * outer

        const grad = ctx.createLinearGradient(x1, y1, x2, y2)
        grad.addColorStop(0, `rgba(232,160,32,0.6)`)
        grad.addColorStop(1, `rgba(232,160,32,0)`)

        ctx.beginPath()
        ctx.moveTo(x1, y1)
        ctx.lineTo(x2, y2)
        ctx.strokeStyle = grad
        ctx.lineWidth = width
        ctx.stroke()
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, W, H)
      frame++
      const t = frame * 0.02

      const cx = W / 2, cy = H / 2

      // Background sun corona
      const sunR = Math.min(W, H) * 0.12
      const corona = ctx.createRadialGradient(cx, cy - H * 0.1, 0, cx, cy - H * 0.1, sunR * 4)
      corona.addColorStop(0, 'rgba(255,200,50,0.12)')
      corona.addColorStop(0.4, 'rgba(232,160,32,0.06)')
      corona.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.beginPath()
      ctx.ellipse(cx, cy - H * 0.1, sunR * 4, sunR * 4, 0, 0, Math.PI * 2)
      ctx.fillStyle = corona
      ctx.fill()

      // Sun
      drawSunRays(cx, cy - H * 0.1, sunR, t)
      const sunGrad = ctx.createRadialGradient(cx, cy - H * 0.1, 0, cx, cy - H * 0.1, sunR)
      sunGrad.addColorStop(0, '#FFF0A0')
      sunGrad.addColorStop(0.5, '#F0A030')
      sunGrad.addColorStop(1, '#E06010')
      ctx.beginPath()
      ctx.arc(cx, cy - H * 0.1, sunR, 0, Math.PI * 2)
      ctx.fillStyle = sunGrad
      ctx.fill()

      // Main solar panel array - 3 panels
      const panelConfigs = [
        { ox: -W * 0.18, oy: H * 0.15, w: W * 0.22, h: H * 0.28, depth: 20, alpha: 1.0, dt: 0 },
        { ox: W * 0.18, oy: H * 0.15, w: W * 0.22, h: H * 0.28, depth: 20, alpha: 1.0, dt: 1 },
        { ox: 0, oy: H * 0.3, w: W * 0.26, h: H * 0.32, depth: 25, alpha: 1.0, dt: 0.5 },
      ]

      panelConfigs.forEach(cfg => {
        drawPanel(cx + cfg.ox, cy + cfg.oy, cfg.w, cfg.h, cfg.depth, t + cfg.dt, cfg.alpha)
      })

      // Energy flow lines
      for (let i = 0; i < 6; i++) {
        const progress = ((t * 0.7 + i * 1.0) % 4) / 4
        const startPanel = panelConfigs[i % 3]
        const sx = cx + startPanel.ox
        const sy = cy + startPanel.oy
        const ex = cx
        const ey = cy + H * 0.42

        const x = sx + (ex - sx) * progress
        const y = sy + (ey - sy) * progress - Math.sin(progress * Math.PI) * 30

        ctx.beginPath()
        ctx.arc(x, y, 2.5 * (1 - Math.abs(progress - 0.5) * 2), 0, Math.PI * 2)
        ctx.fillStyle = `rgba(232,160,32,${0.7 * Math.sin(progress * Math.PI)})`
        ctx.fill()
      }

      // House silhouette
      const hx = cx, hy = cy + H * 0.42
      const hw = W * 0.12, hh = H * 0.14
      ctx.save()
      ctx.globalAlpha = 0.35
      // Roof
      ctx.beginPath()
      ctx.moveTo(hx - hw, hy)
      ctx.lineTo(hx, hy - hh * 0.7)
      ctx.lineTo(hx + hw, hy)
      ctx.closePath()
      ctx.fillStyle = '#1E3A5F'
      ctx.fill()
      ctx.strokeStyle = 'rgba(60,140,220,0.4)'
      ctx.lineWidth = 1
      ctx.stroke()
      // Walls
      ctx.fillStyle = '#0D1829'
      ctx.fillRect(hx - hw * 0.7, hy, hw * 1.4, hh * 0.6)
      ctx.strokeStyle = 'rgba(60,140,220,0.3)'
      ctx.strokeRect(hx - hw * 0.7, hy, hw * 1.4, hh * 0.6)
      // Door
      ctx.fillStyle = 'rgba(60,140,220,0.2)'
      ctx.fillRect(hx - hw * 0.12, hy + hh * 0.3, hw * 0.24, hh * 0.3)
      ctx.restore()

      // Floating stats
      const stats = [
        { label: '₹78K Subsidy', x: cx - W * 0.32, y: cy - H * 0.1 },
        { label: '25yr Warranty', x: cx + W * 0.25, y: cy + H * 0.05 },
        { label: '4.5yr Payback', x: cx - W * 0.3, y: cy + H * 0.25 },
      ]
      stats.forEach((s, i) => {
        const pulse = 1 + Math.sin(t * 0.8 + i * 2) * 0.04
        ctx.save()
        ctx.translate(s.x, s.y)
        ctx.scale(pulse, pulse)
        ctx.globalAlpha = 0.7
        ctx.fillStyle = 'rgba(10,14,26,0.85)'
        const tw = ctx.measureText(s.label).width + 24
        ctx.roundRect(-tw / 2, -14, tw, 28, 8)
        ctx.fill()
        ctx.strokeStyle = 'rgba(232,160,32,0.4)'
        ctx.lineWidth = 1
        ctx.roundRect(-tw / 2, -14, tw, 28, 8)
        ctx.stroke()
        ctx.fillStyle = '#E8A020'
        ctx.font = 'bold 11px DM Sans, sans-serif'
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.fillText(s.label, 0, 0)
        ctx.restore()
      })

      raf = requestAnimationFrame(animate)
    }

    animate()
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ imageRendering: 'crisp-edges' }}
    />
  )
}
