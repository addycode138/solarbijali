interface Props {
  tag?: string
  h1: string
  desc?: string
  breadcrumb?: { href: string; label: string }[]
  className?: string
}

export default function PageHeader({ tag, h1, desc, breadcrumb, className = '' }: Props) {
  return (
    <div className={`bg-gradient-to-b from-[#EEF2FF] to-[#F8FAFC] border-b border-[#E2E8F0] pt-12 pb-10 px-5 ${className}`}>
      <div className="max-w-[1280px] mx-auto">
        {breadcrumb && (
          <nav aria-label="Breadcrumb" className="flex items-center flex-wrap gap-1.5 text-[12px] text-[#94A3B8] mb-5">
            {breadcrumb.map((item, i) => (
              <span key={item.href} className="flex items-center gap-1.5">
                {i > 0 && <span aria-hidden="true">›</span>}
                {i < breadcrumb.length - 1
                  ? <a href={item.href} className="hover:text-[#4F46E5] transition-colors">{item.label}</a>
                  : <span className="text-[#475569] font-medium">{item.label}</span>
                }
              </span>
            ))}
          </nav>
        )}
        {tag && (
          <div className="section-tag mb-3">{tag}</div>
        )}
        <h1 className="text-[clamp(28px,4.5vw,46px)] font-black text-[#0F172A] tracking-tight leading-tight mb-3">
          {h1}
        </h1>
        {desc && (
          <p className="text-[16px] text-[#64748B] leading-relaxed max-w-[640px]">{desc}</p>
        )}
      </div>
    </div>
  )
}
