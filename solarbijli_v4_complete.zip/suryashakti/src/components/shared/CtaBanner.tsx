'use client'
import Link from 'next/link'
import { useCalcPopup } from '@/components/calculator/CalcPopupProvider'
import { PHONE_DISPLAY } from '@/lib/constants'

interface Props {
  title?: string
  desc?: string
}

export default function CtaBanner({ title = 'Ready to Go Solar in UP?', desc = 'Get ₹1,08,000 total subsidy + free site survey. MNRE certified partners in Noida, Ghaziabad, Meerut, Baraut, Muzaffarnagar, Saharanpur & 12 West UP cities.' }: Props) {
  const { openPopup } = useCalcPopup()
  return (
    <section className="bg-[#4F46E5] py-16 px-5" aria-label="Call to action">
      <div className="max-w-[900px] mx-auto text-center">
        <h2 className="text-[clamp(24px,4vw,38px)] font-black text-white tracking-tight leading-tight mb-3">{title}</h2>
        <p className="text-[16px] text-white/80 mb-8 leading-relaxed">{desc}</p>
        <div className="flex flex-wrap gap-3 justify-center">
          <button onClick={openPopup}
            className="bg-white text-[#4F46E5] font-bold text-[15px] px-8 py-4 rounded-xl hover:-translate-y-0.5 hover:shadow-xl transition-all">
            ⚡ Calculate My Savings Free
          </button>
          <a href={`tel:7373734778`}
            className="flex items-center gap-2 bg-white/15 text-white font-semibold text-[15px] px-7 py-4 rounded-xl border border-white/25 hover:bg-white/25 transition-all">
            📞 {PHONE_DISPLAY}
          </a>
        </div>
      </div>
    </section>
  )
}
