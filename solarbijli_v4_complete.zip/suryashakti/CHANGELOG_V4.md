# SolarBijli v4 — Complete Production Changelog

## Summary of All Changes (v3 → v4)

### 🏙️ 12 West UP Cities Added (`src/lib/constants.ts`)
- **New cities**: Baraut (Baghpat), Baghpat, Ghaziabad, Muzaffarnagar, Saharanpur, Hapur, Bulandshahr, Moradabad
- Each with verified sun hours (5.4–5.7 hrs/day), avg bills, district names
- `CALCULATOR_CITIES` export for prioritized display order
- `WEST_UP_DISTRICTS` export for SEO use

### 📊 Calculator Tenure Selection (`src/components/calculator/SolarCalculator.tsx`)
- **5 / 7 / 10 / 15 year tenure buttons** — live EMI recalculates instantly
- All 12 cities selectable with "Show all cities" toggle
- City info bar: district + sun hours + avg bill
- Full EMI comparison table: Canara (6.5%) & SBI (7%) × all 4 tenures
- Mobile-first: `p-5 sm:p-6 lg:p-8`, `clamp()` font sizes, responsive big numbers

### 🤖 Super-Smart Chatbot (`src/components/chatbot/Chatbot.tsx`)
- **Auto-opens at 4 seconds** with animated tooltip "Free solar estimate 👆"
- **Guided flow**: bill → city → tenure → live results card → name → phone → saved lead
- Live calculation card with: system size, EMI per tenure, subsidies breakdown, net monthly gain, 25yr savings, CO₂
- Context-aware **quick reply chips** change per conversation stage
- All 12 cities detected from natural language input
- WhatsApp button in chat header
- Lead POSTed to `/api/leads` with full data
- Typing indicators, message timestamps
- FreeSolarChat for all Q&A including net metering, warranty, timeline, loans

### 📋 CalcPopup Updated (`src/components/calculator/CalcPopup.tsx`)
- All 12 cities (8 popular + "All 12 ▼" toggle)
- Tenure selector: 5/7/10/15yr with live EMI
- Shows Annual Savings row in estimate summary
- Mobile padding fixes (px-5 sm:px-7)

### 📱 Mobile Optimization (`src/app/globals.css`)
- `overflow-x: hidden` on html/body
- Firefox range input (`-moz-range-track`, `-moz-range-thumb`)
- `line-clamp-2` utility for city card descriptions
- Mobile section spacing tightened at `max-width: 640px`
- Chatbot safe zone at `max-width: 390px`
- `focus-visible` outline for accessibility
- Touch target sizing for range inputs on mobile

### 🌍 Homepage (`src/app/page.tsx`)
- H1 updated: "Western UP's #1 Solar Platform"
- Description: all 12 cities mentioned, ₹1,08,000 total, EMI ₹638/mo
- Stat badge: "12 Cities" (was "4 Cities")
- Ticker: all 12 cities scroll through
- Cities grid: 12 cards (2×6), mobile 2-col → 3-col → 4-col
- Subsidy section: shows Central + UP State breakdown, ₹1,08,000 total
- FAQ: added EMI tenure question
- All px-6 → px-4 sm:px-6 for mobile

### 🔍 SEO (`src/lib/seo.ts`)
- **31 targeted keywords** including every West UP district
- `getOrganizationSchema()`: 12 cities in `areaServed`
- `getLocalBusinessSchema()`: precise GPS coords for all 12 cities, rich `hasOfferCatalog`
- `getCalculatorAppSchema()`: 9 feature list items, tenure options mentioned
- `getWebsiteSchema()`: updated description

### 📄 City Pages (`src/app/cities/[city]/page.tsx`)
- Metadata: ₹1,08,000 (was ₹78,000), 2025 dates, EMI ₹638/mo
- 5 FAQs per city (was 4) — added subsidy application process FAQ
- WhatsApp link uses real phone `7373734778` (was fake 9876543210)
- Subsidy card: shows Central + UP State breakdown inline
- Breadcrumb: links to `/cities` (was `/#cities`)
- Mobile: `p-4 sm:p-6`, `text-[clamp]`, responsive card grid

### 📁 Cities Index (`src/app/cities/page.tsx`)
- Stats bar: 12 districts, ₹1,08,000, 500+ installations, 5.4–5.7 sun hrs
- Grid: 3-col on lg (was 2-col), all 12 city cards
- `line-clamp-2` on descriptions for clean layout
- SEO copy section at bottom
- Metadata: all 12 cities in title + description

### 🧾 Forms & UI
- `InquiryForm.tsx`: scrollable city selector (all 12), fixed translation keys (`propType`, `bill`, `whatsappCta`), real WhatsApp number
- `Footer.tsx`: "7 cities" link column with all major cities
- `CtaBanner.tsx`: description mentions all 12 cities
- `About.tsx`: links to all 12 city pages

### 🌐 Other Pages
- `calculator/page.tsx`: 2025 dates, ₹1,08,000, tenure mention, all 12 cities in SEO copy
- `contact/page.tsx`: `areaServed` expanded to 12 cities
- `solar-installation-process/page.tsx`: "12 West UP cities" everywhere
- `blog/[slug]/page.tsx`: 12 cities in CTA text
- `partners/page.tsx`: SolarBijli branding (was SuryaShakti)
- `admin/page.tsx`: SolarBijli branding
- `learn/solar-basics/page.tsx`: SolarBijli title
- `blog-data.ts`: EMI note updated to 7%/6.5% tenure options

### 🗺️ Sitemap (`next-sitemap.config.js`)
- All 12 city pages with priority 0.92
- Added `/muft-bijli-yojana` (0.95), `/cities` (0.93), `/why-solar` (0.90), `/solar-installation-process` (0.88), `/contact` (0.80)

### 🌐 Translations (`src/lib/i18n/translations.ts`)
- Chat greeting: shorter, action-focused
- Quick replies updated
- "SBI loan @ 7% (Canara 6.5%)" (was 7.25%)

### ✅ Brand Consistency
- All "SuryaShakti" → "SolarBijli" (partners, admin, HomeSections, solar-basics)
- All fake phone `9876543210` → `98765XXXXX` placeholder or real number
- All `₹868/month` EMI → `₹638/month`
- All `7.25%` → `7%` (SBI) or `6.5%` (Canara)
- All `2024` dates → `2025`
- All `₹78,000` standalone subsidy → `₹1,08,000 (Central + UPNEDA)`

---

## Run Locally
```bash
cd suryashakti
npm install
cp .env.example .env.local
# Add your DATABASE_URL, RESEND_API_KEY, NEXT_PUBLIC_APP_URL
npm run dev        # http://localhost:3000
npm run build      # production build
npm run type-check # TypeScript check
```

## Key Files Changed (13 total)
| File | Changes |
|------|---------|
| `src/lib/constants.ts` | 12 cities |
| `src/lib/seo.ts` | 31 keywords, all city schemas |
| `src/lib/i18n/translations.ts` | Chat, rates |
| `src/app/globals.css` | Mobile CSS, Firefox, a11y |
| `src/app/page.tsx` | 12 cities everywhere |
| `src/app/calculator/page.tsx` | 2025, tenure |
| `src/app/cities/page.tsx` | 12 city grid |
| `src/app/cities/[city]/page.tsx` | All 12, 5 FAQs |
| `src/app/layout.tsx` | 12 cities metadata |
| `src/components/chatbot/Chatbot.tsx` | Full rebuild |
| `src/components/calculator/SolarCalculator.tsx` | Tenure selector |
| `src/components/calculator/CalcPopup.tsx` | 12 cities, tenure |
| `src/components/forms/InquiryForm.tsx` | 12 cities, fixes |
| `src/components/layout/Footer.tsx` | 7 city links |
| `next-sitemap.config.js` | 12 cities |
