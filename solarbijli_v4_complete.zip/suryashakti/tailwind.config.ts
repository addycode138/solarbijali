import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      fontFamily: {
        syne: ['var(--font-syne)', 'Inter', 'sans-serif'],
        dm: ['var(--font-dm)', 'Inter', 'sans-serif'],
      },
      colors: {
        sun: { DEFAULT: '#F59E0B', 2: '#D97706', bg: '#FFFBEB', border: '#FDE68A', text: '#92400E' },
        cta: { DEFAULT: '#4F46E5', 2: '#4338CA', bg: '#EEF2FF', light: '#E0E7FF' },
        leaf: { DEFAULT: '#059669', 2: '#047857', bg: '#ECFDF5', border: '#A7F3D0' },
        ink: { DEFAULT: '#0F172A', 2: '#1E293B' },
        surface: { DEFAULT: '#F8FAFC', 2: '#F1F5F9' },
        line: { DEFAULT: '#E2E8F0', 2: '#CBD5E1' },
        muted: { DEFAULT: '#64748B', 2: '#94A3B8' },
      },
      borderRadius: {
        '2xl': '16px', '3xl': '24px', '4xl': '32px',
      },
      boxShadow: {
        'card': '0 4px 6px -1px rgba(15,23,42,.08), 0 2px 4px -2px rgba(15,23,42,.05)',
        'card-hover': '0 20px 25px -5px rgba(15,23,42,.1), 0 8px 10px -6px rgba(15,23,42,.04)',
        'cta': '0 1px 2px rgba(79,70,229,.2)',
        'cta-hover': '0 10px 15px -3px rgba(79,70,229,.2)',
      },
      animation: {
        shimmer: 'shimmer 2s ease-in-out infinite',
        sunSpin: 'sunSpin 12s linear infinite',
        fadeUp: 'fadeUp .8s ease both',
        ticker: 'ticker 22s linear infinite',
        floatY: 'floatY 4s ease-in-out infinite',
      },
      keyframes: {
        shimmer: { '0%,100%': { opacity: '.6' }, '50%': { opacity: '1' } },
        sunSpin: { to: { transform: 'rotate(360deg)' } },
        fadeUp: { from: { opacity: '0', transform: 'translateY(24px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        ticker: { from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
        floatY: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-8px)' } },
      },
    },
  },
  plugins: [],
}

export default config
