# ☀️ SuryaShakti v2.0 — Production Solar Platform

Full-stack Next.js 14 solar marketing website for Western UP. Features multilingual support, AI chatbot, 3D animations, full SEO suite, and high-converting lead capture.

---

## 🆕 v2.0 Features

| Feature | Details |
|---|---|
| **Multilingual** | English, हिंदी, भोजपुरी — auto-detects browser language |
| **AI Chatbot** | SuryaBot — rule-based NLP, solar calculator, lead capture |
| **3D Animation** | Canvas-based isometric solar panel hero with live particles |
| **WhatsApp CTA** | Floating button with pre-filled message per language |
| **SEO Suite** | Full schema markup, canonical, hreflang, sitemap, robots.txt |
| **Inquiry Form** | 3-step wizard with trust signals, auto-validation |
| **Performance** | Aggressive caching, image optimization, CSS/JS splitting |
| **PWA** | Web app manifest for mobile install |

---

## Quick Start

```bash
git clone https://github.com/your-org/suryashakti.git
cd suryashakti
npm install
cp .env.example .env.local   # fill in required values
npm run db:push               # create database tables
npm run db:seed               # add demo agencies
npm run dev                   # start at localhost:3000
```

---

## Deployment (Vercel)

```bash
vercel                        # follow prompts, or use GitHub integration
```

**Required environment variables in Vercel dashboard:**
- `DATABASE_URL` — Supabase PostgreSQL connection string
- `RESEND_API_KEY` — for email notifications
- `ADMIN_SECRET` — long random string for admin dashboard
- `NEXT_PUBLIC_APP_URL` — your domain e.g. `https://suryashakti.in`
- `NEXT_PUBLIC_WHATSAPP_NUMBER` — WhatsApp number with country code

**Recommended:**
- `NEXT_PUBLIC_GTM_ID` — Google Tag Manager
- `GOOGLE_SITE_VERIFICATION` — Search Console verification

---

## SEO Architecture

### Schema Markup (JSON-LD)
| Schema | Page | Purpose |
|---|---|---|
| Organization | All pages | Brand entity |
| WebSite + SearchAction | All pages | Sitelinks search box |
| LocalBusiness | City pages | Local pack ranking |
| FAQPage | Home + City | FAQ rich results |
| HowTo | Home | Process rich result |
| Product + AggregateRating | Home | Product rich result |
| WebApplication | Calculator | App rich result |
| BreadcrumbList | Inner pages | Breadcrumb rich result |

### Meta Tags
- Title optimised with primary keyword + brand
- Description with benefit + location + CTA
- Canonical URL on every page
- `hreflang` for English and Hindi
- OpenGraph + Twitter card
- `geo.region`, `geo.placename`, `ICBM` for local SEO
- `robots` with `max-image-preview:large, max-snippet:-1`

### Sitemap
Auto-generated at `/sitemap.xml` after build. Includes:
- Homepage (daily, priority 1.0)
- Calculator (weekly, priority 0.98)
- Learn pages (monthly, 0.85–0.92)
- City pages (monthly, priority 0.9)
- hreflang alternates for en-IN and hi-IN

### Performance (Core Web Vitals)
- Fonts: `display: swap` on all Google Fonts
- Images: Next.js `Image` with AVIF/WebP, lazy loading
- 3D canvas: `dynamic()` with `ssr: false` — doesn't block HTML
- Chatbot & InquiryForm: lazy-loaded via `dynamic()`
- Aggressive cache headers: 1 year on static assets
- CSS: Tailwind + PurgeCSS removes unused styles

---

## Multilingual System

Three locales supported: `en` (English), `hi` (Hindi), `bho` (Bhojpuri).

### Auto-detection
1. Checks `localStorage` for saved preference
2. Falls back to `navigator.language`
3. Defaults to English

### Adding a new language
1. Add locale to `src/lib/i18n/translations.ts` — copy `en` block and translate
2. Add to `locales` array and `localeNames` map
3. Add to `next-sitemap.config.js` `alternateRefs`

### Using translations in components
```tsx
'use client'
import { useI18n } from '@/lib/i18n/context'

export default function MyComponent() {
  const { t, locale } = useI18n()
  return <h1>{t.hero.line1}</h1>
}
```

---

## Chatbot (SuryaBot)

Located at `src/components/chatbot/Chatbot.tsx`. Rule-based NLP that handles:

| Intent | Trigger keywords | Response |
|---|---|---|
| Subsidy info | subsidy, government, free | PM Surya Ghar slab breakdown |
| EMI/loan | emi, loan, monthly | SBI loan calculation |
| Calculate | bill amount (e.g. "3000") | Live calculator result |
| Installation time | install, days, survey | Step-by-step timeline |
| Net metering | grid, sell, excess | Net metering explanation |
| Roof space | roof, area, sq ft | Space requirements |
| Cities | noida, meerut, etc. | City coverage + data |

Lead capture form appears automatically after intent-matched responses.

### Upgrading to Claude AI
Set `ANTHROPIC_API_KEY` and update `src/app/api/chat/route.ts`:
```ts
import Anthropic from '@anthropic-ai/sdk'
const client = new Anthropic()
// Use claude-haiku-4-5 for speed + cost efficiency
```

---

## 3D Solar Animation

`src/components/3d/SolarPanelHero3D.tsx` — Canvas 2D renderer:
- 3 isometric solar panels with real-time shimmer
- Animated sun with 12 rotating rays
- Floating energy particles flowing to house
- House silhouette with solar connection
- Floating stats badges (₹78K Subsidy, 25yr Warranty, 4.5yr Payback)
- Responsive: hidden on mobile, shown on lg+ screens
- Loaded via `dynamic(() => ..., { ssr: false })` — zero impact on FCP

---

## WhatsApp Integration

Update the phone number in two places:
1. `src/components/ui/WhatsAppButton.tsx` — `WHATSAPP_NUMBER` constant
2. `.env.local` — `NEXT_PUBLIC_WHATSAPP_NUMBER`

Messages are pre-filled per language from `translations.ts` → `whatsapp.message`.

---

## File Structure

```
src/
├── app/
│   ├── page.tsx                    ← Homepage (all sections + SEO)
│   ├── layout.tsx                  ← Root layout (i18n, GTM, schema)
│   ├── calculator/page.tsx         ← Calculator page + SEO content
│   ├── cities/[city]/page.tsx      ← Dynamic city pages
│   ├── learn/subsidies/page.tsx    ← PM Surya Ghar guide
│   ├── learn/solar-basics/page.tsx ← Solar education
│   ├── learn/loans/page.tsx        ← Loan comparison
│   ├── partners/page.tsx           ← Partner listing
│   ├── about/page.tsx
│   ├── admin/page.tsx              ← Password-protected lead dashboard
│   ├── api/leads/route.ts          ← POST lead, GET list
│   ├── api/agencies/route.ts
│   └── api/calculate/route.ts
├── components/
│   ├── 3d/SolarPanelHero3D.tsx    ← Canvas 3D animation
│   ├── calculator/SolarCalculator.tsx
│   ├── chatbot/Chatbot.tsx         ← AI chatbot + lead capture
│   ├── forms/InquiryForm.tsx       ← 3-step inquiry form
│   ├── layout/Navbar.tsx           ← With language switcher
│   ├── layout/Footer.tsx           ← With i18n links
│   └── ui/
│       ├── LanguageSwitcher.tsx    ← EN / हिंदी / भोजपुरी
│       └── WhatsAppButton.tsx
├── lib/
│   ├── calculator.ts               ← Solar calculation engine
│   ├── constants.ts                ← Cities, rates, slabs
│   ├── seo.ts                      ← All schema + metadata helpers
│   ├── i18n/
│   │   ├── translations.ts         ← EN + HI + BHO translations
│   │   └── context.tsx             ← React context + auto-detection
│   ├── db.ts                       ← Prisma client
│   ├── email.ts                    ← Resend email templates
│   └── validations.ts              ← Zod schemas
└── types/index.ts
```

---

## Google Ranking Checklist

After deployment, complete these steps:

1. **Search Console**: Add property at search.google.com/search-console
2. **Submit sitemap**: `https://yourdomain.in/sitemap.xml`
3. **Google My Business**: Create GMB listing for each city
4. **Core Web Vitals**: Run PageSpeed Insights — target 90+ mobile score
5. **Index Coverage**: Check no important pages are blocked in robots.txt
6. **Backlinks**: List on JustDial, IndiaMART, SolarQuotes for local citations
7. **Reviews**: Collect Google reviews for LocalBusiness schema rating

---

## Support

- [Next.js 14 Docs](https://nextjs.org/docs)
- [Prisma Docs](https://prisma.io/docs)
- [Supabase Docs](https://supabase.com/docs)
- [PM Surya Ghar Portal](https://pmsuryaghar.gov.in)
- [PVVNL Net Metering](https://pvvnl.org)
